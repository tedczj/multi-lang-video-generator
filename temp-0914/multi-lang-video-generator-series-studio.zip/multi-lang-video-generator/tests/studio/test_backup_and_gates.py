from pathlib import Path
import json
import pytest
from mlvideo.backup import backup,restore,TABLES
from mlvideo.studio.catalog import Catalog,VOICE_CHECKS
from mlvideo.studio.jobs import execute_next
from mlvideo.util import file_lock
from .helpers import seed_episode, profile_ready, fake_tts
from .sqlite_protocol import SQLiteProtocolDB


def test_backup_contains_and_restores_studio(catalog,tmp_path):
    s=catalog.create_series('Backup series');catalog.create_character(s['id'],'A')
    with file_lock(catalog.root/'.writer.lock'):
        out=tmp_path/'backup';result=backup(catalog.engine,out)
    assert 'studio_profiles' in result['tables'] and result['tables']['studio_characters']==1
    target=dict(catalog.config,data_root=str(tmp_path/'restored'),test_sqlite=str(tmp_path/'restored.sqlite'))
    target['database']={**target['database'],'database':'RESTORE_ISOLATED'}
    Path(target['data_root']).mkdir()
    db=SQLiteProtocolDB(target);db.migrate()
    try:
        cat=Catalog(db,target)
        with file_lock(cat.root/'.writer.lock'):restore(cat.engine,out)
        assert cat.rows('studio_series')[0]['name']=='Backup series'
        assert cat.rows('studio_characters')[0]['series_id']==s['id']
    finally:db.close()


def test_profile_rejects_another_profiles_preview(catalog,monkeypatch):
    fake_tts(monkeypatch);s,ep,rev=seed_episode(catalog);c=catalog.create_character(s['id'],'A')
    p,ref=profile_ready(catalog,ep,rev,c)
    p2=catalog.create_profile(c['id'],ref['id'],'Second draft')
    j=catalog.rows('studio_jobs',"kind='PREVIEW'")[0]
    with pytest.raises(ValueError):catalog.publish_profile(p2['id'],j['id'],'TEST','wrong binding',dict.fromkeys(VOICE_CHECKS,True))


def test_unknown_job_transition_is_rejected(catalog):
    s=catalog.create_series('S');ep=catalog.create_episode(s['id'],'E','https://youtu.be/Ye33eY4UNtY')
    j=catalog.prepare(ep['id'])
    with pytest.raises(ValueError):catalog.finish_job(j['id'],'SUCCEEDED',{})
    assert catalog.get('studio_jobs',j['id'])['state']=='QUEUED'


def test_qa_fail_is_persisted_and_cannot_be_consumed(catalog,monkeypatch):
    _,stub=fake_tts(monkeypatch);s,ep,rev=seed_episode(catalog);c=catalog.create_character(s['id'],'A')
    p,_=profile_ready(catalog,ep,rev,c)
    stub.silence=True
    job=catalog.preview(p['id'],'你好');assert execute_next(catalog)
    result=catalog.get('studio_jobs',job['id'])['result']
    assert result['quality_status']=='FAIL'
    execution=catalog.db.one('SELECT execution_id FROM artifacts WHERE id=%s',(result['qa'],))['execution_id']
    assert catalog.engine.result(execution)['quality_status']=='FAIL'
    with pytest.raises(ValueError,match='failed quality checks'):catalog.engine.artifact(result['audio'],ep['asset_sha512'])
    with pytest.raises(ValueError):catalog.publish_profile(p['id'],job['id'],'TEST','must reject silent clip',dict.fromkeys(VOICE_CHECKS,True))
