# 本地视频“英文一句 → 中文一句”研究与时间线验证包

本包有两部分：

1. `DEVELOPMENT_DESIGN_ZH.md`：公开项目研究、最小改造路线、数据协议和开发验收方案。
2. `timeline_demo.py`、`test_timeline.py`、`demo.py`：**已经运行验证的时间线/合成原型**。

**本包不是完整的一键 AI 视频翻译软件。没有实现字幕 OCR、去字幕修复、字体识别、LLM 翻译或声音克隆。** 原型接收已经清理的视频、同步的原音轨和预先生成的中文音频；合成测试中的音频是不同频率的提示音，不是实际语音。

## 环境

Python 3.10+，PATH 中有 `ffmpeg` 和 `ffprobe`。Python 部分只有标准库，没有 pip 依赖。

FFmpeg 构建需包含 FFV1、libx264、AAC；烧录字幕还需要 libass 和已安装的中文字体。包内不包含任何字体或模型权重。执行：

```bash
python3 --version
ffmpeg -version
ffmpeg -filters | grep -E ' ass | loop | trim '
```

本次验证环境：Python 3.13.5、Linux x86_64、FFmpeg 7.1.5。**没有在你的 Mac 上实测。** Mac 可指定本机已有字体，例如 `PingFang SC`；存在该字体及 libass 字形回退正确性需要在本机检查。

## 运行测试

在本目录执行：

```bash
python3 -m unittest -v test_timeline
python3 demo.py --out my_demo_run --font "PingFang SC"
```

在安装了 Noto Sans CJK SC 的机器上：

```bash
python3 demo.py --out my_demo_run --font "Noto Sans CJK SC"
```

只验证音视频时间线、不烧录字幕：

```bash
python3 demo.py --out my_demo_run_no_burn --no-burn
```

输出目录必须为空或不存在；脚本不自动删除旧结果。再次测试使用另一个 `--out` 路径。

成功后检查：

- `my_demo_run/rendered/result.mp4`：合成结果。
- `my_demo_run/rendered/timeline.json`：源时间线到成片的映射。
- `my_demo_run/rendered/qa.json`：结构检查报告及明确的未测试项目。
- `my_demo_run/rendered/master.mkv`、`master.wav`：用于精确比对的无损中间产物。

本次已执行结果在 `verified_output/`。10 项单元测试通过，其中一项包含 250 个随机时间线案例。合成测试输入 150 帧 / 6 秒，插入 1.2 秒、0.8 秒音频，每段前后各 150 ms 并向上补齐到帧；输出 216 帧 / 8.64 秒 / 414720 个 48 kHz 音频采样帧。

检查包括：帧数、主音轨采样数、音画时长差、全文件解码；原音和插入音频在无损主音轨中的逐采样位置；原始帧和定格帧在未烧字无损主视频中的逐帧哈希。**精确一致性不指最终 H.264/AAC 的编码字节相同。**

## 使用自己的预处理素材

创建 `manifest.json`，路径相对这个 JSON 所在目录：

```json
{
  "clean_video": "clean.mp4",
  "original_audio": "original.mp4",
  "pre_ms": 150,
  "post_ms": 150,
  "segments": [
    {
      "id": "u0001",
      "start_frame": 25,
      "end_frame": 75,
      "zh_audio": "tts/u0001.wav",
      "en": "This is the first example.",
      "zh": "这是第一个例子。"
    }
  ]
}
```

```bash
python3 timeline_demo.py manifest.json --out result_run --fps 25 --burn --font "PingFang SC"
```

`start_frame` / `end_frame` 是视频归一化为指定帧率后的帧索引，使用左闭右开区间。不要直接把 SRT 行结束时间当作不会切断语音的边界。`end_frame` 是经过人工准备或独立对齐模块确认的安全插入点；原型不会自行识别讲话边界。

`clean_video` 与 `original_audio` 必须来自同一源、起点和时长对齐。只有一个视频时，`original_audio` 可省略。每个中文文件只包含那一句需要插入的配音。音频长度由脚本解码后测量，不信任手填时长。原片的开头、句间间隔、结尾都按视频归一化时间范围保留；AAC 等编码尾部填充不额外延长视频。

## 已实现与限制

已实现：顺序英文/中文插入、中文时段定格、双语 ASS、空白插入音床、输入基本校验、无损中间文件、最终编码、结构 QA。字幕字体由参数指定，不是自动匹配原字体。

原型只覆盖整数 24 / 25 / 30 / 50 / 60 fps、SDR、近零起始 PTS、48 kHz 双声道 16-bit PCM 工作格式、单一原音轨、非重叠语句。源音视频必须在一帧范围内对齐。字幕脚本使用 ASS 百分之一秒精度，无法代表比该精度更细的展示时刻。

不覆盖：HDR、原生 VFR 精确映射、29.97/23.976 有理数帧率、多路重叠说话、字幕自动换行质量检查、音色/语义质量、自动字幕区域检测、背景声自然延续。长视频高效分块、断点恢复和所有 AI worker 仍需按设计实现。

为便于检查，该原型按段解码并生成 FFV1 文件，磁盘占用大、长视频效率低；这是正确性验证实现，不是高吞吐生产渲染器。真实流水线应使用索引/单向解码和分块检查点。

## 来源与状态

研究来自项目 README、实际源文件及官方文档，详见设计文档来源表。第三方代码没有打包，第三方许可证与权重必须分别核查。示例脚本为本次生成代码；不代表上游已实现本设计。
