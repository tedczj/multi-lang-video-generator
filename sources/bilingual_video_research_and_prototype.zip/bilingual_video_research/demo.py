"""Generate test signals and verify exact frame/PCM placement.

The tones are NOT speech or cloned voices. Only timeline/composition is tested.
Uses a new, empty output directory; never deletes an existing run.
"""
from __future__ import annotations
import argparse
import json
import wave
from pathlib import Path
from timeline_demo import run, compose


def frame_hashes(path: Path) -> list[str]:
    raw = run(['ffmpeg', '-v', 'error', '-i', str(path), '-map', '0:v:0', '-f', 'framemd5', '-'])
    return [line.split(',')[-1].strip() for line in raw.splitlines()
            if line.strip() and not line.startswith('#')]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path('demo_output'))
    parser.add_argument('--font', default='Noto Sans CJK SC')
    parser.add_argument('--no-burn', action='store_true')
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists() and any(out.iterdir()):
        raise ValueError('Use a new, empty --out directory')
    out.mkdir(parents=True, exist_ok=True)
    work = out / 'assets'
    work.mkdir()
    run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc2=size=640x360:rate=25:duration=6',
         '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000:duration=6',
         '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', str(work / 'source.mp4')])
    for name, freq, duration in [('a', 800, 1.2), ('b', 1100, .8)]:
        run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i',
             f'sine=frequency={freq}:sample_rate=48000:duration={duration}',
             '-ac', '2', '-c:a', 'pcm_s16le', str(work / f'{name}.wav')])
    manifest = dict(clean_video='source.mp4', original_audio='source.mp4', segments=[
        dict(id='a', start_frame=10, end_frame=50, zh_audio='a.wav', en='First example.', zh='第一个示例。'),
        dict(id='b', start_frame=65, end_frame=120, zh_audio='b.wav', en='Second example.', zh='第二个示例。')])
    (work / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    rendered = out / 'rendered'
    qa = compose(work / 'manifest.json', rendered, burn=not args.no_burn, font=args.font)
    p = json.loads((rendered / 'timeline.json').read_text())
    with wave.open(str(rendered / 'master.wav'), 'rb') as w:
        master = w.readframes(w.getnframes())
    with wave.open(str(rendered / 'source_audio.wav'), 'rb') as w:
        source = w.readframes(w.getnframes())
    spf = p['samples_per_frame']
    for e in p['events']:
        dst = e['output_start_frame'] * spf * 4
        if e['kind'] == 'original':
            begin = e['source_start_frame'] * spf * 4
            end = e['source_end_frame'] * spf * 4
            expected = source[begin:end]
            expected += b'\0' * (end - begin - len(expected))
            if master[dst:dst + end - begin] != expected:
                raise AssertionError('Original PCM changed or misplaced')
        else:
            lead = e['pre_samples'] * 4
            if master[dst:dst + lead] != b'\0' * lead:
                raise AssertionError('Leading pad is not silence')
            with wave.open(str(rendered / e['zh_audio']), 'rb') as w:
                zh = w.readframes(w.getnframes())
            if master[dst + lead:dst + lead + len(zh)] != zh:
                raise AssertionError('Inserted PCM changed or misplaced')
            tail = (e['post_samples'] + e['round_pad_samples']) * 4
            if master[dst + lead + len(zh):dst + lead + len(zh) + tail] != b'\0' * tail:
                raise AssertionError('Trailing pad is not silence')
    source_frames = frame_hashes(rendered / 'source_video.mkv')
    expected_frames = []
    for e in p['events']:
        if e['kind'] == 'original':
            expected_frames.extend(source_frames[e['source_start_frame']:e['source_end_frame']])
        else:
            expected_frames.extend([source_frames[e['hold_source_frame']]] *
                                   (e['output_end_frame'] - e['output_start_frame']))
    if frame_hashes(rendered / 'master.mkv') != expected_frames:
        raise AssertionError('Source/hold frame mapping differs from plan')
    qa['checks']['original_and_inserted_pcm_exact'] = True
    qa['checks']['source_and_hold_frame_hashes_exact'] = True
    qa['note'] = 'Exact comparisons apply to lossless normalized masters, not to final H.264/AAC bitstreams.'
    (rendered / 'qa.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(qa, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
