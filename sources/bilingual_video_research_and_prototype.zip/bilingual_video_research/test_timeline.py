import random
import unittest
from timeline_demo import make_plan, safe_ass_text, SR

class TimelineTests(unittest.TestCase):
    def example(self):
        return [{'id':'a','start_frame':10,'end_frame':50,'zh_samples':57600},
                {'id':'b','start_frame':65,'end_frame':120,'zh_samples':38400}]
    def test_duration_and_order(self):
        p=make_plan(150,25,self.example())
        self.assertEqual(p['output_frames'],216)
        self.assertEqual([x['kind'] for x in p['events']],['original','insert','original','insert','original'])
        self.assertEqual(p['expected_output_samples'],414720)
    def test_preserve_intro_gap_outro(self):
        p=make_plan(150,25,self.example())
        spans=[(x['source_start_frame'],x['source_end_frame']) for x in p['events'] if x['kind']=='original']
        self.assertEqual(spans,[(0,50),(50,120),(120,150)])
    def test_subtitle_mapping(self):
        p=make_plan(150,25,self.example())
        self.assertEqual([(x['output_start_frame'],x['output_end_frame']) for x in p['subtitles']],[(10,88),(103,186)])
    def test_overlap_rejected(self):
        s=self.example();s[1]['start_frame']=49
        with self.assertRaises(ValueError):make_plan(150,25,s)
    def test_duplicate_rejected(self):
        s=self.example();s[1]['id']='a'
        with self.assertRaises(ValueError):make_plan(150,25,s)
    def test_empty_audio_rejected(self):
        s=self.example();s[1]['zh_samples']=0
        with self.assertRaises(ValueError):make_plan(150,25,s)
    def test_zero_start_and_last_frame(self):
        p=make_plan(25,25,[dict(id='a',start_frame=0,end_frame=25,zh_samples=1)])
        self.assertEqual(p['events'][-1]['hold_source_frame'],24)
        self.assertEqual(p['events'][-1]['kind'],'insert')
    def test_unknown_fps_rejected(self):
        with self.assertRaises(ValueError):make_plan(150,29,self.example())
    def test_ass_text_not_executable(self):
        self.assertNotIn('{',safe_ass_text(r'{\pos(1,2)}hello'))
    def test_randomized_invariants(self):
        rng=random.Random(42)
        for _ in range(250):
            fps=rng.choice([24,25,30,50,60]);total=2000;cursor=0;s=[]
            for i in range(20):
                start=cursor+rng.randint(0,8);end=start+rng.randint(1,30)
                s.append(dict(id=str(i),start_frame=start,end_frame=end,zh_samples=rng.randint(1,SR*10)))
                cursor=end
            p=make_plan(total,fps,s);src=out=0
            for e in p['events']:
                self.assertEqual(e['output_start_frame'],out)
                length=e['output_end_frame']-out;self.assertGreater(length,0)
                if e['kind']=='original':
                    self.assertEqual(e['source_start_frame'],src);src=e['source_end_frame']
                else:
                    self.assertEqual(length*p['samples_per_frame'],e['pre_samples']+e['zh_samples']+e['post_samples']+e['round_pad_samples'])
                out=e['output_end_frame']
            self.assertEqual(src,total);self.assertEqual(out,p['output_frames'])

if __name__=='__main__':unittest.main()
