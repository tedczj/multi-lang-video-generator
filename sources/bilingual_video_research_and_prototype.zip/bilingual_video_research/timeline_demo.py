#!/usr/bin/env python3
"""Deterministic EN-then-ZH timeline proof, NOT an AI dubbing application.

Input: clean, zero-start SDR video + time-synchronous source audio + prepared
Chinese WAV clips. Uses only Python stdlib and FFmpeg/FFprobe. Intermediate
video is FFV1, intermediate audio is 48 kHz stereo signed 16-bit PCM.
"""
from __future__ import annotations
import argparse
import json
import shutil
import subprocess
import wave
from pathlib import Path
from typing import Any

SR = 48_000

def run(args: list[str], cwd: Path | None = None) -> str:
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {args!r}\n{result.stderr[-8000:]}")
    return result.stdout

def probe(path: Path, count: bool = False) -> dict[str, Any]:
    args = ['ffprobe', '-v', 'error']
    if count:
        args += ['-count_frames']
    return json.loads(run(args + ['-show_streams', '-show_format', '-of', 'json', str(path)]))

def make_plan(total_frames: int, fps: int, segments: list[dict[str, Any]],
              pre_ms: int = 150, post_ms: int = 150) -> dict[str, Any]:
    """All source intervals are half-open. Every source frame is used once."""
    if fps not in (24, 25, 30, 50, 60):
        raise ValueError('Proof supports only fps=24,25,30,50,60; production must handle rational/VFR PTS.')
    if not isinstance(total_frames, int) or total_frames <= 0:
        raise ValueError('total_frames must be a positive integer')
    if min(pre_ms, post_ms) < 0 or not segments:
        raise ValueError('Pads must be nonnegative and segments cannot be empty')
    spf = SR // fps
    pre, post = SR * pre_ms // 1000, SR * post_ms // 1000
    ids: set[str] = set()
    events: list[dict[str, Any]] = []
    cues: list[dict[str, Any]] = []
    src_cursor = out_cursor = prior_end = 0
    for seg in segments:
        sid = str(seg['id'])
        start, end, n = seg['start_frame'], seg['end_frame'], seg['zh_samples']
        if sid in ids:
            raise ValueError(f'Duplicate id: {sid}')
        ids.add(sid)
        if any(type(x) is not int for x in (start, end, n)):
            raise ValueError('Frame boundaries and audio sample counts must be integers')
        if not (0 <= start < end <= total_frames) or start < prior_end or n <= 0:
            raise ValueError(f'Invalid, unsorted or overlapping segment: {sid}')
        shift = out_cursor - src_cursor
        length = end - src_cursor
        events.append(dict(kind='original', source_start_frame=src_cursor,
                           source_end_frame=end, output_start_frame=out_cursor,
                           output_end_frame=out_cursor + length))
        out_cursor += length
        extra = (pre + n + post + spf - 1) // spf
        events.append(dict(kind='insert', id=sid, hold_source_frame=end - 1,
                           output_start_frame=out_cursor, output_end_frame=out_cursor + extra,
                           pre_samples=pre, zh_samples=n, post_samples=post,
                           round_pad_samples=extra * spf - pre - n - post,
                           zh_audio=seg.get('zh_audio', '')))
        cues.append(dict(id=sid, output_start_frame=start + shift,
                         output_end_frame=out_cursor + extra,
                         en=seg.get('en', ''), zh=seg.get('zh', '')))
        out_cursor += extra
        src_cursor, prior_end = end, end
    if src_cursor < total_frames:
        events.append(dict(kind='original', source_start_frame=src_cursor,
                           source_end_frame=total_frames, output_start_frame=out_cursor,
                           output_end_frame=out_cursor + total_frames - src_cursor))
        out_cursor += total_frames - src_cursor
    return dict(schema_version=1, scope='timeline_proof_only', fps=fps, sample_rate=SR,
                samples_per_frame=spf, source_frames=total_frames, output_frames=out_cursor,
                expected_output_samples=out_cursor * spf, events=events, subtitles=cues)

def ass_time(frame: int, fps: int) -> str:
    # ASS has centisecond timing; quantize only at serialization.
    cs = round(frame * 100 / fps)
    return f'{cs // 360000}:{cs // 6000 % 60:02}:{cs // 100 % 60:02}.{cs % 100:02}'

def safe_ass_text(text: str) -> str:
    # Treat input as plain text, never as ASS override code.
    return str(text).replace('\\', '／').replace('{', '｛').replace('}', '｝').replace('\r', '').replace('\n', r'\N')

def write_ass(path: Path, plan: dict[str, Any], width: int, height: int, font: str) -> None:
    if any(ch in font for ch in ',\n\r{}'):
        raise ValueError('Unsafe font family')
    size = max(16, round(height * .058))
    en_y, zh_y = round(height * .82), round(height * .92)
    header = f'''[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: English,{font},{size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,20,20,15,1
Style: Chinese,{font},{size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,20,20,15,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
    rows = []
    for cue in plan['subtitles']:
        start, end = ass_time(cue['output_start_frame'], plan['fps']), ass_time(cue['output_end_frame'], plan['fps'])
        for lang, style, y in [('en', 'English', en_y), ('zh', 'Chinese', zh_y)]:
            text = safe_ass_text(cue[lang])
            if text:
                rows.append(f'Dialogue: 0,{start},{end},{style},,0,0,0,,{{\\an2\\pos({width//2},{y})}}{text}')
    path.write_text(header + '\n'.join(rows) + '\n', encoding='utf-8')

def pcm(path: Path, target: Path) -> int:
    run(['ffmpeg', '-v', 'error', '-y', '-i', str(path), '-map', '0:a:0', '-vn',
         '-ar', str(SR), '-ac', '2', '-c:a', 'pcm_s16le', str(target)])
    with wave.open(str(target), 'rb') as audio:
        return audio.getnframes()

def copy_samples(src: wave.Wave_read, dst: wave.Wave_write, start: int, length: int) -> None:
    src.setpos(start)
    while length:
        block = src.readframes(min(length, SR))
        got = len(block) // 4
        if not got:
            raise ValueError('Unexpected truncated source audio')
        dst.writeframesraw(block)
        length -= got

def write_silence(dst: wave.Wave_write, length: int) -> None:
    while length:
        n = min(length, SR)
        dst.writeframesraw(b'\0' * n * 4)
        length -= n

def compose(manifest_path: Path, output: Path, fps: int = 25,
            burn: bool = False, font: str = 'Noto Sans CJK SC') -> dict[str, Any]:
    if fps not in (24, 25, 30, 50, 60):
        raise ValueError('Unsupported fps for this proof')
    for exe in ('ffmpeg', 'ffprobe'):
        if not shutil.which(exe):
            raise RuntimeError(f'{exe} not found on PATH')
    if output.exists() and any(output.iterdir()):
        raise ValueError('Output directory must be empty, to avoid overwriting or mixing runs')
    output.mkdir(parents=True, exist_ok=True)
    output = output.resolve()
    data = json.loads(manifest_path.read_text(encoding='utf-8'))
    base = manifest_path.resolve().parent
    def local(value: str) -> Path:
        path = Path(value)
        return (path if path.is_absolute() else base / path).resolve(strict=True)
    video, audio_source = local(data['clean_video']), local(data.get('original_audio', data['clean_video']))
    audio_info = probe(audio_source)
    audio_streams = [s for s in audio_info['streams'] if s['codec_type'] == 'audio']
    if not audio_streams or abs(float(audio_streams[0].get('start_time', '0'))) > 1 / fps:
        raise ValueError('Proof requires a near-zero-start synchronized source audio track')
    info = probe(video)
    v = next(s for s in info['streams'] if s['codec_type'] == 'video')
    if abs(float(v.get('start_time', '0'))) > 1 / fps:
        raise ValueError('Proof requires near-zero video start PTS; normalize offsets first')
    if v.get('color_transfer') in ('smpte2084', 'arib-std-b67'):
        raise ValueError('HDR input is outside this SDR proof; perform explicit color-managed conversion first')
    normalized = output / 'source_video.mkv'
    run(['ffmpeg', '-v', 'error', '-y', '-i', str(video), '-map', '0:v:0', '-an',
         '-vf', f'fps={fps},setpts=PTS-STARTPTS,format=yuv420p', '-r', str(fps),
         '-fps_mode', 'cfr', '-c:v', 'ffv1', str(normalized)])
    nv = next(s for s in probe(normalized, True)['streams'] if s['codec_type'] == 'video')
    total = int(nv['nb_read_frames'])
    source_audio = output / 'source_audio.wav'
    ns = pcm(audio_source, source_audio)
    samples_per_frame = SR // fps
    if abs(ns - total * samples_per_frame) > samples_per_frame:
        raise ValueError('Source audio/video duration differs by more than one frame; input must be aligned')
    segs = []
    for idx, seg in enumerate(data['segments']):
        s = dict(seg)
        path = output / f'zh_{idx:04}.wav'
        s['zh_samples'] = pcm(local(s['zh_audio']), path)
        s['zh_audio'] = path.name
        # Frame indexes are supplied, not inferred from subtitle text.
        segs.append(s)
    plan = make_plan(total, fps, segs, data.get('pre_ms', 150), data.get('post_ms', 150))
    (output / 'timeline.json').write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
    write_ass(output / 'bilingual.ass', plan, int(nv['width']), int(nv['height']), font)
    parts = []
    master = output / 'master.wav'
    with wave.open(str(source_audio), 'rb') as source, wave.open(str(master), 'wb') as dst:
        dst.setnchannels(2); dst.setsampwidth(2); dst.setframerate(SR)
        for idx, event in enumerate(plan['events']):
            count = event['output_end_frame'] - event['output_start_frame']
            part = output / f'part_{idx:04}.mkv'
            if event['kind'] == 'original':
                begin = event['source_start_frame']
                args = ['-i', str(normalized), '-frames:v', str(count),
                        '-vf', f'trim=start_frame={begin}:end_frame={begin + count},setpts=N/({fps}*TB)']
                begin_sample, needed = begin * samples_per_frame, count * samples_per_frame
                available = max(0, min(needed, ns - begin_sample))
                if available:
                    copy_samples(source, dst, begin_sample, available)
                write_silence(dst, needed - available)
            else:
                begin = event['hold_source_frame']
                args = ['-i', str(normalized),
                        '-vf', f'trim=start_frame={begin}:end_frame={begin + 1},loop=loop={count-1}:size=1:start=0,setpts=N/({fps}*TB)',
                        '-frames:v', str(count)]
                write_silence(dst, event['pre_samples'])
                with wave.open(str(output / event['zh_audio']), 'rb') as zh:
                    copy_samples(zh, dst, 0, event['zh_samples'])
                write_silence(dst, event['post_samples'] + event['round_pad_samples'])
            run(['ffmpeg', '-v', 'error', '-y'] + args + ['-an', '-r', str(fps), '-fps_mode', 'cfr', '-c:v', 'ffv1', str(part)])
            parts.append(part)
    (output / 'concat.txt').write_text(''.join(f"file '{p.name}'\nduration {(e['output_end_frame'] - e['output_start_frame']) / fps:.9f}\n" for p, e in zip(parts, plan['events'])), encoding='utf-8')
    run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '1', '-i', 'concat.txt',
         '-i', 'master.wav', '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy',
         '-c:a', 'pcm_s16le', 'master.mkv'], cwd=output)
    args = ['ffmpeg', '-v', 'error', '-y', '-i', 'master.mkv']
    if burn:
        args += ['-vf', 'ass=bilingual.ass']
    run(args + ['-map', '0:v:0', '-map', '0:a:0', '-c:v', 'libx264', '-crf', '18',
                '-preset', 'veryfast', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', 'result.mp4'], cwd=output)
    final = probe(output / 'result.mp4', True)
    fv = next(s for s in final['streams'] if s['codec_type'] == 'video')
    fa = next(s for s in final['streams'] if s['codec_type'] == 'audio')
    with wave.open(str(master), 'rb') as w:
        actual_samples = w.getnframes()
    run(['ffmpeg', '-v', 'error', '-xerror', '-i', str(output / 'result.mp4'), '-f', 'null', '-'])
    checks = dict(video_frames=int(fv['nb_read_frames']) == plan['output_frames'],
                  master_audio_samples=actual_samples == plan['expected_output_samples'],
                  av_duration_difference=abs(float(fv['duration']) - float(fa['duration'])) <= 1 / fps,
                  full_decode=True)
    qa = dict(scope='structural_timeline_only', status='PASS' if all(checks.values()) else 'FAIL',
              checks=checks, output_duration_seconds=plan['output_frames'] / fps,
              output_frames=int(fv['nb_read_frames']), master_audio_samples=actual_samples,
              not_tested=['OCR', 'subtitle removal', 'font matching', 'translation',
                          'ASR', 'voice cloning', 'semantic or perceptual quality'])
    (output / 'qa.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    if qa['status'] != 'PASS':
        raise RuntimeError(f'Structural validation failed: {qa}')
    return qa

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('manifest', type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--fps', type=int, default=25)
    p.add_argument('--burn', action='store_true', help='Needs an installed CJK-capable font; no fonts are bundled')
    p.add_argument('--font', default='Noto Sans CJK SC')
    a = p.parse_args()
    print(json.dumps(compose(a.manifest, a.out, a.fps, a.burn, a.font), ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
