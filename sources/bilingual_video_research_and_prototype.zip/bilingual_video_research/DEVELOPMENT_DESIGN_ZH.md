# 本地视频硬字幕清理、双语重排与英文/中文交替配音：研究及开发设计

研究基准日：2026-09-10。来源为公开仓库 README、实现文件和官方文档。上游 `main` 会变化，应在实际开发时锁定 commit 和模型 revision。本次没有下载并跑通全部 AI 项目；已完成的运行验证只有附带的时间线/合成原型。本文将“上游现有能力”“建议新增功能”“本次已测试实现”分开陈述。

## 1. 结论和选型

在本次核查的项目中，没有找到已验证完整满足以下组合的一键项目：硬字幕提取并去除、恢复原英文字体/风格、双语重排、同音色中文逐句追加而不是替换英文、无人值守综合质量检查。

建议选 **pyVideoTrans + VSE/VSR + 自建 Interleave Composer/QA**。不是从零写 ASR、翻译、声音克隆或修复模型，也不是简单把一个“配音语言”开关改成中文。

| 项目 | 可复用部分 | 与本需求的缺口 / 核查结论 |
|---|---|---|
| pyVideoTrans | 本地视频、识别、翻译、克隆配音后端、分角色、双语字幕、CLI/流水线 | 需要增加“原英文保留 + 中文延长时间线”的独立后半段；没有核实完整硬字幕修复/原字体识别/综合 QA 流程。[R01–R06] |
| VideoLingo | 语义分句、术语和翻译流程、WhisperX、TTS 扩展 | 可作为 Apache-2.0 基座备选；当前 README 把多角色单独配音列为限制，默认后处理以原时长对齐为目标。[R07–R10] |
| Linly-Dubbing | ASR、翻译、声音克隆、人声分离和相关模块集成 | 广播式翻译配音更接近其主线；没有核实逐句交替、原字体恢复及完整无人值守验收。[R11] |
| VSE + VSR | 硬字幕 OCR/SRT 提取，字幕区域检测及修复 | 是独立预处理模块，不是翻译/交替配音成品。SRT 之外还需导出字框、掩码、样式和置信度。[R12–R13] |
| Dub Studio | 识别/翻译/克隆、屏幕文字定位和匹配风格覆盖的设计 | 当前以 Windows 本地原生应用为目标；屏幕文字采用 OCR→blur→overlay，不等于背景修复；voiceover 也不等于每句后插入中文。[R14] |
| OpenCreator（原 KrillinAI） | 本地视频翻译、字幕、声音相关工作流 | 当前已扩展成更大的创作/代理工作台，引入整个框架不是这里的最小改动路线。[R15] |

默认选 pyVideoTrans 是工程复用判断，不是经过同一数据集跑分后的质量排名。现有翻译/声音处理阶段保留，时间线后半段另走新模式，避免破坏上游原有替换配音功能。

许可证：pyVideoTrans 为 GPL-3.0；VideoLingo、Linly-Dubbing、VSE/VSR 仓库标示 Apache-2.0；Dub Studio 的应用代码标示 MIT。必须继续检查依赖和权重。特别是 ProPainter 的代码及权重采用 S-Lab 非商业许可，不能因为 VSR 外层 Apache-2.0 就推断其中所有算法均可直接商用。[R01,R07,R11–R14,R16] 进程隔离用于依赖和故障隔离，不构成许可证豁免。

## 2. 需求边界：先消除不可满足的隐含假设

### 2.1 硬字幕不是一个可无损分离的图层

先运行 ffprobe，检查字幕流、音频流、色彩信息、起始时间、时基、帧率和旁挂字幕文件。软字幕可以抽取/取消显示；已烧入画面的硬字幕覆盖了背景像素，去字是修复推断，不承诺恢复真实原背景。VSR 所称保持分辨率，不代表被遮挡的背景信息可无损恢复。[R13,R17]

优先使用已有 ASS/SRT/VTT 或容器字幕作为文本来源。硬字幕必须先提取文字、位置、时间、样式参考，再去除；不能先擦除再识别。存在软字幕和硬字幕两套时分别检测，不以“有字幕流”断言没有烧字。

### 2.2 原字体与中文覆盖范围是两回事

有 ASS/字体元数据时优先读取。只剩像素时，精确识别字体名称无法保证；可对有限、合法的字体库进行渲染匹配，输出 top-k 和匹配置信度，而不是让视觉模型随口给一个确定字体名。字体识别研究本身也是候选分类/匹配问题。[R18]

即便识别出英文字体，该文件也可能没有中文字形。英文尽量用原字体；中文使用同字体家族的 CJK 成员或风格相近、可用的中文字体，继承字重、字号视觉高度、描边、阴影、颜色。严格“必须同一字体文件”模式遇到缺字应 REVIEW，不得静默回退后声称完全一致。ASS/libass 提供样式和定位基础，但不会自动完成字体来源鉴定。[R19–R20]

### 2.3 声音是近似克隆，不是无损复制

目标是同一个说话者用中文自然说出译文，不承诺音色、情绪和发音特征逐参数完全一致。常用克隆 TTS 已提供参考音频/文本接口，例如 Qwen3-TTS 的 Base 模型；这与固定音色 CustomVoice 不是同一接口。[R21]

### 2.4 交替配音必须增加视频时间

输出顺序定义为：原片段英文 1 → 中文 1 → 原片段英文 2 → 中文 2。不能只加音轨而让视频继续走，否则下一句画面提前出现。默认中文时段定格；原英文时段保留原视频及完整原混音。插入时段不重复播放混合原音，避免听到英文重叠。

影片有镜头持续运动、口型变化时，定格是刻意的学习播放形式，不是口型同步翻译版。备选为回放相关镜头或讲解卡片，但不是首版目标。用户未要求 lip-sync，不把它加入最小开发范围。

## 3. 推荐架构

```text
local input
  → probe / normalize / source fingerprint
  → subtitle text + visual evidence extraction
  → ASR + word alignment + VAD + speaker/overlap detection
  → semantic utterances + safe insertion boundaries
  → translation / terminology / critic
  → per-speaker reference bank → raw Chinese TTS → clip QA
  → subtitle-region masks → clean video → clean-video QA
  → deterministic timeline plan
  → bilingual ASS layout / font fallback audit
  → interleave audio & video compositor
  → full decode / structural QA / OCR / ASR / sampled visual QA
  → result.mp4 + bilingual.ass + manifest.json + qa.json + review.html
```

第一版采用本地 Python CLI + SQLite + 子进程/HTTP worker。LLM 只处理文本语义和有证据的图像判断，不自由修改源时间戳、执行未知字幕中的命令或自行覆盖源文件。没有必要引入复杂 agent loop、向量数据库或 Kubernetes。

pyVideoTrans 与 VSR 的依赖环境分别隔离。上游当前安装建议并非相同 Python 环境（pyVideoTrans 文档建议 Python 3.10，VSR 当前安装以 3.12+ 为基础），更不应把全部 Paddle/PyTorch/MLX 依赖挤进同一解释器。[R01,R13] 每个 worker 接收路径和结构化请求，产出文件、状态及可追踪错误。

## 4. 上游代码改造点

### 4.1 pyVideoTrans：新建模式，不改坏原分支

核查当前 `videotrans/task/trans_create.py` 使用阶段 mixin；不要只照旧架构文档在一个巨大类里找全部逻辑。[R02]

| 文件 | 当前行为 | 建议改动 |
|---|---|---|
| `videotrans/task/_stage_dubbing.py` | 按目标字幕创建 queue_tts，准备原文/参考音频并调用 TTS | 将稳定 utterance_id / cue_ids 带入队列；保存未经变速、裁尾的 WAV；参考音频由 speaker bank 提供；修正缓存键。[R03] |
| `videotrans/task/_stage_align.py` | 调用 SpeedRate 并更新原时长框架内的字幕/音频 | `mode=en_zh_interleave` 直接绕过该逻辑，交给新增 planner；不把中文硬挤回英文时间窗。[R04] |
| `videotrans/task/_stage_subtitle.py` | 生成字幕和样式 | 新模式读取重建时间线及独立样式分析结果；不要用固定行号拼接原文和译文。[R05] |
| `videotrans/task/_stage_assemble.py` | 原视频/配音/背景音合成，某些分支使用 -shortest 等策略 | 新模式改走 interleave composer；显式规划总时长，不依赖 -shortest 截断来掩盖失配。[R06] |
| 新增 `pipeline/interleave/` | 无本项目实现 | 放置 schema、planner、compositor、layout 和 qa；不把这些逻辑散落在 GUI 回调。 |

伪代码（**拟新增接口，不是上游已有参数**）：

```python
if cfg.output_mode == "en_zh_interleave":
    raw_clips = dubbing_stage.generate_unaligned(utterances, speaker_bank)
    raw_clips = qa_stage.validate_and_retry(raw_clips, max_retries=2)
    plan = interleave_planner.build(source, utterances, raw_clips)
    result = interleave_composer.render(clean_video, original_audio, raw_clips, plan)
    return qa_stage.validate_final(result, plan)
else:
    return existing_replace_dubbing_pipeline()
```

一个特别需要修补的静态源码风险：当前配音全局缓存键含目标语言、目标文字、voice/rate/volume/pitch/tts_type，但不包含实际参考音频哈希。`voice="clone"` 时，不同视频同一句译文可能命中相同键，存在错用音色缓存的路径。这里是静态风险判断，并非声称已观察到真实事故。[R03]

建议缓存键：

```text
SHA256(normalized_zh_text + source_speaker_id + target_language
       + SHA256(reference_pcm) + exact_reference_transcript
       + model_repository + model_revision + adapter_version
       + generation_parameters + seed + normalization_version)
```

音色参考或模型改变必须使相应中文音频失效；任意音频长度改变必须重新规划整条后续时间线。

### 4.2 VideoLingo 备选的具体边界

`core/_10_gen_audio.py` 可复用原始 TTS 生成，但随后有变速对齐流程，末尾超出容许窗口 0.6 秒以内时存在直接裁掉末段音频的分支；不能原样用于完整保留中文的交替模式。[R08]

`core/_11_merge_audio.py` 使用 16 kHz 单声道、64 kbps MP3 中间步骤，并按其配音任务时间戳填空白；这不是保留原英文的 48 kHz 主时间线。[R09] `core/_12_dub_to_vid.py` 的字体基于平台预设，而非识别画面原字体。[R10] 因此选择它也需更换后半段，不能靠改一行 FFmpeg amix 达到本需求。

## 5. 核心数据协议

不把 SRT 行号当主键。保存以下独立对象：

- `CaptionCue`：画面上实际看到的一次字幕事件，含来源、文本、时间、字框、样式、OCR 置信度。
- `Utterance`：完整语义/安全语音切分单元，可对应多个 cue，含 speaker_id、对齐单词、重叠标记。
- `VoiceReference`：准确转写、参考音频路径/哈希、说话者、场景、质量分。
- `DubClip`：中文原文、WAV 路径、采样率/采样数、模型 revision、QA 结果。
- `TimelineEvent`：原始区间或插入区间、源时间范围、输出范围、冻结参考帧和具体音源。

示例（数值仅展示结构）：

```json
{
  "id": "u000012",
  "cue_ids": ["c000018", "c000019"],
  "speaker_id": "spk_01",
  "source": {
    "start_us": 12500000,
    "speech_end_us": 14920000,
    "safe_cut_us": 15000000,
    "original_text": "I think we should try again.",
    "text_source": "hard_sub_ocr",
    "source_text_sha256": "<computed>"
  },
  "translation": {
    "zh_display": "我觉得我们应该再试一次。",
    "zh_spoken": "我觉得我们应该再试一次。",
    "glossary_revision": 1,
    "status": "PASS"
  },
  "reference": {
    "speaker_id": "spk_01",
    "path": "speakers/spk_01/ref_scene03.wav",
    "pcm_sha256": "<computed>",
    "transcript": "<verbatim reference-audio transcript>"
  },
  "dub": {
    "path": "tts/u000012.wav",
    "sample_rate": 48000,
    "samples": 134400,
    "model_revision": "<pinned revision>",
    "status": "PASS"
  }
}
```

原字幕与说话内容不一致时保留两者，不静默把字幕替换成 ASR。剪辑字幕、屏幕标语、静音文字与对白分别分类。源字幕缺词、OCR 与 ASR 在实体/否定词上冲突时进入 REVIEW；上下文辅助只能生成修正建议及证据。

## 6. 每个阶段如何实现和验证

### 6.1 探测和归一化

```bash
ffprobe -v error -show_streams -show_format -of json input.mp4 > probe.json
```

保留源文件只读。以 SHA256 创建 job。记录音轨/字幕流选择、source PTS→working PTS 映射、旋转信息、色彩/HDR、帧率和像素宽高比。生产版支持有理数帧率；MVP 遇到 HDR、多音轨歧义、非零起点未处理等输入明确拒绝或 REVIEW，不能默默裁音或转色。音频工作格式建议 48 kHz PCM，语音模型所需采样率单独生成派生输入。

### 6.2 字幕提取与安全掩码

先选字幕流/旁挂文件；确实为硬字幕才调用 VSE。让 OCR 输出时间窗口与字框轨迹，跨帧多数投票稳定文字，保留原始帧引用和置信度。检测任务必须区分对白字幕、角标、幻灯片文字和场景标牌。

固定字幕带可配置一次 ROI；完全无人干预模式先自动搜索稳定的“短时改变文字带”，评估其置信度后运行。低置信度则 REVIEW，而不是默认全屏擦字。动态字幕使用逐时段掩码，描边/阴影加自适应膨胀，不能全程固定大矩形模糊。

VSR 当前 CLI 的一个可核查例子（坐标顺序是 YMIN YMAX XMIN XMAX）：

```bash
python backend/main.py -i input.mp4 -o clean.mp4 \
  --subtitle-area-coords 850 1050 100 1820 \
  --inpaint-mode sttn-det
```

以上坐标只适用于对应分辨率下的示例，必须用真实 OCR/ROI 替换。VSR 会加载所选修复模型；该命令不是本包内置实现。[R13]

首版可让 VSR 自己在给定 ROI 中检测；质量版通过适配层导入逐帧外部掩码。是否支持后者需要按锁定源码补入口，不假设已有 `--mask-json` 参数。

修复只在字幕存在的时间和区域执行，按镜头分块并重叠上下文，拼接时处理边界。渲染前保留 clean-video QA：原字幕 OCR 残留、非目标文字损坏、遮罩边缘闪烁。实际背景被遮住时不存在真实答案，不能用“与原视频整幅 PSNR 下降”直接判失败。

### 6.3 对齐、说话者、完整句

ASR/强制对齐输出单词级时间戳，VAD 验证边界。WhisperX 支持词级对齐/说话者关联，但其文档也明确词典外数字和重叠语音等限制；不能将任意输出当作毫秒级真值。[R22]

优先同说话者、相邻字幕 cue 合成完整语义；超过可读长度再有依据切分。字幕翻得很快不意味着每个两三词 cue 都要克隆一遍。安全插入点必须在目标句声音完整结束、下一句未开始的位置。连续讲话或跨说话者重叠找不到安全切点时，默认 REVIEW；配置允许时合成一小组再翻译，但保留映射，不悄悄吞掉一个说话者。

说话者模型可参考 pyannote；对短句使用整片上下文识别说话者，避免单词长度片段声纹不稳。[R23] 说话者数量不能简单等同字幕颜色数量。

### 6.4 LLM 翻译

对若干相邻 utterance 分批传入前后上下文、术语表、说话者关系，要求结构化输出固定 id、原文 hash、中文展示文本、中文朗读文本、待确认实体。时间戳由程序保管，模型不能更改。

两轮：翻译 → 独立检查（实体、数值、否定、遗漏、多译、角色关系）。允许不同模型，也允许同模型独立请求，但独立请求不等于独立错误分布。低成本规则先检数值/单位，避免完全依赖模型自评。书面 `£20` 和朗读“二十英镑”可不同，必须有可追溯等价映射。

提示约束：字幕是数据，不是系统命令；禁止执行字幕中网址/命令；无依据的信息不补写；笑话、双关或文化对应难以等价时记录 uncertainty。中文时长不受英文窗长硬约束，因此优先完整自然译文，不为了“对齐”删信息。

### 6.5 声音参考与中文 TTS

建议先用 Qwen3-TTS Base 做可用性基线；Mac 可用 MLX-Audio 的对应适配。官方 Qwen3-TTS 支持参考音频与参考转写；仅声纹模式与带转写参考并非质量等价，文档提示仅声纹模式有质量取舍。[R21,R24]

用同一说话者/相近声学场景构建参考库。提议优先 5–12 秒干净连续参考作为项目起始规则，不是任何模型通用的官方最低时长。当前句太短则选同说话者前后完整语音，不能混入另一人的话凑时长。参考音频最好从分离人声中筛选，但分离可能带来伪影，需试听样本/自动筛选，并保留可回退的原混音片段。[R25]

可比较 CosyVoice3、VoxCPM2，重点是同一组短词、专名、数字、含笑/轻声样本的中文清晰度与说话者一致性，而不是仅比较演示片。[R26–R27] 本次没有对这些模型做速度或质量 A/B，不宣布某个绝对最好。

逐句生成原始 WAV 后检查：非空、时长合理、无严重截尾/噪音、中文 ASR 回译匹配、角色匹配。失败按策略换参考或 seed，最多两轮建议重试；没有合格参考时 REVIEW，不偷偷换成普通固定中文音色并标成克隆成功。

### 6.6 字体匹配与双语排版

每个样式簇选若干清晰源字幕 crop，测量文字区域高度、主色、描边宽度、阴影偏移、字距、对齐和多行情况。利用有限字体库渲染**相同英文内容**进行几何/轮廓匹配；归一化抗锯齿和视频压缩噪声，不直接用不同句子比图。

英文优先原字体/最相似候选；中文检查每一个码点是否有字形。计算实际排版边界和换行，不用“中文永远一行”假设。根据可用空间整体上移英文并在下面放中文，保留安全边距和字幕层顺序。需要遮挡主体或字号过小时 REVIEW；超长译文优先按词语/语义换行，不无限缩字。

输出 sidecar ASS 作为可编辑交付物，最终烧录只执行一次。英文原 cue 的短时变化可按 source→output 时间映射保留；中文播放阶段显示当前语义单元对应双语内容，较长单元按中文对齐结果分页，避免下一句英文提前出现。

## 7. 时间线：必须由程序确定，不能交给 LLM 猜

设原视频时长 T；第 i 个完整语句为 [s_i, e_i)，e_i 已包含安全切点处理；中文 WAV 解码实测时长 c_i；中文前后间隔 p、q。每个插入长度 h_i 为 (p+c_i+q) 向上补齐到工作帧边界。累计偏移 D_i = Σ(j<i) h_j。

```text
原英文 i： [s_i + D_i, e_i + D_i)
中文音频： [e_i + D_i + p, e_i + D_i + p + c_i)
画面定格： [e_i + D_i, e_i + D_i + h_i)
最终时长： T + Σ h_i
```

必须保留源区间 [0,e_1)、[e_1,e_2)、…、[e_n,T)。这包括片头、没有字幕的画面、原句间停顿和片尾；不要只把 ASR 识别到的句子拼在一起。

音频以整数采样计数，视频以有理数时基/帧 PTS 表示。补帧误差显式记录为 pad，而不是每句四舍五入后累积。最后检查样本总数和帧数。若字幕时基比视频粗，序列化误差单独记录和验收。

中文插入时：冻结清理后本句的安全帧；最小实现用安全切点前一帧。生产版在切点前有限窗口内选清晰、非闭眼/非跨场景的帧。不能取下一句已经出现的画面，也不能冻结仍带原硬字幕的帧。

原文段：保留完整原混音。中文段：中文 WAV + 可选 non-vocal room tone / 音乐床；绝不叠加同句英文混音。原版背景音乐会被延长/断接，需要独立音床策略；首版的纯静音音床是明确可接受的基础选项，不声称自然连续。淡入淡出只处理插入段音床边缘，不穿过原句辅音来掩盖错误切点。

最终编码禁用“靠 -shortest 保证有文件输出”的兜底。遇到时长差必须报错，不能静默裁掉最后中文或原片尾。FFmpeg 的 trim/atrim、时间戳重设、循环/拼接与 ASS 可实现底层处理，具体规划规则由本项目负责。[R28]

## 8. 无人值守 QA 与有界自动修复

自动化目标是筛查明显问题并生成可定位报告，不是承诺所有语义/审美问题都能发现。

| 层 | 检查对象 | 推荐办法 | 失败处理 |
|---|---|---|---|
| 结构 | 缺片、错序、丢片尾、缺音、解码失败 | 校验 manifest、全文件 decode、帧数/采样数/流时长、源区间覆盖一次 | FAIL，阻止成片标为完成 |
| 时间线 | 中文压住下一句、插入位置漂移、冻结长短错误 | 按 plan 检测片段边界，原音/插入音与主轨相关性或精确无损比对 | 重建 timeline/compose，不重新 OCR |
| 源文字 | OCR 漏字、错数值、把屏幕标牌当对白 | 多帧一致性、OCR–ASR 对照、字幕类型分类 | 重新 OCR / REVIEW |
| 翻译 | 漏译、数字单位、专名、否定翻反 | 结构化对齐 + 规则 + LLM critic | 限次重译 / REVIEW |
| 中文配音 | 漏读、多读、重复、语言错误、断词、静音 | 用独立 ASR 识别生成 WAV，对比 zh_spoken，检查首尾 VAD 和实体 | 换参考/seed 后重生；不能裁词过关 |
| 说话者 | 换人、混入另一声音、参考污染 | speaker embedding + 同人/异人标定数据 +参考内容核对 | 重选参考 / REVIEW |
| 去字幕 | 残字、抹掉其他字、边缘闪烁 | 在 clean video 上 OCR；检查 mask 外一致性；时间连续性及抽样视觉模型 | 调掩码/修复模式重做该镜头 |
| 排版 | 缺字方框、双影、字幕出界、重叠、错误字体回退 | 字体 cmap/实际渲染字形检查、layout bbox、帧级抽样 OCR | 换合法字体/重新布局 / REVIEW |
| 声音工程 | 过响、削波、音量跳跃 | 响度/峰值/片段统计、背景床边界检查 | 只规范化中文/插入床，保持原声策略可追踪 |
| 画面工程 | 意外黑帧、非预期冻结、镜头拼接闪烁 | 用 plan 区分合法冻结与异常；镜头边界附近多帧检查 | 重渲染该块 / REVIEW |

首版阈值是**项目拟定值，不是经本次真实视频校准的标准**：音画总时长差 ≤1 帧；所有源时间区间完整覆盖；中文关键数值/实体不能不一致；中文 ASR CER 在大于 10 字的干净样本上可从 ≤5% 候选通过、>10% 候选重试起步，中间和短句 REVIEW。必须先规范化数字/标点/口语等价表达，不能把识别模型自己的错字当 TTS 罪证。严重错语种/空音频直接 FAIL。

建议中文音频 true peak 不超过 -1 dBTP 作为输出策略起点；最终阈值和响度目标以目标平台及源声音量校准，不对所有素材直接全局归一化。声纹相似度不设置未经标定的“余弦 0.8 必定同人”；跨语言和音质差异会影响分布。

生成 `qa.json`：

```json
{
  "job_status": "REVIEW",
  "checks": [
    {
      "name": "dub_asr_entities",
      "utterance_id": "u000012",
      "status": "REVIEW",
      "expected": "二十英镑",
      "observed": "两英镑",
      "artifact": "qa/u000012.wav",
      "retry_count": 2
    }
  ]
}
```

检查状态用 PASS / REVIEW / FAIL / SKIPPED。需要的检查没装模型、执行异常或没有证据时不得填 PASS。未完成必要检查的总状态不能自动发布通过。`review.html` 展示时间戳、源 crop、修复 crop、双语文本、可点击试听和具体错误；无人介入可完成初筛，不要求用户逐句等确认才跑下去。

## 9. 缓存、恢复、安全和长视频

SQLite 保存 jobs、stage_runs、utterances、artifacts、qa_findings。阶段状态 PENDING/RUNNING/DONE/FAILED；发现遗留 RUNNING 使用锁/心跳识别过期执行后重试。中间文件先写 `.tmp`，校验后原子 rename；只有 DONE 的工件可被下游消费。

每个阶段缓存依赖输入文件哈希、参数、模型/代码 revision。中文译文改动只重做对应 TTS 与其后时间线；掩码改动只重做有关镜头 clean-video 与其后渲染。源视频变化从头创建 job，不混用路径同名的旧缓存。模型随机性记录 seed 但不承诺跨硬件位级复现。

生成与修复各阶段单独设置最大任务时长、最大句长、文件大小和重试次数。FFmpeg 用参数数组，不拼 shell；LLM/OCR 输出作为不可信文本转义 ASS。禁用读取字幕里指定的任意外部路径；输出限制在 job sandbox。远程模型 API 是可选 adapter；使用前明确是否发送文本、音频、图像，默认不把“本地工具”误当自动离线保证。

长视频生产渲染需要索引与分块：保持统一工作格式和帧索引，用单向解码或安全 seek 到关键帧后精确裁切；每块生成无损/高质量中间工件，最后统一编码/封装一次。不要让每一句从文件头完整重新解码。VSR 分块带相邻帧上下文，重叠区只输出一次，音画时间线用原全局索引。

## 10. Mac / NVIDIA 部署策略

在此前提到的 Apple Silicon /64 GB Mac 情景，优先本机 FFmpeg + MLX 语音 worker。MLX-Audio 仓库提供 Apple Silicon 的 TTS/STT，包括 Qwen3-TTS、ASR 和强制对齐相关能力；这是兼容路线依据，不是本次对具体机型的吞吐实测。[R24]

VSR 当前 README 列出 Apple Silicon 安装路线，但 OCR 和修复模型的硬件路径不同；“能安装”不表示每种模型都高效使用 MPS。先对 10–30 秒真实样本验证 CPU OCR/MPS 或其他可用修复组合，记录运行日志和显存/内存。必要时把 inpaint worker 移到局域网 NVIDIA 主机，其余保留在 Mac。[R13]

不要在 macOS Docker 中按 NVIDIA CUDA 路线部署后期待访问 Apple GPU；部署选择应围绕原生 MLX/MPS 环境而不是无差别复制 CUDA 命令。64 GB 统一内存也不等价于 64 GB NVIDIA 专用显存。第一版并发设为一个重模型 worker，OCR、TTS、修复分阶段执行，按实测再放开。本文不提供未经测量的“每分钟视频几分钟完成”承诺。

## 11. 可执行开发顺序和验收门

以下是待开发完整流水线的分段验收顺序，不是声称仓库已经包含这些命令。

### Gate A：时间线正确性（本包已经覆盖基础实现）

先用现成 clean video、人工/上游准备的安全边界、两段 WAV 验证。要求所有原始帧按源区间出现一次、插入帧正好来自指定 hold frame、原音 PCM 和插入 PCM 顺序精确，片头/间隙/片尾保留。包内命令：

```bash
python3 -m unittest -v test_timeline
python3 demo.py --out first_run --no-burn
```

### Gate B：TTS 接入（待实现）

同一说话者至少准备：单词、短句、普通句、数字金额、专名、长句、轻声/笑声。固定两种参考质量，比较同模型不同参考及两个后端。验收 ASR 内容、完整结尾和同一角色映射，不要求与英文时长相同。加入两个不同说话者说同一句中文的回归用例，确保缓存不串音色。

### Gate C：原字幕文字与清理（待实现）

先对本来无字幕的合法测试视频烧入已知字幕，保留 clean ground truth。覆盖固定白字/黑描边、多行、移动背景、切镜、无字幕间隔、字幕与人脸/衣服重叠、同屏非目标文字。用已知文字与掩码验证提取/残留；用干净真值评估修复，不能用纯色画面的成功代表全部真实场景。

### Gate D：字体与字幕重排（待实现）

有限字体集正例 + 库外字体负例 + 不含中文的拉丁字体例。要求字体不确定性显式输出、字形无缺失、下行中文不遮挡上一行、合理换行。只有风格近似时报告 `approximate`，不能报 `exact`。

### Gate E：真实端到端 + 故障注入（待实现）

准备单人讲解、双人轮流讲话、原字幕不同步、重叠说话、含 BGM、无背景音乐、快切镜头等代表样本。主动注入漏一条字幕、错一个数字、错一个说话者、空 TTS、重复片段、删片尾、缺字体、OCR worker 超时、残留两字、清理抹掉角标。

要求结构故障和已知注入故障被定位，不以抽象平均分代替具体命中；记录每类误报和漏报。未支持的重叠语音等能被自动拦截进入 REVIEW，也算正确行为；悄悄产出缺词成片不算成功。

## 12. 本包真实验证记录

已经实现并执行：`timeline_demo.py`、`test_timeline.py`、`demo.py`。10 项单元测试通过，其中随机不变量测试运行 250 个案例。合成输入是 6 秒 25 fps 测试图，原音 440 Hz，插入分别为 800 Hz/1.2 秒、1100 Hz/0.8 秒测试音；每段两侧 150 ms，向上补齐到整帧。

结果：216 帧，8.64 秒；48 kHz 主音频 414720 采样帧。全文件解码通过；原始和冻结视频帧在无损主视频中的逐帧哈希一致；原音/插入音在无损主音轨中的逐采样位置一致。双语 ASS 烧录已生成样片并查看一帧，中文字符正常显示。

**没有完成真实语音 TTS/音色克隆、OCR、去字幕模型、LLM 翻译、字体自动匹配和综合 AI QA 的运行验证。** `qa.json` 对这些列出 not_tested。此结果证明的是时间线方案及原型可执行，不证明任意 YouTube 视频已经可无人值守高质量加工。

## 13. 主要公开来源

引用日期为研究基准日；实现文件为当时可读取的 `main`，不是已锁定发布版。正式集成时保存 `git rev-parse HEAD`、依赖锁和模型 revision。

- [R01] pyVideoTrans README / license: https://github.com/jianchang512/pyvideotrans
- [R02] 当前阶段入口: https://raw.githubusercontent.com/jianchang512/pyvideotrans/main/videotrans/task/trans_create.py
- [R03] 配音与缓存: https://raw.githubusercontent.com/jianchang512/pyvideotrans/main/videotrans/task/_stage_dubbing.py
- [R04] 时间对齐: https://raw.githubusercontent.com/jianchang512/pyvideotrans/main/videotrans/task/_stage_align.py
- [R05] 字幕阶段: https://raw.githubusercontent.com/jianchang512/pyvideotrans/main/videotrans/task/_stage_subtitle.py
- [R06] 合成阶段: https://raw.githubusercontent.com/jianchang512/pyvideotrans/main/videotrans/task/_stage_assemble.py
- [R07] VideoLingo README / license: https://github.com/Huanshere/VideoLingo
- [R08] TTS 生成及末段裁切: https://raw.githubusercontent.com/Huanshere/VideoLingo/main/core/_10_gen_audio.py
- [R09] 音频合并: https://raw.githubusercontent.com/Huanshere/VideoLingo/main/core/_11_merge_audio.py
- [R10] 视频配音合成: https://raw.githubusercontent.com/Huanshere/VideoLingo/main/core/_12_dub_to_vid.py
- [R11] Linly-Dubbing: https://github.com/Kedreamix/Linly-Dubbing
- [R12] VSE: https://github.com/YaoFANGUK/video-subtitle-extractor
- [R13] VSR: https://github.com/YaoFANGUK/video-subtitle-remover
- [R14] Dub Studio: https://github.com/timoncool/dub-studio
- [R15] OpenCreator / formerly KrillinAI: https://github.com/krillinai/OpenCreator
- [R16] ProPainter / license: https://github.com/sczhou/ProPainter
- [R17] ffprobe: https://ffmpeg.org/ffprobe.html
- [R18] DeepFont research: https://arxiv.org/abs/1507.03196
- [R19] ASS override tags: https://aegisub.org/docs/latest/ass_tags/
- [R20] libass: https://github.com/libass/libass
- [R21] Qwen3-TTS: https://github.com/QwenLM/Qwen3-TTS
- [R22] WhisperX: https://github.com/m-bain/whisperX
- [R23] pyannote-audio: https://github.com/pyannote/pyannote-audio
- [R24] MLX-Audio: https://github.com/Blaizzy/mlx-audio
- [R25] audio-separator: https://github.com/nomadkaraoke/python-audio-separator
- [R26] CosyVoice: https://github.com/QwenAudio/CosyVoice
- [R27] VoxCPM: https://github.com/OpenBMB/VoxCPM
- [R28] FFmpeg filters: https://ffmpeg.org/ffmpeg-filters.html
