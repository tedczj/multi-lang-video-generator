# 十项需求对照

| 要求 | 设计位置 | 可运行实现 / 尚需补齐 |
|---|---|---|
| 1. 项目骨架与模块 | 主设计§2 | vidflow已建；业务worker清楚列为待接入 |
| 2. 本地视频后的业务流程 | 主设计§3、§8–9 | 逐节点输入输出与门禁完整；demo运行其中媒体子链 |
| 3. SHA512目录聚合 | 主设计§4–5 | Store.ingest；下载前incoming例外已说明 |
| 4. 每节点每次数据版本和血缘 | 主设计§5 | request/manifest、每文件hash/producer/parents、失败保留；外部worker回执待完善 |
| 5. 策略可替换、标准结果 | 主设计§6、数据契约文档 | Registry/Strategy/worker协议；captions schema与AB fixture测试 |
| 6. 无条件重试 | 主设计§7 | Engine.retry始终新调用；实际FFmpeg重试测试 |
| 7. 单资产日志 | 主设计§10 | events.jsonl、DB事件投影、request/outputs/code/params/duration关联 |
| 8. git+策略+参数+日志 | 主设计§5.4 | git/dirty/treehash/source snapshot/strategy version/params hash；真实模型revision由worker接入 |
| 9. 上游库/代码片段 | 来源文档 | 16条来源/具体文件/函数/短摘录；已解析的3个commit固定 |
| 10. 单元+真实环境集成 | 测试文档 | 已跑单元和真实FFmpeg；YouTube/真实OCR入口未运行；全链路用例待业务适配完成 |
