from pathlib import Path
import pytest
from vidflow.demo import run_demo
from vidflow.engine import Engine,output_id
from vidflow.plugins import default_registry
from vidflow.store import Store
from vidflow.util import read_json

@pytest.fixture(scope='module')
def demo(tmp_path_factory):
    p=tmp_path_factory.mktemp('media')/'run'
    result=run_demo(p)
    return p,result

@pytest.mark.media
def test_real_ffmpeg_frame_and_pcm_oracles(demo):
    p,r=demo
    assert r['frame_order_exact'] and r['pcm_exact']
    assert r['output_frames']==425 and r['audio_samples']==816000

@pytest.mark.media
def test_gap_first_freezes_only_missing_intervals(demo):
    p,r=demo
    assert r['hold_frames']==[0,75,50]
    t=read_json(p/'timeline.json')
    assert [(h['at_source_frame'],h['frames']) for h in t['holds']]==[(225,75),(300,50)]

@pytest.mark.media
def test_unexecuted_ai_checks_prevent_final_pass(demo):
    p,r=demo
    assert r['qa_overall']=='REVIEW'
    qa=read_json(p/'qa.json')
    assert sum(c['status']=='SKIPPED' for c in qa['checks'])==5

@pytest.mark.media
def test_real_render_retry_creates_new_execution_and_reinvokes_ffmpeg(demo):
    p,r=demo;s=Store(p/'workspace',r['source_sha512']);e=Engine(s,default_registry())
    retried=e.retry(r['render_execution'])
    assert retried['execution_id']!=r['render_execution']
    assert retried['version']==2
    assert retried['retry_of']==r['render_execution']
    assert len([a for a in retried['artifacts'] if a['name'].endswith('.stderr.log')])>=5
