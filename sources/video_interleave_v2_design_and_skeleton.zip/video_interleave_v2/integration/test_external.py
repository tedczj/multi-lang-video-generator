"""Opt-in REAL environment tests. Missing prerequisites do not imply success.

Only the default (not enabled) path is skipped. Once explicitly enabled, missing
configuration, unavailable tools/models and failed quality assertions FAIL the test.
"""
import json
import os
from pathlib import Path
import pytest
from vidflow.acquire import download
from vidflow.engine import Engine,output_id
from vidflow.plugins import default_registry,worker_strategy
from vidflow.store import Store
from vidflow.util import read_json


def require_live(kind):
    if os.getenv('VIDFLOW_LIVE_'+kind)!='1':pytest.skip('Real '+kind+' tests explicitly disabled')
    assert os.getenv('VIDFLOW_AUTHORIZED')=='1','Only use authorized video/voice assets'

@pytest.mark.external
def test_live_youtube_download_and_repeat(tmp_path):
    require_live('YOUTUBE')
    url=os.environ['VIDFLOW_YOUTUBE_URL']
    a,ar=download(tmp_path/'workspace',url,height=360)
    b,br=download(tmp_path/'workspace',url,height=360)
    assert ar['attempt_id']!=br['attempt_id']
    assert a.source.exists() and b.source.exists()
    # Same URL does NOT guarantee same bytes: no false same-hash assertion here.

@pytest.mark.external
def test_real_ocr_ab_same_contract_new_executions(tmp_path):
    require_live('OCR')
    profile=read_json(Path(os.environ['VIDFLOW_OCR_PROFILE']))
    s,_=Store.ingest(tmp_path/'workspace',Path(profile['video']))
    registry=default_registry();e=Engine(s,registry)
    source=e.execute('source','local.register');results=[]
    for name in ('a','b'):
        worker=profile['workers'][name]
        registry.register(worker_strategy('ocr',worker['id'],'captions.v1',worker['argv']))
        m=e.execute('ocr',worker['id'],inputs={'source':output_id(source)},params=worker['params'],models=worker['models'])
        data=read_json(Path(s.artifact(output_id(m))['absolute_path']))
        assert data['cues'],'Real reference fixture should have subtitles'
        text=' '.join(c['text'] for c in data['cues'])
        for expected in profile['expected_substrings']:assert expected in text
        r=e.retry(m['execution_id']);assert r['execution_id']!=m['execution_id']
        results.append(m)
    assert results[0]['version']!=results[1]['version']
