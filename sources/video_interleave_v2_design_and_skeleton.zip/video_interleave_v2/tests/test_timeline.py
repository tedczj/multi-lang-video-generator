from fractions import Fraction as F
from math import ceil
import random
import pytest
from vidflow.timeline import plan, verify


def spec(gap, end=2, total=20):
    return {'fps':'25','sample_rate':48000,'source_frames':total*25,
        'utterances':[{'id':'u1','start_sample':0,'end_sample':int(end*48000),
                       'safe_cut_frame':int((F(str(end))+F(str(gap)))*25)}]}

@pytest.mark.parametrize('gap,c,extra',[(8,4,0),(6,4,0),(3,4,75),(.32,4,142),(0,4,150)])
def test_gap_cases(gap,c,extra):
    t=plan(spec(gap),{'u1':c*48000})
    assert sum(h['frames'] for h in t['holds'])==extra


def test_larger_original_gap_is_preserved():
    t=plan(spec(8),{'u1':48000})
    assert t['output_frames']==500
    assert F(t['dubs'][0]['start_seconds'])==3


def test_last_utterance_extends_tail():
    s=spec(1,end=9,total=10)
    t=plan(s,{'u1':4*48000})
    assert t['output_frames']==375


def test_overlap_rejected():
    s=spec(1)
    s['utterances'].append({'id':'u2','start_sample':48000,'end_sample':4*48000,'safe_cut_frame':125})
    with pytest.raises(ValueError,match='Unsafe'):plan(s,{'u1':48000,'u2':48000})


def test_no_safe_frame_cut_rejected():
    s=spec(1)
    s['utterances'][0]['safe_cut_frame']=49
    with pytest.raises(ValueError,match='Unsafe'):plan(s,{'u1':48000})


def test_missing_extra_and_zero_audio_rejected():
    for durations in [{},{'u1':0},{'u1':10,'u2':10}]:
        with pytest.raises(ValueError):plan(spec(1),durations)


def test_rational_rate_is_exact_in_planner():
    s={'fps':'30000/1001','sample_rate':48000,'source_frames':300,
       'utterances':[{'id':'u','start_sample':0,'end_sample':48000,'safe_cut_frame':31}]}
    t=plan(s,{'u':48001})
    assert F(t['dubs'][0]['end_seconds'])-F(t['dubs'][0]['start_seconds'])==F(48001,48000)
    verify(t)


def test_no_utterances_preserves_source():
    s=spec(1);s['utterances']=[]
    assert plan(s,{})['output_frames']==500


def test_corrupted_coverage_detected():
    t=plan(spec(1),{'u1':48000});t['pieces'][0]['source_start_frame']=1
    with pytest.raises(ValueError):verify(t)


def test_500_random_timelines_no_drift_or_lost_content():
    rng=random.Random(531)
    for _ in range(500):
        cursor=0;units=[];dur={}
        for i in range(rng.randint(1,30)):
            start=cursor+rng.randrange(0,30)
            end=start+rng.randint(1,100)
            cut=end+rng.randint(0,150)
            units.append({'id':str(i),'start_sample':start*1920,'end_sample':end*1920,'safe_cut_frame':cut})
            dur[str(i)]=rng.randint(1,240000)
            cursor=cut
        total=cursor+rng.randint(0,100)
        s={'fps':'25','sample_rate':48000,'source_frames':total,'utterances':units}
        t=plan(s,dur);verify(t)
        assert t['output_frames']==total+sum(x['frames'] for x in t['holds'])
        assert sum(x['source_end_frame']-x['source_start_frame'] for x in t['pieces'] if x['kind']=='source')==total
