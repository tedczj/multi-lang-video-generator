import json
import sqlite3
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import pytest
from vidflow.contracts import validate
from vidflow.engine import Engine, ExecutionFailed, Strategy, output_id
from vidflow.plugins import default_registry, worker_strategy
from vidflow.store import Store
from vidflow.util import atomic_json, file_lock, read_json, sha512

@pytest.fixture
def env(tmp_path):
    p=tmp_path/'original.mp4'; p.write_bytes(b'reference source bytes')
    s,_=Store.ingest(tmp_path/'workspace',p)
    return s, Engine(s, default_registry()), p


def test_hash_identity_and_copy(env,tmp_path):
    s,e,p=env
    renamed=tmp_path/'renamed.bin'; renamed.write_bytes(p.read_bytes())
    s2,_=Store.ingest(s.root,renamed)
    assert s.asset==s2.asset==sha512(p)
    p.write_bytes(b'caller changed source')
    assert s.source.read_bytes()==b'reference source bytes'


def test_modified_video_is_other_asset(env,tmp_path):
    s,e,p=env; p.write_bytes(b'changed')
    s2,_=Store.ingest(s.root,p)
    assert s.asset!=s2.asset


def test_same_retry_always_new_version_and_invocation(env):
    s,e,_=env
    a=e.execute('ocr','fixture_a',params={'text':'hello'})
    b=e.retry(a['execution_id']); c=e.retry(a['execution_id'])
    assert [x['version'] for x in (a,b,c)]==[1,2,3]
    assert len({output_id(x) for x in (a,b,c)})==3
    assert a['artifacts'][0]['sha512']==b['artifacts'][0]['sha512']
    events=[json.loads(x) for x in (s.base/'events.jsonl').read_text().splitlines()]
    assert sum(x['event']=='fixture.invoked' for x in events)==3
    assert b['retry_of']==a['execution_id']


def test_pin_old_output_when_new_exists(env):
    s,e,_=env
    a=e.execute('ocr','fixture_a',params={'text':'a'})
    b=e.execute('ocr','fixture_b',params={'text':'b'})
    e.registry.register(Strategy('consume','test','fixture.v1',
        lambda c,p:{'schema':'fixture.v1','value':c.input_json('captions')['cues'][0]['text']}))
    m=e.execute('consume','test',inputs={'captions':output_id(a)})
    value=read_json(Path(s.artifact(output_id(m))['absolute_path']))
    assert value['value']=='a'
    assert m['inputs'][0]['id']==output_id(a)


def test_failure_preserved_retry_invokes_again(env):
    s,e,_=env; calls=[]
    def bad(c,p):
        calls.append(1); c.path('partial.txt').write_text('partial')
        raise RuntimeError('intentional failure')
    e.registry.register(Strategy('fail','test','fixture.v1',bad))
    with pytest.raises(ExecutionFailed) as err: e.execute('fail','test')
    with pytest.raises(ExecutionFailed): e.retry(err.value.execution_id)
    assert len(calls)==2
    row=s.get_execution(err.value.execution_id)
    assert row['state']=='FAILED'
    assert (s.execution_dir(row['request'])/'artifacts/partial.txt').exists()


def test_schema_validation_prevents_success(env):
    s,e,_=env
    e.registry.register(Strategy('bad','test','captions.v1',lambda c,p:{'cues':[]}))
    with pytest.raises(ExecutionFailed) as err: e.execute('bad','test')
    assert s.get_execution(err.value.execution_id)['state']=='FAILED'


def test_old_artifact_tamper_detected(env):
    s,e,_=env; m=e.execute('ocr','fixture_a')
    a=s.artifact(output_id(m)); p=Path(a['absolute_path']); p.chmod(0o644); p.write_text('{}')
    with pytest.raises(ValueError,match='integrity'): s.artifact(a['id'])


def test_plain_secret_rejected(env):
    s,e,_=env
    with pytest.raises(ValueError,match='secret_ref'): e.execute('ocr','fixture_a',params={'api_key':'sensitive'})


def test_paths_confined(env):
    s,e,_=env
    def bad(c,p):
        c.path('../escape.txt').write_text('bad')
        return {'schema':'fixture.v1','value':1}
    e.registry.register(Strategy('bad','paths','fixture.v1',bad))
    with pytest.raises(ExecutionFailed): e.execute('bad','paths')


def test_output_symlink_rejected(env):
    s,e,_=env
    def bad(c,p):
        c.path('alias').symlink_to(s.source)
        return {'schema':'fixture.v1','value':1}
    e.registry.register(Strategy('bad','symlink','fixture.v1',bad))
    with pytest.raises(ExecutionFailed): e.execute('bad','symlink')


def test_concurrent_versions_and_single_log(env):
    s,e,_=env
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(lambda _:e.execute('ocr','fixture_a'), range(8)))
    assert sorted(m['version'] for m in results)==list(range(1,9))
    rows=[json.loads(x) for x in (s.base/'events.jsonl').read_text().splitlines()]
    assert [x['seq'] for x in rows]==list(range(1,len(rows)+1))
    assert sum(x['event']=='execution.finished' for x in rows)==8


def test_log_projection_recovers_partial_tail(env):
    s,e,_=env; e.execute('ocr','fixture_a')
    log=s.base/'events.jsonl'; n=len(log.read_text().splitlines())
    with log.open('ab') as f: f.write(b'{"interrupted')
    s.event(None,'test',{})
    rows=[json.loads(x) for x in log.read_text().splitlines()]
    assert len(rows)==n+1


def test_terminal_state_is_not_overwritable(env):
    s,e,_=env; m=e.execute('ocr','fixture_a')
    ex=s.get_execution(m['execution_id'])['request']
    with pytest.raises(ValueError,match='terminal'): s.commit(ex,m)


def test_recover_abandoned_is_not_success(env):
    s,e,_=env
    ex=s.allocate({'node':'ocr','scope':'video','run_id':'r','strategy':'fixture_a','inputs':{}})
    assert s.recover(ex['id'])=='ABANDONED'
    assert (s.execution_dir(ex)/'manifest.json').exists()


def test_live_lease_prevents_recovery(env):
    s,e,_=env
    ex=s.allocate({'node':'ocr','scope':'video','run_id':'r','strategy':'fixture_a','inputs':{}})
    with file_lock(s.execution_dir(ex)/'lease.lock'):
        with pytest.raises(BlockingIOError): s.recover(ex['id'])


def test_selection_is_append_only(env):
    s,e,_=env; a=e.execute('ocr','fixture_a'); b=e.execute('ocr','fixture_b')
    x=s.select('ocr-main',output_id(a),'first experiment')
    y=s.select('ocr-main',output_id(b),'second experiment')
    assert x!=y and len(list((s.base/'selections').glob('*.json')))==2


def test_model_and_params_lineage_recorded(env):
    s,e,_=env
    models=[{'provider':'fixture','model_id':'not-real','revision':'r1'}]
    m=e.execute('ocr','fixture_a',params={'text':'abc','seed':17},models=models)
    assert m['models']==models and m['params']['seed']==17
    assert len(m['params_sha512'])==128 and len(m['code']['source_tree_sha512'])==128
    assert m['source_snapshot_sha512']


def test_subprocess_worker_executes_again(env,tmp_path):
    s,e,_=env
    worker=tmp_path/'worker.py'
    worker.write_text("""import argparse,json
p=argparse.ArgumentParser();p.add_argument('--request');p.add_argument('--result');a=p.parse_args()
r=json.load(open(a.request));print('worker actually executed')
json.dump({'schema':'fixture.v1','value':r['execution_id']},open(a.result,'w'))
""")
    e.registry.register(worker_strategy('worker','subprocess','fixture.v1',[sys.executable,str(worker)]))
    a=e.execute('worker','subprocess'); b=e.retry(a['execution_id'])
    av=read_json(Path(s.artifact(output_id(a))['absolute_path']))['value']
    bv=read_json(Path(s.artifact(output_id(b))['absolute_path']))['value']
    assert av!=bv


def test_timeout_retains_failure(env):
    s,e,_=env
    def slow(c,p):
        c.execute([sys.executable,'-c','import time; time.sleep(5)'],timeout=.05)
        return {'schema':'fixture.v1','value':1}
    e.registry.register(Strategy('slow','test','fixture.v1',slow))
    with pytest.raises(ExecutionFailed) as err:e.execute('slow','test')
    assert s.get_execution(err.value.execution_id)['state']=='FAILED'


def test_no_cross_asset_binding(env,tmp_path):
    s,e,p=env; a=e.execute('ocr','fixture_a')
    x=tmp_path/'other'; x.write_bytes(b'other')
    s2,_=Store.ingest(s.root,x)
    with pytest.raises(ValueError): Engine(s2,default_registry()).execute('ocr','fixture_a',inputs={'x':output_id(a)})
