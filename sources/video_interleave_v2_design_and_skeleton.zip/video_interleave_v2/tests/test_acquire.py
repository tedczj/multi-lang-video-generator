from pathlib import Path
import pytest
from vidflow.acquire import youtube_url,ytdlp_argv

@pytest.mark.parametrize('url',[
 'https://www.youtube.com/watch?v=abcdefghijk&t=33s&list=ignored',
 'https://youtu.be/abcdefghijk?t=1','https://youtube.com/shorts/abcdefghijk'])
def test_url_normalization(url):
    assert youtube_url(url)=='https://www.youtube.com/watch?v=abcdefghijk'

@pytest.mark.parametrize('url',['file:///etc/passwd','https://youtube.com.evil.test/watch?v=abcdefghijk',
 'https://user:pass@youtube.com/watch?v=abcdefghijk','https://youtube.com/playlist?list=x'])
def test_bad_urls_rejected(url):
    with pytest.raises(ValueError):youtube_url(url)


def test_download_never_uses_result_archive_or_old_partial():
    a=ytdlp_argv('https://youtu.be/abcdefghijk',Path('/tmp/new-attempt'))
    for option in ['--ignore-config','--no-playlist','--no-download-archive','--no-continue','--force-overwrites','--no-simulate']:
        assert option in a
    assert 'after_move:%(filepath)j' in a
    assert a[-2]=='--'
