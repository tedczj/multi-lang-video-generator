import json
from pathlib import Path
import pytest
from vidflow.pipeline import run_recipe
from vidflow.engine import Engine,output_id
from vidflow.plugins import default_registry
from vidflow.store import Store

def setup(tmp_path):
    p=tmp_path/'source';p.write_bytes(b'owned fixture')
    s,_=Store.ingest(tmp_path/'workspace',p)
    return s,Engine(s,default_registry())

def test_recipe_repeated_executes_all_and_pins_lineage(tmp_path):
    s,e=setup(tmp_path)
    recipe={'schema':'recipe.v1','steps':[
        {'key':'ocr','node':'ocr','strategy':'fixture_a','inputs':{'source':{'step':'src'}},'params':{'text':'one'}},
        {'key':'src','node':'source','strategy':'local.register'}]}
    a=run_recipe(e,recipe);b=run_recipe(e,recipe)
    assert a['run_id']!=b['run_id']
    assert a['executions']['ocr']!=b['executions']['ocr']
    ma=json.loads(s.get_execution(a['executions']['ocr'])['manifest_json'])
    mb=json.loads(s.get_execution(b['executions']['ocr'])['manifest_json'])
    assert ma['artifacts'][0]['parents']!=mb['artifacts'][0]['parents']
    assert (s.base/'runs'/a['run_id']/'plan.json').exists()

def test_cycle_unknown_dep_and_duplicate_key_reject(tmp_path):
    s,e=setup(tmp_path)
    with pytest.raises(ValueError):
        run_recipe(e,{'schema':'recipe.v1','steps':[{'key':'a','node':'ocr','strategy':'fixture_a','inputs':{'x':{'step':'a'}}}]})
    with pytest.raises(ValueError):
        run_recipe(e,{'schema':'recipe.v1','steps':[{'key':'a','node':'source','strategy':'local.register'}]*2})
