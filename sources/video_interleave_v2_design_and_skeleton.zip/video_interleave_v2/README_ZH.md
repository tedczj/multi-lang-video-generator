# VidFlow：可替换节点与空档优先双语视频骨架

这是**可运行的执行/版本/时间线参考骨架与详细开发设计**，不是已经完成OCR、去字幕、翻译、声音克隆的一键成品。示例使用提示音；两个OCR fixture只测试接口。联网下载和真实模型尚未在本环境执行。

## 文档入口

- `DEVELOPMENT_DESIGN_ZH.md`：完整架构、20余节点、SHA512目录、血缘、强制重试、日志、媒体策略及开发验收。
- `docs/UPSTREAM_REFERENCES_ZH.md`：各上游仓库/具体文件/函数/代码片段，复用和新增边界。
- `docs/DATA_CONTRACTS_ZH.md`：每类标准结果字段、单位和语义校验。
- `docs/TEST_PLAN_ZH.md`：单元、真实FFmpeg、真实YouTube/双OCR及全链路用例。
- `evidence/TEST_RESULTS_ZH.md`：本次实际执行结果；未执行项目清单。

## 环境与安装

参考骨架使用Python 3.11+，Linux/macOS本地文件系统；`fcntl`锁不支持原生Windows。已测环境见evidence。需要PATH中有FFmpeg/ffprobe，FFmpeg支持FFV1、libx264和AAC。

在包根目录运行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[test]'
python -m vidflow.cli doctor
python -m pytest -q
```

`requirements-tested.txt`记录本次核心测试所用相关Python包版本，不是所有模型worker的依赖锁，也不承诺不同OS的轮子完全相同。生产worker必须分别锁定依赖/模型revision并做目标设备集成。

## 跑已完成的实际媒体演示

输出目录必须不存在或为空：

```bash
python -m vidflow.demo --out ./demo_run_001
```

将生成12秒原片与提示音译音，再按空档优先策略输出17秒预览。`demo_run_001/verification.json`记录逐帧/逐采样验证；`demo_run_001/workspace/videos/<sha512>/`保留原片、每节点版本、原始进程日志、SQLite索引和events.jsonl。

此演示没有字幕烧录、真实语音或真实字幕擦除。`qa.json`总体是REVIEW，因为必要AI/字幕质量检查尚未执行。无损母版用于精确验证，不要求H264/AAC字节与原片一致。

## 导入自己的本地文件

```bash
python -m vidflow.cli --root ./workspace ingest /absolute/path/input.mp4
```

输出包含真实asset_sha512和source执行manifest。随后可以运行已实现的probe：

```bash
python -m vidflow.cli --root ./workspace run <完整SHA512> probe ffprobe
```

`probe`返回媒体信息，不会替你完成尚未接入的业务节点。

## 检验插件替换和配方重跑

使用上述asset运行测试配方：

```bash
python -m vidflow.cli --root ./workspace pipeline <完整SHA512> examples/fixture_recipe.json
python -m vidflow.cli --root ./workspace pipeline <完整SHA512> examples/fixture_recipe.json
```

两次配方均实际调用source与两个OCR fixture，生成不同run、execution和节点版本。它们返回预设文本，**不读取字幕图像，不是Paddle/Qwen实现**。

指定参数/输入/模型声明运行一个真实已安装插件：

```bash
python -m vidflow.cli --root ./workspace run <SHA512> ocr <已安装策略ID> \
  --params /absolute/params.json \
  --inputs /absolute/pinned_artifact_inputs.json \
  --models /absolute/model_declarations.json
```

inputs形如`{"source":"art_<精确版本>"}`。不接受latest别名。models必须是JSON列表；参数中的密钥只写secret_ref。

插件可通过`vidflow.strategies` entry point返回`Strategy`。通用进程适配器`worker_strategy`会给外部程序附加`--request`和`--result`，要求其真实实现标准输出；不是把任意第三方CLI直接当作本协议worker。

## 无条件重试与恢复

```bash
python -m vidflow.cli --root ./workspace retry <SHA512> <execution_id>
```

使用原执行固定输入和参数，**调用当前安装策略重新运行**，新建版本/目录并记录retry_of。旧执行成功也可重试；没有输入哈希或参数缓存跳过。需要旧代码复现时，先显式部署原commit/镜像。无效或被篡改输入会校验失败，不应以“无条件”绕过完整性或安全检查。

```bash
python -m vidflow.cli --root ./workspace recover <SHA512> <execution_id>
```

recover只恢复中断记录/已封存结果，不等于retry。原worker仍持有lease时拒绝抢占。完整远程心跳/fencing及全部断电窗口仍是生产扩展任务。

## 实际YouTube下载入口（本环境未联网验证）

```bash
python -m pip install -e '.[download,test]'
python -m vidflow.cli --root ./workspace download \
  'https://www.youtube.com/watch?v=<授权视频ID>' --height 1080
```

还需依据yt-dlp官方文档准备受支持的JS runtime/EJS及FFmpeg。每次调用使用新incoming目录，实际下载/合流后才计算SHA512。URL上的起始时间参数不默认裁剪，下载完整单视频。下载失败/未合流没有确定视频哈希时，保留incoming诊断。

默认只针对可正常获取且已授权的视频，不提供权限或DRM绕过。下载器的live状态预检、资源配额、授权secret适配还需按设计补全。不要把临时下载目录里的敏感元数据公开分享。

真实联网和双OCR测试启用方法见`docs/TEST_PLAN_ZH.md`。未启用时清楚SKIP；启用后缺环境或失败就是FAIL。

## 已实现功能与明确限制

| 已实现并有测试 | 需要后续开发/目标环境验证 |
|---|---|
| 全视频SHA512资产目录、逐次节点版本、文件hash/保守血缘 | 全业务输入端口的canonical基准与质量校验 |
| 无条件retry、显式版本绑定、顺序DAG、统一日志 | 完整生产发布门禁、远程fencing、长视频配额/GC |
| 代码git/dirty/源码树快照、参数/模型声明记录 | 每个实际外部模型/worker的运行回执和独立代码部署快照 |
| JSON Schema、两个fixture、外部子进程协议 | 真实OCR、VAD/ASR、去字幕、字体、翻译、克隆适配 |
| Fraction时间线及gap-first不变量 | 每语句多种译音串联的时间线策略 |
| 实际FFmpeg补帧/PCM混音/预览和结构检查 | VFR/HDR/旋转、多音轨、所有有理帧率的生产合成 |
| 基础恢复与并发版本测试 | 完整kill -9/断电/磁盘满故障矩阵 |

参考渲染器要求canonical CFR、接近0起点、源PCM与视频等长、PCM16双声道、每帧整数采样数。源与译音必须提前规范化。它按段重复解码并将PCM放入内存，适用于正确性验证，不适合直接处理长视频生产任务。

本包没有字体或模型权重；上游参考许可需逐一检查。本次源码git与导出指纹见`BUILD_PROVENANCE.json`，执行时会检查导出源码树哈希；修改源码后不能继续冒称未修改的导出commit。
