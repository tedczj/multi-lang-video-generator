from __future__ import annotations
from fractions import Fraction as F
from math import ceil


def plan(spec: dict, dub_samples: dict[str, int], *, pre="1", post="1") -> dict:
    """Exact rational planner. Cuts are prevalidated canonical FRAME boundaries.

    Every source frame appears once; only hold frames are new. No audio time-stretch.
    If there is no safe frame boundary between utterances, upstream must regroup.
    """
    fps, sr, total = F(spec["fps"]), int(spec["sample_rate"]), int(spec["source_frames"])
    before, after = F(str(pre)), F(str(post))
    if fps <= 0 or sr <= 0 or total <= 0 or before < 0 or after < 0:
        raise ValueError("Invalid media timing")
    units = spec["utterances"]
    ids = [u["id"] for u in units]
    if len(set(ids)) != len(ids) or set(ids) != set(dub_samples):
        raise ValueError("Missing, extra or duplicate utterance/dub IDs")
    holds, dubs, output_units, pieces = [], [], [], []
    delay_frames = 0
    previous_end, cursor, output_cursor = F(0), 0, 0
    for i, u in enumerate(units):
        start, end = F(u["start_sample"], sr), F(u["end_sample"], sr)
        cut = int(u["safe_cut_frame"])
        cut_t = F(cut, 1) / fps
        next_start = F(units[i+1]["start_sample"], sr) if i+1 < len(units) else F(total, 1)/fps
        if not (previous_end <= start < end <= cut_t <= next_start):
            raise ValueError("Unsafe cut or overlap: regroup; never clip original speech")
        if not (cursor <= cut <= total) or dub_samples[u["id"]] <= 0:
            raise ValueError("Invalid cut or zero-length dub")
        delay = F(delay_frames, 1) / fps
        ds = end + delay + before
        de = ds + F(dub_samples[u["id"]], sr)
        missing = max(F(0), de + after - (cut_t + delay))
        extra_frames = ceil(missing * fps)
        if cut > cursor:
            pieces.append({"kind": "source", "source_start_frame": cursor,
                "source_end_frame": cut, "output_start_frame": output_cursor,
                "output_end_frame": output_cursor + cut - cursor})
            output_cursor += cut - cursor
        if extra_frames:
            if cut < 1:
                raise ValueError("Cannot hold a frame before source frame zero")
            hold = {"kind": "hold", "at_source_frame": cut,
                "source_hold_frame": cut - 1, "frames": extra_frames,
                "output_start_frame": output_cursor,
                "output_end_frame": output_cursor + extra_frames, "utterance_id": u["id"]}
            holds.append(hold)
            pieces.append(hold)
            output_cursor += extra_frames
        dubs.append({"utterance_id": u["id"], "start_seconds": str(ds), "end_seconds": str(de),
                     "samples": dub_samples[u["id"]], "audio_role": "dub_" + u["id"]})
        output_units.append({**u, "output_start_seconds": str(start + delay),
            "output_end_seconds": str(end + delay), "subtitle_end_seconds": str(de + after),
            "source_gap_seconds": str(next_start - end), "hold_frames": extra_frames})
        delay_frames += extra_frames
        cursor, previous_end = cut, end
    if cursor < total:
        pieces.append({"kind": "source", "source_start_frame": cursor, "source_end_frame": total,
            "output_start_frame": output_cursor, "output_end_frame": output_cursor + total - cursor})
    result = {"schema": "timeline.v1", "fps": str(fps), "sample_rate": sr,
        "source_frames": total, "output_frames": total + delay_frames,
        "holds": holds, "pieces": pieces, "dubs": dubs, "utterances": output_units,
        "pre_seconds": str(before), "post_seconds": str(after)}
    verify(result)
    return result


def verify(t: dict) -> None:
    fps, sr = F(t["fps"]), t["sample_rate"]
    src, out = 0, 0
    for p in t["pieces"]:
        if p["output_start_frame"] != out:
            raise ValueError("Output coverage gap or overlap")
        if p["kind"] == "source":
            if p["source_start_frame"] != src:
                raise ValueError("Source omitted, duplicated or reordered")
            size = p["source_end_frame"] - src
            src = p["source_end_frame"]
        else:
            if p["source_hold_frame"] != src - 1 or p["at_source_frame"] != src:
                raise ValueError("Hold references wrong source frame")
            size = p["frames"]
        if size <= 0 or p["output_end_frame"] != out + size:
            raise ValueError("Invalid piece duration")
        out += size
    if src != t["source_frames"] or out != t["output_frames"]:
        raise ValueError("Incomplete source/output coverage")
    for i, (u, d) in enumerate(zip(t["utterances"], t["dubs"], strict=True)):
        ds, de = F(d["start_seconds"]), F(d["end_seconds"])
        if ds - F(u["output_end_seconds"]) != F(t["pre_seconds"]):
            raise ValueError("Wrong pre-gap")
        if de - ds != F(d["samples"], sr):
            raise ValueError("Dub was truncated/stretched")
        following = (F(t["utterances"][i+1]["output_start_seconds"])
                     if i+1 < len(t["utterances"]) else F(out, 1)/fps)
        if following - de < F(t["post_seconds"]):
            raise ValueError("Dub overlaps next original speech or lacks post-gap")
