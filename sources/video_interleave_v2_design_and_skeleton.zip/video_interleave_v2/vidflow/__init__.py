"""Own implementation; third-party projects are referenced, not vendored."""
__version__ = "0.1.0"
