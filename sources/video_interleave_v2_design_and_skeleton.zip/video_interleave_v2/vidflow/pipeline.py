"""Small explicit DAG runner. Included steps ALWAYS execute; no hash cache/resume magic."""
from __future__ import annotations
from pathlib import Path
from .engine import Engine, output_id
from .util import atomic_json, now, uid, ensure_no_secrets, safe_name


def run_recipe(engine: Engine, recipe: dict) -> dict:
    if recipe.get('schema') != 'recipe.v1':
        raise ValueError('Expected recipe.v1')
    ensure_no_secrets(recipe)
    steps = recipe['steps']
    keys = [safe_name(s['key']) for s in steps]
    if len(set(keys)) != len(keys):
        raise ValueError('Duplicate step key')
    pending = {s['key']: s for s in steps}
    order, known = [], set()
    # Validate the whole DAG before recording an executable run.
    while pending:
        ready = [k for k,s in pending.items() if all(not isinstance(v,dict) or
                 v.get('step') in known for v in s.get('inputs',{}).values())]
        if not ready:
            raise ValueError('Cycle or unknown dependency')
        for k in ready:
            s=pending.pop(k);engine.registry.get(s['node'],s['strategy'])
            order.append(s);known.add(k)
    run_id=uid('run');directory=engine.store.base/'runs'/run_id
    atomic_json(directory/'plan.json',{'run_id':run_id,'at':now(),'recipe':recipe})
    accepted={};executions={}
    engine.store.event(None,'run.started',{'run_id':run_id,'plan':str((directory/'plan.json').relative_to(engine.store.base))})
    try:
        for s in order:
            inputs={}
            for role,value in s.get('inputs',{}).items():
                inputs[role]=output_id(accepted[value['step']], value.get('output','result.json')) if isinstance(value,dict) else value
            m=engine.execute(s['node'],s['strategy'],scope=s.get('scope','video'),
                params=s.get('params',{}),models=s.get('models',[]),inputs=inputs,run_id=run_id)
            accepted[s['key']]=m;executions[s['key']]=m['execution_id']
            atomic_json(directory/'steps'/(s['key']+'.json'),{'key':s['key'],'execution_id':m['execution_id'],
                'inputs':inputs,'outputs':m['artifacts']})
        result={'schema':'run.v1','run_id':run_id,'state':'SUCCEEDED','executions':executions,'ended_at':now()}
    except BaseException as e:
        result={'schema':'run.v1','run_id':run_id,'state':'FAILED','executions':executions,
                'failed_execution_id':getattr(e,'execution_id',None),'error_type':type(e).__name__,'ended_at':now()}
        atomic_json(directory/'result.json',result);engine.store.event(None,'run.finished',result)
        raise
    atomic_json(directory/'result.json',result);engine.store.event(None,'run.finished',result)
    return result
