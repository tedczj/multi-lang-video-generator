from __future__ import annotations
import json
from pathlib import Path
import shutil
import wave
from .engine import Registry, Strategy
from .media import render
from .timeline import plan
from .util import atomic_json, read_json, sha512


def register_source(ctx, params):
    src = ctx.store.source
    return {"schema": "source.v1", "asset_sha512": ctx.store.asset,
            "source_path": "source/original.bin", "source_bytes": src.stat().st_size}


def import_file(ctx, params):
    source = Path(params["path"]).resolve(strict=True)
    target = ctx.path("payload" + (source.suffix if len(source.suffix) < 12 else ".bin"))
    shutil.copyfile(source, target)
    return {"schema": "file.v1", "file": target.name, "sha512": sha512(target),
            "original_name": source.name}


def probe(ctx, params):
    result = ctx.execute(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json",
                          str(ctx.store.source)])
    return {"schema": "probe.v1", "probe": json.loads(result.stdout)}


def timeline(ctx, params):
    spec = ctx.input_json("spec")
    durations = {}
    for u in spec["utterances"]:
        with wave.open(str(ctx.input("dub_" + u["id"])), "rb") as w:
            if (w.getnchannels(), w.getsampwidth(), w.getframerate()) != (2,2,spec["sample_rate"]):
                raise ValueError("Normalize dub PCM before planning")
            durations[u["id"]] = w.getnframes()
    return plan(spec, durations, pre=params.get("pre_seconds","1"), post=params.get("post_seconds","1"))


def media_render(ctx, params):
    t = ctx.input_json("timeline")
    return render(ctx, t, ctx.store.source, ctx.input("source_wav"),
                  {d["utterance_id"]: ctx.input(d["audio_role"]) for d in t["dubs"]})


def qa_media(ctx, params):
    t = ctx.input_json("timeline")
    raw = ctx.execute(["ffprobe", "-v", "error", "-count_frames", "-show_streams", "-of", "json",
                       str(ctx.input("lossless_video"))]).stdout
    v = next(s for s in json.loads(raw)["streams"] if s["codec_type"] == "video")
    with wave.open(str(ctx.input("master_audio")), "rb") as w:
        actual_samples = w.getnframes()
    from fractions import Fraction
    expected_samples = Fraction(t["output_frames"] * t["sample_rate"],1)/Fraction(t["fps"])
    checks = [{"id": "frame_count", "status": "PASS" if int(v["nb_read_frames"]) == t["output_frames"] else "FAIL"},
              {"id": "sample_count", "status": "PASS" if actual_samples == expected_samples else "FAIL"}]
    ctx.execute(["ffmpeg", "-v", "error", "-xerror", "-nostdin", "-i", str(ctx.input("preview")),
                 "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-"])
    checks.append({"id": "full_decode", "status": "PASS"})
    for item in ("ocr_residual", "translation_semantics", "voice_identity", "subtitle_layout", "speech_overlap"):
        checks.append({"id": item, "status": "SKIPPED", "reason": "Required AI/visual adapters are not implemented in this skeleton"})
    return {"schema": "qa.v1", "overall": "FAIL" if any(c["status"] == "FAIL" for c in checks) else "REVIEW",
            "checks": checks}


def fixture_a(ctx, params):
    # A deterministic fake OCR, used ONLY for adapter-contract and retry tests.
    ctx.emit("fixture.invoked", fixture=True)
    return {"schema": "captions.v1", "asset_sha512": ctx.store.asset,
        "coordinate_space": "canonical_video_pixels", "cues": [{"cue_id": "c1", "start_us": 0,
        "end_us": 1000000, "text": params.get("text", "Test"), "bbox_xyxy": [1,2,90,20],
        "confidence": 1.0, "evidence": []}], "warnings": ["FIXTURE_NOT_REAL_OCR"]}


def fixture_b(ctx, params):
    r = fixture_a(ctx, params)
    r["cues"][0]["text"] = r["cues"][0]["text"].upper()
    return r


def default_registry():
    r = Registry()
    for s in [Strategy("source", "local.register", "source.v1", register_source),
              Strategy("import", "file.snapshot", "file.v1", import_file),
              Strategy("probe", "ffprobe", "probe.v1", probe),
              Strategy("timeline", "gap_first", "timeline.v1", timeline),
              Strategy("render", "ffmpeg.reference", "render.v1", media_render),
              Strategy("qa", "media.structural", "qa.v1", qa_media),
              Strategy("ocr", "fixture_a", "captions.v1", fixture_a),
              Strategy("ocr", "fixture_b", "captions.v1", fixture_b)]:
        r.register(s)
    return r


def worker_strategy(node: str, strategy_id: str, output_schema: str, argv: list[str]) -> Strategy:
    """Adapter factory. argv is administrator configuration, NOT model-generated text.

    Worker must accept --request PATH --result PATH and WRITE into its work directory.
    Models run elsewhere only after a specific worker has implemented this protocol.
    """
    def run(ctx, params):
        req = ctx.path("worker.request.json")
        result = ctx.path("worker.result.json")
        atomic_json(req, {"schema": "worker.request.v1", "execution_id": ctx.ex["id"],
            "asset_sha512": ctx.store.asset, "strategy": strategy_id, "params": params,
            "models": ctx.ex["models"], "cache_policy": "NO_RESULT_REUSE",
            "inputs": {r: str(ctx.input(r)) for r in ctx.ex["inputs"]},
            "asset_source_path": str(ctx.store.source), "output_dir": str(ctx.work)})
        ctx.execute([*argv, "--request", str(req), "--result", str(result)], timeout=params.get("timeout_seconds",600))
        return read_json(result)
    return Strategy(node, strategy_id, output_schema, run)
