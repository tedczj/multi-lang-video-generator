from __future__ import annotations
from dataclasses import dataclass
import importlib.metadata
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import time
import traceback
from typing import Callable
import zipfile
from .contracts import validate
from .store import Store
from .util import (atomic_json, code_provenance, confined, digest, ensure_no_secrets,
                   file_lock, fsync_dir, now, read_json, safe_name, sha512, uid)


@dataclass(frozen=True)
class Strategy:
    node: str
    id: str
    output_schema: str
    run: Callable
    implementation_version: str = "1"


class Registry:
    def __init__(self):
        self.items: dict[tuple[str, str], Strategy] = {}

    def register(self, strategy: Strategy):
        key = (strategy.node, strategy.id)
        if key in self.items:
            raise ValueError(f"Duplicate plugin: {key}")
        self.items[key] = strategy
        return self

    def discover(self):
        for ep in importlib.metadata.entry_points(group="vidflow.strategies"):
            self.register(ep.load()())
        return self

    def get(self, node: str, strategy: str) -> Strategy:
        try:
            return self.items[(node, strategy)]
        except KeyError as e:
            raise ValueError(f"Plugin not installed: {node}/{strategy}") from e


class ExecutionFailed(RuntimeError):
    def __init__(self, execution_id: str, message: str):
        self.execution_id = execution_id
        super().__init__(f"{execution_id}: {message}")


class Context:
    def __init__(self, store: Store, ex: dict, work: Path):
        self.store, self.ex, self.work = store, ex, work
        self.commands = 0

    def emit(self, event: str, **data):
        self.store.event(self.ex["id"], event, data)

    def path(self, relative: str) -> Path:
        path = confined(self.work, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def input(self, role: str) -> Path:
        return Path(self.store.artifact(self.ex["inputs"][role])["absolute_path"])

    def input_json(self, role: str):
        return read_json(self.input(role))

    def execute(self, argv: list[str], timeout: float = 600) -> subprocess.CompletedProcess:
        if not argv or not all(isinstance(x, str) for x in argv):
            raise TypeError("Command must be an argv list, never a shell string")
        self.commands += 1
        stem = f"raw/command-{self.commands:03d}"
        out, err = self.path(stem + ".stdout.log"), self.path(stem + ".stderr.log")
        self.emit("command.started", argv=argv, timeout_seconds=timeout,
                  stdout=str(out.relative_to(self.work)), stderr=str(err.relative_to(self.work)))
        start = time.monotonic()
        with out.open("wb") as fo, err.open("wb") as fe:
            process = subprocess.Popen(argv, cwd=self.work, stdin=subprocess.DEVNULL,
                stdout=fo, stderr=fe, shell=False, start_new_session=True)
            try:
                rc = process.wait(timeout=timeout)
            except BaseException:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                self.emit("command.interrupted", elapsed_seconds=time.monotonic() - start)
                raise
        self.emit("command.finished", returncode=rc, elapsed_seconds=time.monotonic() - start,
                  stdout_sha512=sha512(out), stderr_sha512=sha512(err))
        if rc:
            # Raw diagnostic text is retained as an artifact, not copied into general logs.
            raise RuntimeError(f"Command failed with exit {rc}; see {stem}.stderr.log")
        return subprocess.CompletedProcess(argv, rc, out.read_bytes(), err.read_bytes())


class Engine:
    def __init__(self, store: Store, registry: Registry):
        self.store, self.registry = store, registry

    def execute(self, node: str, strategy: str, *, params: dict | None = None,
                inputs: dict[str, str] | None = None, models: list | None = None,
                scope: str = "video", run_id: str | None = None,
                retry_of: str | None = None) -> dict:
        params, inputs, models = params or {}, inputs or {}, models or []
        ensure_no_secrets(params)
        ensure_no_secrets(models)
        plugin = self.registry.get(node, strategy)
        # Input IDs pin specific versions. No "latest" resolution exists in this API.
        resolved = {k: self.store.artifact(v) for k, v in inputs.items()}
        provenance = code_provenance()
        request = {"node": node, "strategy": strategy, "scope": scope,
            "run_id": run_id or uid("run"), "retry_of": retry_of,
            "params": params, "params_sha512": digest(params), "inputs": inputs,
            "input_manifests": [{"role": k, **{x: v[x] for x in
                ("id", "execution_id", "sha512", "path", "schema_id")}} for k,v in resolved.items()],
            "models": models, "code": provenance,
            "strategy_version": plugin.implementation_version,
            "output_schema": plugin.output_schema,
            "runtime": {"python": platform.python_version(), "platform": platform.platform()},
            "result_cache": "disabled"}
        ex = self.store.allocate(request)
        folder = self.store.execution_dir(ex)
        with file_lock(folder / "lease.lock"):
            work = folder / "work"
            work.mkdir()
            # Archive the actual adapter/core source for replay, including a dirty worktree.
            project = Path(__file__).resolve().parents[1]
            with zipfile.ZipFile(folder / "source.snapshot.zip", "w", zipfile.ZIP_DEFLATED) as z:
                for item in provenance["source_files"]:
                    z.write(project / item["path"], item["path"])
            started = time.monotonic()
            state, failure = "SUCCEEDED", None
            try:
                # This call is unconditional. Content hashes never replace invocation.
                value = plugin.run(Context(self.store, ex, work), params)
                atomic_json(work / "result.json", value)
                validate(plugin.output_schema, value)
                if value.get("asset_sha512", self.store.asset) != self.store.asset:
                    raise ValueError("Plugin returned another asset's data")
            except BaseException as error:
                state, failure = "FAILED", error
                atomic_json(work / "error.json", {"type": type(error).__name__,
                    "message": str(error), "traceback": traceback.format_exc()})
            # Every attempt keeps partial output. Only SUCCEEDED artifacts are bindable.
            try:
                for p in work.rglob("*"):
                    if p.is_symlink():
                        raise ValueError("Plugin output symlinks are not publishable")
                    if p.is_file():
                        with p.open("rb") as f:
                            os.fsync(f.fileno())
                sealed = folder / "artifacts"
                os.replace(work, sealed)
                fsync_dir(folder)
                artifacts = []
                for p in sorted(sealed.rglob("*")):
                    if p.is_file():
                        name = str(p.relative_to(sealed))
                        artifacts.append({"id": uid("art"), "name": name,
                            "path": str(p.relative_to(self.store.base)),
                            "sha512": sha512(p), "size": p.stat().st_size,
                            "schema_id": plugin.output_schema if name == "result.json" else None,
                            "producer_execution_id": ex["id"],
                            "parents": [{"role": role, "artifact_id": aid} for role, aid in inputs.items()],
                            "lineage_granularity": "conservative_all_consumed_inputs"})
                        p.chmod(0o444)
            except BaseException as error:
                state, failure, artifacts = "FAILED", error, []
            manifest = {"schema": "execution.v1", "execution_id": ex["id"],
                "asset_sha512": self.store.asset, "node": node, "strategy": strategy,
                "version": ex["version"], "state": state, "started_at": ex["started_at"],
                "ended_at": now(), "duration_seconds": time.monotonic() - started,
                "request_sha512": sha512(folder / "request.json"),
                "source_snapshot_sha512": sha512(folder / "source.snapshot.zip"),
                "artifacts": artifacts,
                "inputs": ex["input_manifests"], "code": provenance,
                "models": models, "params": params, "params_sha512": ex["params_sha512"],
                "retry_of": retry_of, "run_id": ex["run_id"],
                "strategy_version": plugin.implementation_version,
                "error_type": type(failure).__name__ if failure else None}
            atomic_json(folder / "manifest.json", manifest)
            self.store.commit(ex, manifest)
            if failure:
                raise ExecutionFailed(ex["id"], type(failure).__name__) from failure
            return manifest

    def retry(self, execution_id: str) -> dict:
        old = self.store.get_execution(execution_id)["request"]
        return self.execute(old["node"], old["strategy"], params=old["params"],
            inputs=old["inputs"], models=old["models"], scope=old["scope"],
            retry_of=execution_id)


def output_id(manifest: dict, name="result.json") -> str:
    return next(a["id"] for a in manifest["artifacts"] if a["name"] == name)
