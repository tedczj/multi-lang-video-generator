from __future__ import annotations
from array import array
from fractions import Fraction as F
import json
from pathlib import Path
import sys
import wave
from .timeline import verify


def read_pcm(path: Path, sr=48000) -> array:
    with wave.open(str(path), "rb") as w:
        if (w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getcomptype()) != (2,2,sr,"NONE"):
            raise ValueError("Reference renderer requires stereo PCM16 WAV at the plan sample rate")
        a = array("h")
        a.frombytes(w.readframes(w.getnframes()))
        if sys.byteorder != "little":
            a.byteswap()
        return a


def write_pcm(path: Path, a: array, sr: int) -> None:
    if sys.byteorder != "little":
        a = array("h", a)
        a.byteswap()
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(a.tobytes())


def render(ctx, timeline: dict, source_video: Path, source_wav: Path, dub_paths: dict) -> dict:
    verify(timeline)
    fps, sr = F(timeline["fps"]), timeline["sample_rate"]
    spf = F(sr, 1) / fps
    if spf.denominator != 1:
        raise ValueError("Reference renderer requires integral samples/frame; rational planner is broader")
    spf = int(spf)
    # Strict capabilities: no accidental VFR/start-PTS/rate conversion in this renderer.
    probe = json.loads(ctx.execute(["ffprobe", "-v", "error", "-select_streams", "v:0",
        "-count_frames", "-show_streams", "-of", "json", str(source_video)]).stdout)
    v = probe["streams"][0]
    if F(v["avg_frame_rate"]) != fps or int(v["nb_read_frames"]) != timeline["source_frames"]:
        raise ValueError("Canonical source frame count/rate does not match timeline")
    if abs(F(v.get("start_time", "0"))) > F(1, 1000000):
        raise ValueError("Normalize media origin before rendering")
    # Verify ALL input frame timestamps, not just average frame rate.
    pts = json.loads(ctx.execute(["ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_frames", "-show_entries", "frame=best_effort_timestamp_time", "-of", "json",
        str(source_video)]).stdout)["frames"]
    tolerance = max(F(v.get("time_base", "1/1000")), F(1, 1000000))
    if len(pts) != timeline["source_frames"] or any(abs(F(f["best_effort_timestamp_time"]) - F(i,1)/fps) > tolerance for i,f in enumerate(pts)):
        raise ValueError("Input is not canonical CFR")
    source = read_pcm(source_wav, sr)
    if len(source) != timeline["source_frames"] * spf * 2:
        raise ValueError("Source PCM length differs from canonical video")
    original_track = array("h")
    parts = []
    for i, p in enumerate(timeline["pieces"]):
        count = p["output_end_frame"] - p["output_start_frame"]
        if p["kind"] == "source":
            a, b = p["source_start_frame"], p["source_end_frame"]
            vf = f"trim=start_frame={a}:end_frame={b},setpts=PTS-STARTPTS"
            original_track.extend(source[a*spf*2:b*spf*2])
        else:
            a = p["source_hold_frame"]
            vf = f"trim=start_frame={a}:end_frame={a+1},setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop={count-1}"
            original_track.extend(array("h", [0]) * (count*spf*2))
        # Trim-to-one-frame may lose a usable output frame-rate hint. Rebuild
        # every decoded frame PTS explicitly; never trust tpad/auto-vsync here.
        vf += f",setpts=N/(({fps.numerator}/{fps.denominator})*TB)"
        part = ctx.path(f"chunks/part-{i:04d}.mkv")
        ctx.execute(["ffmpeg", "-v", "error", "-nostdin", "-i", str(source_video),
            "-vf", vf, "-an", "-frames:v", str(count), "-r", str(fps), "-fps_mode", "cfr", "-c:v", "ffv1", "-pix_fmt", "yuv420p", str(part)])
        parts.append(part)
    # All part paths are engine-generated; no untrusted text reaches concat syntax.
    listing = ctx.path("chunks/concat.txt")
    listing.write_text("".join(f"file 'part-{i:04d}.mkv'\n" for i in range(len(parts))))
    video = ctx.path("video.lossless.mkv")
    ctx.execute(["ffmpeg", "-v", "error", "-nostdin", "-f", "concat", "-safe", "1",
        "-i", str(listing), "-an", "-c:v", "copy", str(video)])
    mixed = array("h", original_track)
    for dub in timeline["dubs"]:
        audio = read_pcm(dub_paths[dub["utterance_id"]], sr)
        if len(audio) != dub["samples"] * 2:
            raise ValueError("Dub length changed after planning")
        posf = F(dub["start_seconds"]) * sr
        if posf.denominator != 1:
            raise ValueError("Dub onset is not sample-aligned")
        pos = int(posf) * 2
        if pos < 0 or pos+len(audio) > len(mixed):
            raise ValueError("Dub overflows timeline")
        for k, value in enumerate(audio):
            sample = mixed[pos+k] + value
            if not -32768 <= sample <= 32767:
                raise ValueError("Clipping risk; use a separately versioned mix policy")
            mixed[pos+k] = sample
    master = ctx.path("master.wav")
    write_pcm(master, mixed, sr)
    write_pcm(ctx.path("original.retimed.wav"), original_track, sr)
    preview = ctx.path("preview.mp4")
    ctx.execute(["ffmpeg", "-v", "error", "-nostdin", "-i", str(video), "-i", str(master),
        "-map", "0:v:0", "-map", "1:a:0", "-c:v", "libx264", "-crf", "18",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(preview)])
    return {"schema": "render.v1", "video": "video.lossless.mkv", "audio": "master.wav",
            "preview": "preview.mp4", "frames": timeline["output_frames"], "samples": len(mixed)//2}
