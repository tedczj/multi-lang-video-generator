from __future__ import annotations
import argparse
from array import array
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
from .engine import Engine,output_id
from .plugins import default_registry
from .store import Store
from .media import read_pcm,write_pcm
from .util import atomic_json,code_provenance,read_json,sha512


def tone(seconds,frequency,sr=48000):
    result=array('h')
    for k in range(round(seconds*sr)):
        value=round(3000*math.sin(2*math.pi*frequency*k/sr))
        result.extend((value,value))
    return result


def video_hashes(path):
    text=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:v:0',
                '-an','-pix_fmt','yuv420p','-f','framemd5','-'],text=True)
    return [row.rsplit(',',1)[-1].strip() for row in text.splitlines() if row and not row.startswith('#')]


def run_demo(out: Path):
    out=out.resolve()
    if out.exists() and any(out.iterdir()):raise ValueError('Demo output must be empty/nonexistent')
    out.mkdir(parents=True,exist_ok=True)
    sr,fps,duration=48000,25,12
    wav=out/'source.wav'
    src=array('h',[0])*(duration*sr*2)
    for start,end,freq in [(0.5,2,400),(6,7,500),(9,10,600)]:
        a=tone(end-start,freq);begin=round(start*sr)*2;src[begin:begin+len(a)]=a
    write_pcm(wav,src,sr)
    video=out/'source.mkv'
    subprocess.run(['ffmpeg','-v','error','-nostdin','-f','lavfi','-i',
        'testsrc2=size=160x96:rate=25:duration=12','-i',str(wav),'-map','0:v:0','-map','1:a:0',
        '-c:v','ffv1','-pix_fmt','yuv420p','-c:a','pcm_s16le',str(video)],check=True,timeout=60)
    spec={'fps':'25','sample_rate':sr,'source_frames':300,'utterances':[
        {'id':'u1','start_sample':24000,'end_sample':96000,'safe_cut_frame':150},
        {'id':'u2','start_sample':288000,'end_sample':336000,'safe_cut_frame':225},
        {'id':'u3','start_sample':432000,'end_sample':480000,'safe_cut_frame':300}]}
    spec_path=out/'spec.json';atomic_json(spec_path,spec)
    dub_paths={}
    for i,seconds in enumerate([1,3,2],1):
        path=out/f'dub_u{i}.wav';write_pcm(path,tone(seconds,800+i*200),sr);dub_paths[f'u{i}']=path
    store,receipt=Store.ingest(out/'workspace',video)
    engine=Engine(store,default_registry())
    source_manifest=engine.execute('source','local.register',params={'acquisition_id':receipt['id']})
    source_id=output_id(source_manifest)
    def imported(path,scope):
        manifest=engine.execute('import','file.snapshot',scope=scope,params={'path':str(path)},inputs={'source':source_id})
        return next(a['id'] for a in manifest['artifacts'] if a['name'].startswith('payload'))
    base_inputs={'spec':imported(spec_path,'spec'),'source':source_id}
    for ident,path in dub_paths.items():base_inputs['dub_'+ident]=imported(path,ident)
    timeline_manifest=engine.execute('timeline','gap_first',inputs=base_inputs,
                                     params={'pre_seconds':'1','post_seconds':'1'})
    plan_id=output_id(timeline_manifest)
    t=read_json(Path(store.artifact(plan_id)['absolute_path']))
    render_inputs={**{k:v for k,v in base_inputs.items() if k.startswith('dub_')},
                   'timeline':plan_id,'source':source_id,'source_wav':imported(wav,'original-audio')}
    rendered=engine.execute('render','ffmpeg.reference',inputs=render_inputs)
    def artifact(name):return Path(store.artifact(output_id(rendered,name))['absolute_path'])
    quality=engine.execute('qa','media.structural',inputs={'timeline':plan_id,
        'lossless_video':output_id(rendered,'video.lossless.mkv'),
        'master_audio':output_id(rendered,'master.wav'),'preview':output_id(rendered,'preview.mp4')})
    # Independent oracle: construct the expected sequence from source frame numbers.
    original_hashes=video_hashes(video)
    actual_hashes=video_hashes(artifact('video.lossless.mkv'))
    expected=[]
    for p in t['pieces']:
        if p['kind']=='source':expected+=original_hashes[p['source_start_frame']:p['source_end_frame']]
        else:expected += [original_hashes[p['source_hold_frame']]] * p['frames']
    assert actual_hashes==expected
    # Independent PCM oracle; no lossy AAC equality assertion.
    expected_audio=array('h')
    for p in t['pieces']:
        if p['kind']=='source':expected_audio.extend(src[p['source_start_frame']*1920*2:p['source_end_frame']*1920*2])
        else:expected_audio.extend(array('h',[0])*(p['frames']*1920*2))
    for d in t['dubs']:
        clip=read_pcm(dub_paths[d['utterance_id']]);index=int(F(d['start_seconds'])*sr)*2
        for k,v in enumerate(clip):expected_audio[index+k]+=v
    assert read_pcm(artifact('master.wav'))==expected_audio
    assert len(actual_hashes)==425 and len(expected_audio)//2==816000
    assert [u['hold_frames'] for u in t['utterances']]==[0,75,50]
    # Artifact exports for convenient inspection; the canonical versions remain in asset directory.
    for name in ['preview.mp4','master.wav','video.lossless.mkv']:
        shutil.copyfile(artifact(name),out/name)
    atomic_json(out/'timeline.json',t)
    qa=read_json(Path(store.artifact(output_id(quality))['absolute_path']))
    atomic_json(out/'qa.json',qa)
    evidence={'source_frames':300,'source_seconds':12,'output_frames':425,'output_seconds':17,
        'audio_samples':816000,'sample_rate':sr,'hold_frames':[0,75,50],
        'frame_order_exact':True,'pcm_exact':True,'source_sha512':store.asset,
        'qa_overall':qa['overall'],'code':code_provenance(),
        'actual_media_tools':subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0],
        'limitations':['Synthetic tones, not translated speech','No OCR/inpainting/voice cloning run',
                       'Exact comparison is on lossless video/PCM, not H264/AAC'],
        'timeline_execution':timeline_manifest['execution_id'],'render_execution':rendered['execution_id'],
        'qa_execution':quality['execution_id']}
    atomic_json(out/'verification.json',evidence)
    return evidence


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    print(json.dumps(run_demo(a.out),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
