from __future__ import annotations
from jsonschema import Draft202012Validator


def obj(properties, required=None, extra=False):
    return {"type": "object", "properties": properties,
            "required": list(properties) if required is None else required,
            "additionalProperties": extra}

STR = {"type": "string"}
INT = {"type": "integer", "minimum": 0}
NUMBER = {"type": "number", "minimum": 0}
CAPTION = obj({"cue_id": STR, "start_us": INT, "end_us": INT, "text": STR,
               "bbox_xyxy": {"oneOf": [{"type": "null"}, {"type": "array", "items": NUMBER,
                                "minItems": 4, "maxItems": 4}]},
               "confidence": {"type": ["number", "null"], "minimum": 0, "maximum": 1},
               "evidence": {"type": "array", "items": STR}})
CAPTIONS = obj({"schema": {"const": "captions.v1"}, "asset_sha512": STR,
                "coordinate_space": {"const": "canonical_video_pixels"},
                "cues": {"type": "array", "items": CAPTION},
                "warnings": {"type": "array", "items": STR}})
# Media/AI schemas are deliberately NOT represented by a permissive universal "success" object.
SCHEMAS = {
    "captions.v1": CAPTIONS,
    "source.v1": obj({"schema": {"const": "source.v1"}, "asset_sha512": STR,
                      "source_path": STR, "source_bytes": INT}),
    "file.v1": obj({"schema": {"const": "file.v1"}, "file": STR, "sha512": STR,
                    "original_name": STR}),
    "probe.v1": obj({"schema": {"const": "probe.v1"}, "probe": {"type": "object"}}, extra=False),
    "timeline.v1": obj({"schema": {"const": "timeline.v1"}, "fps": STR,
       "sample_rate": INT, "source_frames": INT, "output_frames": INT,
       "holds": {"type": "array", "items": {"type": "object"}},
       "pieces": {"type": "array", "items": {"type": "object"}},
       "dubs": {"type": "array", "items": {"type": "object"}},
       "utterances": {"type": "array", "items": {"type": "object"}},
       "pre_seconds": STR, "post_seconds": STR}),
    "render.v1": obj({"schema": {"const": "render.v1"}, "video": STR, "audio": STR,
                        "preview": STR, "frames": INT, "samples": INT}),
    "qa.v1": obj({"schema": {"const": "qa.v1"}, "overall": {"enum": ["PASS", "REVIEW", "FAIL"]},
                   "checks": {"type": "array", "items": {"type": "object"}}}),
    "fixture.v1": obj({"schema": {"const": "fixture.v1"}, "value": {}}, extra=False),
}


def validate(schema_id: str, value) -> None:
    Draft202012Validator(SCHEMAS[schema_id]).validate(value)
    if schema_id == "captions.v1":
        ids = set()
        for cue in value["cues"]:
            if cue["cue_id"] in ids or cue["end_us"] <= cue["start_us"]:
                raise ValueError("Duplicate cue ID or invalid subtitle interval")
            ids.add(cue["cue_id"])
            box = cue["bbox_xyxy"]
            if box is not None and (box[2] <= box[0] or box[3] <= box[1]):
                raise ValueError("Invalid XYXY box")
