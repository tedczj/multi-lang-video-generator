from __future__ import annotations
import contextlib
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import uuid


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds")


def uid(prefix: str) -> str:
    return prefix + "_" + uuid.uuid4().hex


def sha512(path: Path) -> str:
    h = hashlib.sha512()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value) -> str:
    return hashlib.sha512(canonical(value)).hexdigest()


def atomic_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".write-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(canonical(value) + b"\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
        fsync_dir(path.parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def fsync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


@contextlib.contextmanager
def file_lock(path: Path, blocking: bool = True):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        try:
            yield
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def safe_name(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,140}", value) or value in {".", ".."}:
        raise ValueError(f"Invalid identifier: {value!r}")
    return value


def confined(base: Path, relative: str) -> Path:
    p = Path(relative)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError("Absolute paths/path traversal not allowed")
    result = (base / p).resolve()
    if not result.is_relative_to(base.resolve()):
        raise ValueError("Path or symlink escapes its artifact root")
    return result


def ensure_no_secrets(value, path: str = "params") -> None:
    """Configuration stores secret REFERENCES only, never API keys/cookies."""
    prohibited = {"api_key", "apikey", "authorization", "password", "access_token",
                  "refresh_token", "cookie", "cookies", "secret"}
    if isinstance(value, dict):
        for k, v in value.items():
            if k.lower() in prohibited and v not in (None, ""):
                raise ValueError(f"Use a secret_ref/environment reference, not {path}.{k}")
            ensure_no_secrets(v, path + "." + k)
    elif isinstance(value, list):
        for v in value:
            ensure_no_secrets(v, path)


def code_provenance() -> dict:
    root = Path(__file__).resolve().parents[1]
    files = sorted((root / "vidflow").rglob("*.py"))
    files += [root / "pyproject.toml"] if (root / "pyproject.toml").exists() else []
    tree = [{"path": str(p.relative_to(root)), "sha512": sha512(p)} for p in files]
    result = {"git_commit": None, "dirty": None, "source_tree_sha512": digest(tree),
              "source_files": tree}
    try:
        result["git_commit"] = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, stderr=subprocess.DEVNULL,
            text=True, timeout=5).strip()
        result["dirty"] = bool(subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=root,
            stderr=subprocess.DEVNULL, text=True, timeout=5).strip())
    except (OSError, subprocess.SubprocessError):
        build = root / "BUILD_PROVENANCE.json"
        if build.exists():
            pinned = read_json(build)
            if pinned.get("source_tree_sha512") == result["source_tree_sha512"]:
                result.update(git_commit=pinned["git_commit"], dirty=False,
                              commit_source="verified_export_manifest")
    return result
