from __future__ import annotations
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
from .util import (atomic_json, canonical, confined, file_lock, fsync_dir, now,
                   read_json, safe_name, sha512, uid)

DDL = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS executions(
 id TEXT PRIMARY KEY, node TEXT NOT NULL, scope TEXT NOT NULL, version INTEGER NOT NULL,
 run_id TEXT NOT NULL, strategy TEXT NOT NULL, state TEXT NOT NULL,
 retry_of TEXT, started_at TEXT NOT NULL, ended_at TEXT, request_json TEXT NOT NULL,
 manifest_json TEXT, UNIQUE(node,scope,version));
CREATE TABLE IF NOT EXISTS artifacts(
 id TEXT PRIMARY KEY, execution_id TEXT NOT NULL REFERENCES executions(id),
 name TEXT NOT NULL, path TEXT NOT NULL, sha512 TEXT NOT NULL, size INTEGER NOT NULL,
 schema_id TEXT, UNIQUE(execution_id,name));
CREATE TABLE IF NOT EXISTS bindings(
 execution_id TEXT NOT NULL REFERENCES executions(id), role TEXT NOT NULL,
 artifact_id TEXT NOT NULL REFERENCES artifacts(id), PRIMARY KEY(execution_id,role));
CREATE TABLE IF NOT EXISTS events(
 seq INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT UNIQUE NOT NULL,
 at TEXT NOT NULL, execution_id TEXT, event TEXT NOT NULL, payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS selections(
 id TEXT PRIMARY KEY, at TEXT NOT NULL, name TEXT NOT NULL, artifact_id TEXT NOT NULL
 REFERENCES artifacts(id), reason TEXT NOT NULL);
"""


class Store:
    """Single-host local-filesystem store. JSONL is a recoverable DB event projection."""
    def __init__(self, root: Path, asset: str):
        if not re.fullmatch(r"[0-9a-f]{128}", asset):
            raise ValueError("asset must be the full lowercase SHA512")
        self.root, self.asset = Path(root).resolve(), asset
        self.base = self.root / "videos" / asset
        if not (self.base / "source" / "source.json").exists():
            raise FileNotFoundError("Asset has not been ingested")
        self.db = self.base / "index.sqlite"
        with self.connect() as con:
            con.execute("PRAGMA journal_mode=WAL")
            con.executescript(DDL)

    def connect(self):
        con = sqlite3.connect(self.db, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA synchronous=FULL")
        con.execute("PRAGMA busy_timeout=30000")
        return con

    @property
    def source(self) -> Path:
        meta = read_json(self.base / "source" / "source.json")
        path = confined(self.base, meta["path"])
        if sha512(path) != self.asset:
            raise ValueError("Source integrity check failed")
        return path

    @classmethod
    def ingest(cls, root: Path, original: Path, origin: dict | None = None):
        root, original = Path(root).resolve(), Path(original).resolve(strict=True)
        if not original.is_file():
            raise ValueError("Input must be a regular file")
        incoming = root / "incoming" / uid("local")
        incoming.mkdir(parents=True)
        snapshot = incoming / "input.snapshot"
        # Snapshot first; identity never comes from a mutable caller-owned inode.
        shutil.copyfile(original, snapshot)
        with snapshot.open("rb") as f:
            os.fsync(f.fileno())
        asset = sha512(snapshot)
        base = root / "videos" / asset
        with file_lock(root / "locks" / (asset + ".lock")):
            source_dir = base / "source"
            source_dir.mkdir(parents=True, exist_ok=True)
            dest = source_dir / "original.bin"
            if not dest.exists():
                os.replace(snapshot, dest)
                dest.chmod(0o444)
                fsync_dir(source_dir)
            elif sha512(dest) != asset:
                raise ValueError("Existing source is corrupt; refusing replacement")
            meta = source_dir / "source.json"
            if not meta.exists():
                atomic_json(meta, {"asset_sha512": asset, "path": "source/original.bin",
                                  "bytes": dest.stat().st_size, "created_at": now()})
        store = cls(root, asset)
        receipt = {"id": uid("acq"), "source_name": original.name,
                   "asset_sha512": asset, "origin": origin or {"kind": "local"},
                   "at": now()}
        acq = store.base / "acquisitions" / receipt["id"]
        acq.mkdir(parents=True)
        atomic_json(acq / "receipt.json", receipt)
        store.event(None, "source.ingested", receipt)
        shutil.rmtree(incoming)
        return store, receipt

    def event(self, execution_id, event: str, payload: dict) -> None:
        with self.connect() as con:
            con.execute("INSERT INTO events(event_id,at,execution_id,event,payload_json) VALUES(?,?,?,?,?)",
                        (uid("evt"), now(), execution_id, event, canonical(payload).decode()))
        self.flush_log()

    def flush_log(self) -> None:
        log = self.base / "events.jsonl"
        with file_lock(self.base / "locks" / "log.lock"):
            last = 0
            if log.exists():
                raw = log.read_bytes()
                complete_end = raw.rfind(b"\n") + 1
                if complete_end != len(raw):
                    # Interrupted final write: truncate only its incomplete tail.
                    with log.open("r+b") as f:
                        f.truncate(complete_end)
                if complete_end:
                    last = json.loads(raw[:complete_end].splitlines()[-1])["seq"]
            with self.connect() as con:
                rows = con.execute("SELECT * FROM events WHERE seq>? ORDER BY seq", (last,)).fetchall()
            with log.open("ab") as f:
                for r in rows:
                    item = dict(r)
                    item["payload"] = json.loads(item.pop("payload_json"))
                    item["asset_sha512"] = self.asset
                    f.write(canonical(item) + b"\n")
                f.flush()
                os.fsync(f.fileno())

    def allocate(self, request: dict) -> dict:
        node, scope = safe_name(request["node"]), safe_name(request["scope"])
        with self.connect() as con:
            con.execute("BEGIN IMMEDIATE")
            seq = con.execute("SELECT COALESCE(MAX(version),0)+1 FROM executions WHERE node=? AND scope=?",
                              (node, scope)).fetchone()[0]
            ex = {**request, "id": uid("exec"), "version": seq, "started_at": now()}
            con.execute("INSERT INTO executions(id,node,scope,version,run_id,strategy,state,retry_of,started_at,request_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (ex["id"], node, scope, seq, ex["run_id"], ex["strategy"], "RUNNING",
                         ex.get("retry_of"), ex["started_at"], canonical(ex).decode()))
            for role, artifact_id in request["inputs"].items():
                con.execute("INSERT INTO bindings VALUES(?,?,?)", (ex["id"], role, artifact_id))
        folder = self.execution_dir(ex)
        folder.mkdir(parents=True, exist_ok=False)
        atomic_json(folder / "request.json", ex)
        self.event(ex["id"], "execution.started", ex)
        return ex

    def execution_dir(self, ex: dict) -> Path:
        return self.base / "nodes" / ex["node"] / ex["scope"] / f'v{ex["version"]:06d}_{ex["id"]}'

    def get_execution(self, execution_id: str) -> dict:
        with self.connect() as con:
            row = con.execute("SELECT * FROM executions WHERE id=?", (execution_id,)).fetchone()
        if row is None:
            raise KeyError(execution_id)
        return {**dict(row), "request": json.loads(row["request_json"])}

    def artifact(self, artifact_id: str) -> dict:
        with self.connect() as con:
            row = con.execute("SELECT a.*,e.state FROM artifacts a JOIN executions e ON e.id=a.execution_id WHERE a.id=?",
                              (artifact_id,)).fetchone()
        if row is None or row["state"] != "SUCCEEDED":
            raise ValueError("Artifact does not exist or producer did not succeed")
        result = dict(row)
        path = confined(self.base, result["path"])
        if not path.is_file() or sha512(path) != result["sha512"]:
            raise ValueError("Artifact integrity check failed")
        result["absolute_path"] = str(path)
        return result

    def select(self, name: str, artifact_id: str, reason: str) -> str:
        self.artifact(artifact_id)
        selection_id = uid("selection")
        with self.connect() as con:
            con.execute("INSERT INTO selections VALUES(?,?,?,?,?)",
                        (selection_id, now(), name, artifact_id, reason))
        record = {"id": selection_id, "name": name, "artifact_id": artifact_id, "reason": reason}
        atomic_json(self.base / "selections" / (selection_id + ".json"), record)
        self.event(None, "artifact.selected", record)
        return selection_id

    def commit(self, ex: dict, manifest: dict) -> None:
        with self.connect() as con:
            con.execute("BEGIN IMMEDIATE")
            state = con.execute("SELECT state FROM executions WHERE id=?", (ex["id"],)).fetchone()[0]
            if state != "RUNNING":
                raise ValueError("Execution is already terminal")
            for artifact in manifest.get("artifacts", []):
                if manifest["state"] == "SUCCEEDED":
                    con.execute("INSERT INTO artifacts VALUES(?,?,?,?,?,?,?)",
                                (artifact["id"], ex["id"], artifact["name"], artifact["path"],
                                 artifact["sha512"], artifact["size"], artifact.get("schema_id")))
            con.execute("UPDATE executions SET state=?,ended_at=?,manifest_json=? WHERE id=?",
                        (manifest["state"], manifest["ended_at"], canonical(manifest).decode(), ex["id"]))
            con.execute("INSERT INTO events(event_id,at,execution_id,event,payload_json) VALUES(?,?,?,?,?)",
                        (uid("evt"), now(), ex["id"], "execution.finished", canonical(manifest).decode()))
        self.flush_log()

    def recover(self, execution_id: str) -> str:
        row = self.get_execution(execution_id)
        if row["state"] != "RUNNING":
            self.flush_log()
            return row["state"]
        ex = row["request"]
        folder = self.execution_dir(ex)
        with file_lock(folder / "lease.lock", blocking=False):
            sealed = folder / "manifest.json"
            if sealed.exists():
                manifest = read_json(sealed)
                for a in manifest.get("artifacts", []):
                    if sha512(confined(self.base, a["path"])) != a["sha512"]:
                        raise ValueError("Recovery found corrupt sealed artifact")
            else:
                manifest = {"execution_id": execution_id, "state": "ABANDONED", "ended_at": now(),
                            "artifacts": [], "reason": "No sealed manifest; old partial work retained"}
                atomic_json(sealed, manifest)
            self.commit(ex, manifest)
            return manifest["state"]
