from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from .acquire import download
from .engine import Engine, ExecutionFailed
from .plugins import default_registry
from .store import Store
from .util import code_provenance, read_json


def main():
    p = argparse.ArgumentParser(prog="vidflow")
    p.add_argument("--root", type=Path, default=Path("workspace"))
    commands = p.add_subparsers(dest="command", required=True)
    q = commands.add_parser("ingest"); q.add_argument("path", type=Path)
    q = commands.add_parser("download"); q.add_argument("url"); q.add_argument("--height", type=int, default=1080)
    q = commands.add_parser("run"); q.add_argument("asset"); q.add_argument("node"); q.add_argument("strategy")
    q.add_argument("--models", type=Path); q.add_argument("--params", type=Path); q.add_argument("--inputs", type=Path); q.add_argument("--scope", default="video")
    q = commands.add_parser("retry"); q.add_argument("asset"); q.add_argument("execution")
    q = commands.add_parser("recover"); q.add_argument("asset"); q.add_argument("execution")
    q = commands.add_parser("pipeline"); q.add_argument("asset"); q.add_argument("recipe", type=Path)
    commands.add_parser("doctor")
    args = p.parse_args()
    try:
        if args.command == "ingest":
            s, receipt = Store.ingest(args.root, args.path)
            m = Engine(s, default_registry()).execute("source", "local.register", params={"acquisition_id": receipt["id"]})
            result = {"asset_sha512": s.asset, "execution": m}
        elif args.command == "download":
            s, receipt = download(args.root, args.url, height=args.height)
            m = Engine(s, default_registry()).execute("source", "local.register", params={"acquisition_id": receipt["attempt_id"]})
            result = {"asset_sha512": s.asset, "download": receipt, "execution": m}
        elif args.command == "doctor":
            import shutil, subprocess
            result = {"python": sys.version, "code": code_provenance(), "binaries": {},
                      "missing": [], "note": "Does not assert model readiness or YouTube reachability"}
            for name in ("ffmpeg", "ffprobe"):
                binary = shutil.which(name)
                result["binaries"][name] = binary
                if not binary: result["missing"].append(name)
            import importlib.util
            result["yt_dlp_installed"] = importlib.util.find_spec("yt_dlp") is not None
        else:
            s = Store(args.root, args.asset)
            e = Engine(s, default_registry().discover())
            if args.command == "run":
                result = e.execute(args.node, args.strategy, scope=args.scope,
                    params=read_json(args.params) if args.params else {},
                    inputs=read_json(args.inputs) if args.inputs else {},
                    models=read_json(args.models) if args.models else [])
            elif args.command == "pipeline":
                from .pipeline import run_recipe
                result = run_recipe(e, read_json(args.recipe))
            elif args.command == "retry": result = e.retry(args.execution)
            else: result = {"state": s.recover(args.execution)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as error:
        print(json.dumps({"error": str(error), "type": type(error).__name__,
                          "execution_id": getattr(error,"execution_id",None)},ensure_ascii=False),file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
