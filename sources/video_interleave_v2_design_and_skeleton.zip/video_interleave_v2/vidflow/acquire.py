from __future__ import annotations
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from urllib.parse import urlparse, parse_qs
from .store import Store
from .util import atomic_json, canonical, code_provenance, now, read_json, uid, sha512


def youtube_url(value: str) -> str:
    u = urlparse(value)
    if u.scheme not in {"http", "https"} or u.username or u.password or u.port not in (None,443):
        raise ValueError("Only a YouTube page URL is accepted")
    host = (u.hostname or "").lower()
    allowed = {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtu.be"}
    if host not in allowed:
        raise ValueError("Host is not an allowed YouTube page host")
    if host.endswith("youtu.be"):
        ident = u.path.strip("/")
    elif u.path.rstrip("/") == "/watch":
        ident = parse_qs(u.query).get("v", [""])[0]
    elif u.path.startswith(("/shorts/", "/embed/", "/live/")):
        ident = u.path.strip("/").split("/")[-1]
    else:
        raise ValueError("A single video, not a channel/playlist, is required")
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", ident):
        raise ValueError("Invalid YouTube video ID")
    return "https://www.youtube.com/watch?v=" + ident


def ytdlp_argv(url: str, directory: Path, height: int = 1080) -> list[str]:
    if not isinstance(height, int) or not 144 <= height <= 4320:
        raise ValueError("height must be between 144 and 4320")
    return [sys.executable, "-m", "yt_dlp", "--ignore-config", "--no-playlist",
        "--no-simulate", "--no-download-archive", "--no-cache-dir", "--no-continue",
        "--force-overwrites", "--abort-on-error", "--retries", "3", "--fragment-retries", "3",
        "--socket-timeout", "30", "--format", f"bv*[height<={height}]+ba/b[height<={height}]",
        "--merge-output-format", "mkv", "--write-info-json", "--write-subs", "--write-auto-subs",
        "--sub-langs", "en.*,en", "--sub-format", "vtt/srt/best",
        "--output", str(directory / "source.%(ext)s"),
        "--print-to-file", "after_move:%(filepath)j", str(directory / "final-path.jsonl"),
        "--", youtube_url(url)]


def download(root: Path, url: str, *, height=1080, timeout=3600) -> tuple[Store, dict]:
    """Actual network adapter. Every invocation has a fresh directory (no result cache).

    Failed unbound acquisitions remain in incoming/: no content hash exists yet.
    Only call for media the operator is authorized to download and process.
    """
    root = Path(root).resolve()
    attempt_id = uid("download")
    directory = root / "incoming" / attempt_id
    directory.mkdir(parents=True, mode=0o700)
    request = {"attempt_id": attempt_id, "node": "acquire", "strategy": "yt_dlp.cli",
               "url": youtube_url(url), "height": height, "started_at": now(),
               "code": code_provenance(), "result_cache": "disabled"}
    atomic_json(directory / "request.json", request)
    cmd = ytdlp_argv(url, directory, height)
    request["argv"] = cmd
    atomic_json(directory / "request.json", request)
    start = time.monotonic()
    try:
        with (directory / "stdout.log").open("wb") as out, (directory / "stderr.log").open("wb") as err:
            process = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                       shell=False, start_new_session=True)
            try:
                rc = process.wait(timeout=timeout)
            except BaseException:
                import signal
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                raise
        if rc:
            raise RuntimeError(f"yt-dlp returned {rc}; inspect {directory / 'stderr.log'}")
        paths = [json.loads(line) for line in (directory / "final-path.jsonl").read_text().splitlines() if line.strip()]
        if len(paths) != 1:
            raise RuntimeError("Expected exactly one postprocessed media file")
        media = Path(paths[0]).resolve(strict=True)
        if not media.is_relative_to(directory) or media.suffix == ".part":
            raise ValueError("Invalid final downloaded media path")
        probe = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-of", "json", str(media)],
                               capture_output=True, check=True, timeout=60)
        streams = json.loads(probe.stdout)["streams"]
        if not any(s["codec_type"] == "video" for s in streams) or not any(s["codec_type"] == "audio" for s in streams):
            raise ValueError("Downloaded file must contain video and audio")
        atomic_json(directory / "probe.json", json.loads(probe.stdout))
        version = subprocess.check_output([sys.executable, "-m", "yt_dlp", "--version"], text=True, timeout=10).strip()
        store, receipt = Store.ingest(root, media, origin={"kind": "youtube", "url": request["url"],
                                                         "download_attempt_id": attempt_id})
        inventory = [{"path": str(f.relative_to(directory)), "sha512": sha512(f), "bytes": f.stat().st_size}
                     for f in sorted(directory.rglob("*")) if f.is_file()]
        request.update(files=inventory, state="SUCCEEDED", ended_at=now(), duration_seconds=time.monotonic()-start,
                       asset_sha512=store.asset, yt_dlp_version=version)
        atomic_json(directory / "outcome.json", request)
        destination = store.base / "acquisitions" / attempt_id
        os.replace(directory, destination)
        # The reference adapter intentionally retains its downloaded copy as evidence.
        # Physical deduplication is a separate future storage policy, never a skip rule.
        directory = destination  # Exception reporting must follow the moved directory.
        request["archive_path"] = str(destination.relative_to(store.base))
        store.event(None, "acquire.completed", request)
        return store, request
    except BaseException as e:
        atomic_json(directory / "outcome.json", {**request, "state": "FAILED", "ended_at": now(),
                    "duration_seconds": time.monotonic()-start, "error_type": type(e).__name__, "error": str(e)})
        raise
