# YouTube 双语交替视频流水线开发设计

## 1. 架构结论与交付范围

采用**新建轻量项目骨架 + 专项组件复用 + 模型服务插件化**，不 fork pyVideoTrans、VideoLingo 等整套替换式配音应用。翻译及音色克隆/多语言语音由模型适配器完成；项目负责媒体证据、标准数据、时间线、版本、血缘、执行与验收。节点是否成功执行，与产物质量是否合格，是两个独立维度。

默认播放政策是 **gap_first_last_frame_hold_v1**：英文结束后 1 秒开始中文；原画面优先正常播放；到下一段英文前的安全切点，若中文和其后 1 秒尚未结束，就延长上一帧；之后原画面和原音同步恢复。中文后的间隔至少 1 秒，原片较长空档不被剪短。最后一句利用片尾，不足则补尾帧。英文原声不被替换，中文不加速、不裁尾以迁就原片长度。

### 1.1 本交付中已经实现、实际测试的内容

- Python 可运行骨架：SHA512 资产目录、SQLite 执行索引、不可覆盖的执行版本、参数/代码快照、输入版本绑定、文件哈希与血缘、统一 JSONL 日志、无缓存执行与重试、明确的 DAG 配方执行。
- 可替换插件接口、Python entry point 装载、外部进程 worker 协议，以及用于测试接口的两个**假 OCR**。假 OCR 绝不表示具备真实字幕识别能力。
- yt-dlp 下载适配器与命令构建、URL 限制、下载后真实文件定位、哈希归档。**没有在本环境运行实际 YouTube 下载**。
- 空档优先时间线、FFmpeg 参考合成器、真实 FFmpeg/ffprobe 集成测试，以及无损画面逐帧和 PCM 逐采样的独立校验。
- 单元测试、外部 worker 子进程测试、媒体集成测试；联网与真实 OCR 集成测试入口。

### 1.2 本交付没有冒充已实现的内容

真实字幕 OCR、自动字幕区域定位、VAD/ASR/说话者识别、去字幕修复、自动字体识别/排版、LLM 翻译、声音克隆、内容质量模型以及生产级流式长视频渲染，仍需按本文接口开发/接入。骨架不是从 URL 到真实双语成片的一键软件。示例声音是提示音，不是英文/中文配音。

最终运行状态和实际测试数见 `evidence/TEST_RESULTS_ZH.md`；上游源码定位、极短代码摘录与复用边界见 `docs/UPSTREAM_REFERENCES_ZH.md`；真实素材验收见 `docs/TEST_PLAN_ZH.md`。引用日期为 2026-09-09（America/Denver）；测试日志使用 UTC。

## 2. 项目骨架

### 2.1 稳定内核与业务实现分离

```text
video_interleave_v2/
├── pyproject.toml
├── vidflow/
│   ├── cli.py              # ingest / download / run / retry / recover / pipeline / doctor
│   ├── acquire.py          # URL → yt-dlp → 未绑定下载 → SHA512 资产登记
│   ├── store.py            # 资产目录、SQLite、版本、日志投影、恢复、显式选择
│   ├── engine.py           # 执行生命周期、插件注册、输入固定、发布及无条件重试
│   ├── pipeline.py         # 有向无环配方；每次调用所有纳入步骤均重新执行
│   ├── contracts.py        # 骨架已实现节点的 JSON Schema 与语义校验
│   ├── util.py             # SHA512、原子写、路径约束、锁、代码快照指纹
│   ├── plugins.py          # 已实现策略与通用 worker 适配器
│   ├── timeline.py         # 纯函数：自然空档优先；有理数时间和不变量
│   ├── media.py            # FFmpeg/PCM 参考执行器，不是生产流式渲染器
│   └── demo.py             # 实际媒体回归样例与独立 oracle
├── tests/                  # 无网络测试：目录、重试、版本、契约、时间线、DAG
├── integration/            # 实际 FFmpeg；显式启用的真实外部集成
├── examples/               # 配方、真实 OCR 配置模板
├── docs/                   # 来源、字段协议、测试与开发路线
└── evidence/               # 本次执行结果、样例和日志
```

建议后续扩展为独立包，但保持现有内核接口稳定：

```text
workers/
├── subtitle_inventory/    # 软字幕流/旁挂文件/硬字幕证据
├── ocr_paddle/            # 参考 VSE/VideOCR；独立依赖环境
├── ocr_vlm/               # 例如 qwen_vl_ocr；相同 CaptionTrack 契约
├── speech_alignment/     # WhisperX/VAD/说话者适配
├── subtitle_cleaning/    # VSR 包装，只消费其清理画面
├── style_analysis/       # 字体候选、渲染比对、中文字符覆盖
├── translation_model/    # 外部 LLM，保存请求响应，不继承配音软件框架
├── voice_model/          # 外部跨语言克隆模型/API
└── quality_models/       # 独立 ASR、OCR、视觉/语义检查

vidflow/production/
├── normalize.py          # 统一时基并保留源 PTS 映射
├── utterances.py         # 字幕/语音融合与安全切点
├── mask_builder.py       # 跟踪字框 → 帧掩膜
├── voice_reference.py    # 按说话者准备参考
├── layout.py             # ASS 双语排版
├── audio_mix.py          # 原音保护、背景声策略、译音响度
├── render_streaming.py   # 顺序解码、分块、背压、生产编码
└── publication.py        # 经质检显式发布，绝不以 latest 隐式覆盖
```

这些后续目录是**开发目标，不是已交付的空壳功能声明**。依赖重的模型 worker 不装进内核同一 venv。首版单机 CLI + 本地 SQLite 足够，GPU/MPS worker 可独立进程或 HTTP 服务；暂不引入 Kafka、Redis、分布式调度或大型 agent loop。

插件通过标准 Python entry points 装载；这是一种已有的包发现机制，而契约与执行政策由本项目定义。[R15] SQLite WAL 要求访问数据库的进程位于同一主机，因此索引放本地磁盘，不让多台机器经 SMB/NFS 共同写 WAL。[R14]

### 2.2 内核不能下放给插件的权力

版本号分配、源文件保护、输入版本解析、参数及代码存档、日志落地、产物校验、结果发布、重试次数及状态迁移，由内核统一负责。插件不能自行查找上次成功结果然后返回，不能覆盖旧目录，不能自选下游使用哪个版本，不能静默修改节点策略参数。

同进程插件视为可信业务代码，**不是安全沙箱**。面对不可信扩展，生产部署需要只读输入挂载、独立用户、工作目录/网络白名单和资源限制。路径检查和文件 chmod 不等同于防恶意插件的隔离。

## 3. 完整业务流程与节点责任

下表中每一行是独立的逻辑节点。长视频/多语种节点可以按场景、说话者、语句、语言分 scope 执行，每一个 scope 的每一次执行都有独立版本。

| 节点 | 输入 | 工作内容 | 标准输出 | 不满足条件时 |
|---|---|---|---|---|
| N00 acquire | YouTube 页面 URL | 校验单视频 URL，yt-dlp 下载及合流，保存字幕/元数据/进程日志 | AcquisitionReceipt | 无最终文件时保留 incoming 失败记录 |
| N01 source | 本地完整视频 | 独立复制快照，SHA512，建立资产与来源收据 | SourceAsset | 非完整文件/哈希异常失败 |
| N02 probe | SourceAsset | ffprobe 流、分辨率、时基、帧率、色彩、旋转、音轨和字幕清单 | MediaProbe | 不支持流/无音视频明确失败或单独策略 |
| N03 normalize | SourceAsset + Probe | 保留音画偏移的统一原点；必要时 VFR→CFR、音频 PCM 化；建立源/工作坐标映射 | CanonicalMedia + TimeMap | HDR/旋转/偏移没有支持策略时拒绝静默转换 |
| N04 subtitle_inventory | CanonicalMedia + 下载字幕 | 识别 soft/hard/mixed；选旁挂字幕文本；抽样定位目标字幕区域 | SubtitleInventory + ROITrack | 有字幕流不代表不存在硬字幕；不确定标记复核 |
| N05 ocr | CanonicalMedia + ROITrack | 提取文字、字框、出现时间、截图、置信度；去重并精化边界 | CaptionTrack | 不覆盖所有文字；短字幕和无结果单独报告 |
| N06 speech | 原始音频 + CanonicalMedia | VAD、ASR、词级对齐、说话者和重叠区域；保护所有原始讲话 | SpeechTrack | 不把低音量等同于无讲话；低置信边界复核 |
| N07 utterance | CaptionTrack + SpeechTrack | 语义归句；多 cue→一语句映射；找到不切词的安全帧切点 | UtteranceSet | 重叠讲话合并单元；没有安全切点则重分句 |
| N08 style | 原字幕截图 + 原样式信息 | 字体候选识别、重渲染比较、大小颜色描边位置；中文字体覆盖 | StyleProfile | 精确/近似/未知必须区分 |
| N09 masks | ROITrack + CaptionTrack | 字框时序跟踪、有限膨胀、镜头边界处理，生成允许修复的掩膜 | MaskTrack | 越界、过大区域或与标题混淆则复核 |
| N10 clean_video | CanonicalMedia + MaskTrack | 调用 VSR 修复，只保留清理画面；校验帧数/PTS；残字初检 | CleanVideo + CleanQA | 不能以“输出文件存在”判定成功 |
| N11 translate | UtteranceSet + 上下文/术语表 | LLM 生成每个 ID 的显示译文和朗读译文；校验数字/否定/实体 | TranslationSet | 多/少 ID、缺译文、结构错误失败；语义疑点复核 |
| N12 voice_reference | SpeechTrack + 原音频 | 按说话者选择干净且足够长的参考，保存准确参考文本和授权信息 | VoiceReferenceSet | 禁止跨说话者拼参考；无法满足则复核 |
| N13 synthesize | Translation + VoiceReference | 外部声音模型克隆并生成目标语言音频，不改视频时长 | RawDubClip + ModelReceipt | 不静默换成固定音色，失败保留请求响应 |
| N14 dub_prepare_qa | RawDubClip | 统一采样率；记录首尾静音策略；独立 ASR 检查漏读/重复/语言 | DubClip + ClipQA | 最多有限次重试，每次新版本；不能裁掉实际语音 |
| N15 timeline | CanonicalMedia + UtteranceSet + DubClip | 实测 PCM 时长；利用自然空档；安全切点补帧；计算全部媒体映射 | TimelinePlan | 语音冲突、不完整译音或无安全切点失败 |
| N16 subtitle_layout | Timeline + Caption/Translation + Style | 生成英文上、中文下的 ASS；原英文必要时上移；测量渲染框 | SubtitleLayout + ASS | 字形缺失、越界、重叠复核/失败 |
| N17 audio_mix | Timeline + 原音 + DubClip | 正常段保留原音；定格段暂停原音；中文混入；可选背景声策略 | AudioMaster | 原话/译话重叠、削波、采样长度不符失败 |
| N18 render | Timeline + CleanVideo + ASS + AudioMaster | 按统一计划补帧、烧字幕、编码；保留无损或高质中间产物 | RenderBundle | 编码返回码/全解码/时长不匹配失败 |
| N19 final_qa | RenderBundle + 所有检查所需版本 | 结构、字幕、声音、翻译、残字、冻结和质量检查 | QAReport | PASS/REVIEW/FAIL/SKIPPED，未执行不算通过 |
| N20 publish | RenderBundle + QAReport + 显式选择 | 创建不可变 release 引用与质量摘要 | ReleaseManifest | 不自动以最后完成版本覆盖已选版本 |

N05 与 N06 可并行；N08/N09/N10 与 N11/N12/N13 可分支执行；N15 必须等待被明确选择的译音完成；N18 是画面、声音、字幕的汇合点。首版为降低资源争抢，重模型串行，轻量检查可并行。

模型只拥有 N11/N13 等语义或生成任务，不决定时间戳、文件路径、调度行为或是否跳过重试。模型响应是不可信数据，不能拼成 shell 命令。

## 4. 下载：yt-dlp 接口与 SHA512 归档边界

### 4.1 必须先下载后确定资产目录

URL 不是源视频身份；YouTube video ID 也不是源视频字节身份。同一个页面采用不同格式/分辨率下载，或重新合流后文件字节变化，就可能有不同 SHA512。本文严格执行**实际输入完整视频文件的 128 位十六进制 SHA512 字符串**作为目录名，不用 URL 哈希冒充视频哈希。

```text
页面 URL
  → workspace/incoming/download_<uuid>/
  → 实际下载和合流完成
  → 读取 after_move 的最终媒体路径
  → ffprobe 检查最终文件
  → 对最终文件全字节计算 SHA512
  → workspace/videos/<sha512>/source/original.bin
  → 把此次下载的请求、元数据、字幕及日志归入同资产 acquisitions/<uuid>/
```

下载中断或 URL 失效时，没有可靠视频 SHA512，因此失败历史留在 `incoming/`。这是逻辑上不可消除的暂存阶段，不将未知内容强行归入某个资产。成功后同一次 acquisition 的全部历史再归档。若多个 URL 下载出字节完全相同的文件，源文件可共用，但每次 acquisition 和每次下游执行依然独立保留。

本地文件入口也先复制到拥有的快照再计算哈希，防止原路径被外部应用修改。源视频不覆盖、不“规范化后覆盖回 source”。`original.bin` 是内容探测文件，原扩展名/容器信息在 metadata 中保存；工作视频另产出版本。

### 4.2 下载调用政策

直接复用 yt-dlp CLI。官方提供 `after_move` 阶段获取最终文件路径；合流前猜测扩展名容易引用错误文件。[R01] 核心配置如下，实际构建函数是 `vidflow/acquire.py::ytdlp_argv`：

```text
--ignore-config
--no-playlist
--no-simulate
--no-download-archive
--no-cache-dir
--no-continue
--force-overwrites
--abort-on-error
--format bv*[height<=1080]+ba/b[height<=1080]
--merge-output-format mkv
--write-info-json --write-subs --write-auto-subs
--sub-langs en.*,en
--print-to-file after_move:%(filepath)j <本次独立目录>/final-path.jsonl
```

`--force-overwrites` 只作用于新 attempt 的临时目录，绝不能指向旧资产产物。`--retries` / `--fragment-retries` 是一次下载内的传输重试，不替代节点级新版本重试；日志需要能看出内部传输次数。首次只支持单个点播视频，不做播放列表、直播等待、DRM 绕过或权限绕过。生产接入应补充下载前的点播/live 状态检查、时长/大小上限及网络域名策略。

yt-dlp 当前完整 YouTube 支持还依赖受支持的 JS runtime 与 EJS 组件；不是只安装 Python 包即可假定所有视频可下载。FFmpeg/ffprobe 是外部二进制。[R01][R02] 部署时运行受控冒烟测试并锁定版本；任务中禁止自动升级工具或隐式下载不受控执行组件。下载器升级后是新的代码/运行环境版本，同样允许原输入重做。

授权 cookies 通过 secret_ref 在运行时注入，不入 params 明文、日志或产物包；绝不默认导出整套浏览器身份数据。字幕、标题、info.json 均为外部数据，不能执行其中指令。

## 5. 资产目录、版本与血缘

### 5.1 目录定义

```text
workspace/
├── incoming/                           # SHA512 未知的获取尝试
├── locks/                              # 同哈希登记并发锁
└── videos/<完整128字符sha512>/
    ├── source/
    │   ├── original.bin                # 本资产不可变源快照
    │   └── source.json                 # bytes/hash/origin/type
    ├── acquisitions/<acquisition_id>/  # 每一次获取独立；失败历史可后绑定
    ├── index.sqlite                   # 资产本地索引，不作为唯一事实来源
    ├── index.sqlite-wal / -shm         # SQLite 运行文件，不单独拷贝做快照
    ├── events.jsonl                    # 此资产唯一汇总业务日志，单调seq
    ├── runs/<run_id>/
    │   ├── plan.json                   # 不可变 DAG 配方
    │   ├── steps/<step_key>.json       # 本run实际输入/输出版本绑定
    │   └── result.json                 # 完成/失败，不改写上次run
    ├── nodes/<node>/<scope>/
    │   ├── v000001_exec_<uuid>/
    │   │   ├── request.json            # 执行前封存请求
    │   │   ├── source.snapshot.zip     # 当次实际内核/适配代码快照
    │   │   ├── lease.lock
    │   │   ├── work/                   # 执行中；中断保留；成功后重命名
    │   │   ├── artifacts/              # result.json及所有媒体/原始响应/日志
    │   │   └── manifest.json           # 终态、血缘、完整文件清单、用时
    │   ├── v000002_exec_<uuid>/         # 即使参数和文件哈希相同也新增
    │   └── ...
    ├── selections/<selection_id>.json # 追加式“选择哪个产物”记录
    └── releases/<release_id>/          # 拟实现：发布引用，不覆盖旧成片
```

每个资产都拥有自身数据库和汇总日志。原始 stdout/stderr 不是第二份业务主日志，是某次节点执行的原始证据，保存在该次产物内，并由 `events.jsonl` 引用。

下载器目前保留下载副本及 source 快照以保证证据直观；后续可做物理块级去重，但**存储去重不得变成执行去重**。相同哈希的两个执行产物仍有不同 artifact_id。

### 5.2 五类身份不可混用

| 身份 | 示例 | 语义 |
|---|---|---|
| asset_id | 输入视频 SHA512 | 字节相同源视频聚合 |
| run_id | run_<uuid> | 一次完整/局部配方运行 |
| execution_id | exec_<uuid> | 某逻辑节点某scope的一次实际执行 |
| logical version | ocr/video/v000003 | 同节点同scope单调版本，不按策略分开重置 |
| artifact_id | art_<uuid> | 当次执行发布的某一个文件，不等于文件哈希 |

同一 asset 的 `ocr/video`：第一次 Paddle 为 v1，第二次 Qwen VL 为 v2，再次 Paddle 重試为 v3。版本号说明发生顺序，不说明质量更好。精确引用必须使用 artifact_id 或 execution_id+输出名，不使用“最高版本就最好”。

按语句分 scope 时，可用 `u001.zh-CN`。不同 OCR/归句版本中的 u001 不一定是同一语义单元；可靠身份应是 `(utterance_set_artifact_id, utterance_id)`，不能跨版本按行号、下标或同名 ID 混用。

### 5.3 文件清单与完整血缘

每个执行的 manifest 至少包含：源 SHA512、run/execution/retry_of、节点/策略/版本、代码快照、参数快照及哈希、模型信息、输入 artifact_id+文件哈希、所有输出/原始日志/失败残留的文件清单、起止时间和耗时。

每个文件对象至少包含：

```json
{
  "id": "art_<本次唯一id>",
  "name": "captions.json",
  "path": "nodes/ocr/video/v000003_exec_.../artifacts/captions.json",
  "sha512": "<实际文件128字符sha512>",
  "size": 24891,
  "schema_id": "captions.v1",
  "producer_execution_id": "exec_...",
  "parents": [
    {"role": "video", "artifact_id": "art_<canonical-video>"},
    {"role": "roi", "artifact_id": "art_<roi-track>"}
  ],
  "lineage_granularity": "conservative_all_consumed_inputs"
}
```

骨架采用保守血缘：一个执行产生的每个文件都关联该执行实际消费的所有输入。不会虚构细到某个字来自哪个像素的因果关系。生产扩展可增加 `derived_from` 精确区间，如帧 [120,180)、音频采样 [96000,144000)，并保留全节点依赖兜底。外部手工导入文件必须是 `import` 新执行，记录外部来源及本地快照，不把其伪装为某个模型自动产生。

如果不同节点产物文件字节相同，依然保存不同 producer execution 和 lineage；内容哈希仅用于完整性和物理去重。文件被篡改时下游读取失败，不能悄悄重算并假装它还是旧产物。

### 5.4 参数、模型与策略版本

```text
代码身份 = 仓库地址 + git commit + dirty标记 + 实际源码树哈希
策略身份 = 节点ID + 策略ID + 策略实现版本 + 契约版本
配置身份 = canonical JSON 参数哈希 + 提示词模板哈希 + 术语表artifact
运行身份 = Python/OS/设备 + dependency lock + worker镜像或wheel哈希
模型身份 = provider + requested model + resolved revision + 权重/配置哈希
执行身份 = execution_id + run_id + 时间 + 日志
```

参数哈希使用确定性 JSON 序列化，不用字典打印顺序；禁止 NaN。模型 temperature、top_p、seed、量化、语言、参考音频哈希、参考文本、输出采样率等都要显式记录。API key/cookie 不参与明文配置，只记录 secret_ref 的标识/版本，不记录秘密本身。

git commit 相同而工作树有改动，不能当成相同逻辑。骨架保存 dirty 状态、实际源码树每文件哈希及 source.snapshot.zip。生产插件还应记录独立 worker 源码 commit、wheel/container digest、依赖锁、模型文件 revision；仅内核 commit 不足以代表远程 worker。

`ModelReceipt` 需要区分 requested_model 与 resolved_model。服务端不公开具体权重修订时，保存返回模型名、request_id、时间、usage、请求/响应哈希，并标记 `reproducibility=PARTIAL_PROVIDER_OPAQUE`。不能编造一个权重哈希。固定 seed 也不承诺 GPU/API 跨环境位级确定性。

日志是执行证据，不应把日志文件内容纳入策略指纹形成循环依赖。manifest 引用日志；日志事件反向带 execution_id 和策略版本，已满足“commit+策略标识+参数+日志”的追溯要求。

### 5.5 数据库与文件如何共同恢复

骨架用 SQLite 保存 executions、artifacts、bindings、events、selections；文件 manifest 是可离线检查的结果事实，数据库是事务索引。执行序列如下：

```text
校验请求及固定输入版本
→ BEGIN IMMEDIATE 分配节点scope版本和execution
→ 封存request，创建独占work，写START日志
→ 取得lease，运行策略（始终实际调用）
→ 保存raw响应/产物，校验契约、哈希和媒体条件
→ fsync产物，work原子改名为artifacts
→ 封存manifest
→ 数据库事务：终态+产物索引+终态事件同时提交
→ 按seq将数据库事件投影到events.jsonl并fsync
```

文件系统与 SQLite 不存在跨介质的单个原子事务，不能宣称“整个保存绝对原子”。因此必须支持恢复：

- 无 sealed manifest 且原 worker 已退出：旧 attempt 标记 ABANDONED，保留 work，新的 retry 新目录。
- 有 sealed manifest、DB 仍 RUNNING：验证文件哈希后补提交，不重新运行旧 attempt。
- DB 已提交、日志尚未投影：重放缺失 seq；日志尾部半行修复后继续，不重复完整事件。
- 旧 worker 仍持有 lease：不恢复、不抢占；人工超时先终止进程再检查。远程 worker 需要后续增加 fencing token 和心跳，拒绝迟到结果发布。

`recover` 是状态/证据恢复，不是业务 retry。`retry` 始终产生新执行。生产实现还应给 ABANDONED 的部分 work 生成完整文件哈希清单、补全全部提交窗口的 kill -9 注入测试；当前骨架只实现基础恢复与 lease 防护，不能称完整分布式事务系统。

## 6. 插件接口与节点标准数据

### 6.1 插件协议

已实现的内核形式：

```python
@dataclass(frozen=True)
class Strategy:
    node: str
    id: str
    output_schema: str
    run: Callable
    implementation_version: str = "1"
```

`run(ctx, params)` 只读取 `ctx.input(role)` 指定的固定版本，在 `ctx.path(relative)` 下写入本次产物，然后返回标准 JSON。`ctx.execute(argv, timeout)` 使用参数数组、禁 shell、禁 stdin 等待、进程组超时终止、保留 stdout/stderr 和返回码。插件异常或契约校验失败，该次执行 FAILED，已有中间文件保留但不能成为下游正式输入。

每个节点需要定义输入端口的 artifact type、版本范围、必要角色、输出 Schema 和语义不变量。JSON Schema 能校验字段，但不能证明字体真实、字幕正确、时间未错位；这些需要节点校验器。

生产输入端口验证需要检查：同 asset、同 canonical basis、时间区间合法、字框不越界、语言和说话者引用有效、SHA512正确、质量门禁满足。骨架已验证资产/文件完整性与部分契约，业务层仍需补齐具体 ports 校验。

### 6.2 外部 worker 协议

所有模型进程采用：

```text
<worker executable> --request /absolute/request.json --result /absolute/result.json
```

内核传入 execution_id、asset_sha512、strategy、params、models、固定输入路径、只读源路径、本次 output_dir 及 `cache_policy=NO_RESULT_REUSE`。worker 把标准结果写入 result.json，把截图/模型原始响应/WAV等写入 output_dir。

路径由内核生成；模型输出不得指定任意宿主路径。对远程 worker，替换为短期读授权和按 execution 分区的上传地址，不能把本地绝对路径误当成远程可读文件。状态回报必须绑定 execution_id/fencing token。

推荐 worker 返回 `runtime.json` 和 `model_receipt.json`：实际运行 git/wheel/镜像版本、实际参数、实际模型 revision、缓存行为、设备、首尾时间、token/费用计量字段（可为空）及请求 ID。配置中的模型声明与实际回执不一致时，标记错误或降为不可完全复现，不伪造一致性。

### 6.3 替换 OCR 而不修改下游

统一语义结果是 `captions.v1`：

```json
{
  "schema": "captions.v1",
  "asset_sha512": "<实际视频SHA512>",
  "coordinate_space": "canonical_video_pixels",
  "cues": [
    {
      "cue_id": "c00018",
      "start_us": 12500000,
      "end_us": 14900000,
      "text": "This is an example.",
      "bbox_xyxy": [240, 860, 1670, 1010],
      "confidence": 0.96,
      "evidence": ["frames/c00018.png"]
    }
  ],
  "warnings": []
}
```

坐标为左上右下 `[x_min,y_min,x_max,y_max]`，半开区间。源坐标/缩放坐标必须映射回 canonical，不把上游 `[xmin,xmax,ymin,ymax]` 直接填进来。时间统一相对 canonical 媒体原点，整数微秒，精确媒体运算用采样/帧/有理数。多边形、单字框、候选词、置信度解释、原始结果放独立 raw/evidence 文件，不污染下游通用字段。

置信度不必数值跨模型可比：VLM未提供概率时为 null，不能把自称“很确定”映射为 0.99。下游处理不依赖 Paddle 内部对象或 VLM 特定响应格式。

对比流程：

```text
同一 canonical video + 同一 ROI 版本
  → OCR paddle_ocr / v1
  → OCR qwen_vl_ocr / v2
  → 各自独立产物及日志
  → OCR comparison 新节点：文本CER、时间IoU、区域IoU、漏字、用时、成本
  → 显式选择一个artifact
  → 新run固定引用所选版本
```

v1 的后续归句/翻译不会因 v2 完成而偷偷读取 v2。修改选择不改写已有成片血缘。按字幕时间/内容对齐后比较，不使用两份结果的同一行号代表同一字幕。

### 6.4 其余节点必须遵循的标准数据

完整字段约束及单位在 `docs/DATA_CONTRACTS_ZH.md`。关键类型：

| 类型 | 必须保存的业务信息 |
|---|---|
| CanonicalMedia | 源asset、原点偏移、video/audio artifact、帧率有理数、帧数、采样率/数、分辨率、色彩、TimeMap |
| SpeechTrack | 所有保护语音区间、词时间、说话者、重叠、对齐质量、fallback标识 |
| UtteranceSet | cue映射、实际语音起止采样、安全切帧、speaker_id、文本证据、重分句原因 |
| StyleProfile | 字体候选、实际选用字体文件哈希、CJK覆盖、字号/描边/颜色/阴影、精确或近似状态 |
| MaskTrack | 每段帧范围、掩膜 artifact、ROI、膨胀及插值策略、镜头边界 |
| TranslationSet | utterance复合身份、language、display_text、spoken_text、术语/上下文版本、质量状态 |
| VoiceReference | speaker复合身份、音频采样区间、参考音频哈希/转写、授权ref、质量 |
| DubClip | language、speaker、utterance、WAV artifact、采样率/数、首尾语音采样、模型回执ref |
| TimelinePlan | 原片段映射、定格位置/帧、译音绝对播放位置、总帧/采样、政策版本 |
| SubtitleLayout | ASS artifact、字体清单、逐事件源/译文映射、实际边界框、校验状态 |
| QAReport | 单项PASS/FAIL/REVIEW/SKIPPED、证据artifact/时间、策略参数、总状态 |

同一节点更换算法可以保持 schema；改变字段含义、坐标原点或时间语义必须升级 schema，不能偷偷兼容。迁移旧数据应是新的 adapter 节点执行，旧文件不原地改写。

## 7. 无条件重试、分支、选择与自动重跑

### 7.1 严格语义

执行 retry 表示**重新调用业务策略并重新产生新一版产物**，而不是“确认缓存还在”。输入/代码/模型/参数相同也必须运行。新的 execution_id、scope版本、目录、开始/结束日志、raw请求响应、模型服务请求 ID 全部独立。

骨架 `Engine.retry(execution_id)` 会复制旧输入 artifact 绑定与参数，调用当前安装策略，保存新代码版本并设置 retry_of。旧结果即便 SUCCEEDED 也允许重试。若要求严格复现旧代码，应选择固定旧镜像/worker版本，不能把“使用当前安装代码重试”冒充旧commit重放。

拒绝以下行为：

```text
if input_hash == previous_hash: return previous_output
if output_path.exists(): skip
if params_unchanged and strategy_unchanged: reuse
download_archive命中 → 当作重试成功
TTS按文本/音色结果缓存命中 → 当作新模型执行
```

模型权重、tokenizer、连接池驻留不属于结果缓存，可以复用；业务结果缓存必须关闭。即使新结果字节与旧结果完全一致，也要有新的文件身份与 producer。外部供应商是否内部缓存通常无法完全控制，因此保存 `provider_cache_behavior=unknown`，不承诺供应商一定重新完成底层推理；本系统保证实际重新发起调用。

### 7.2 传输重试与业务重试分开

HTTP一次调用在响应丢失时，可使用**同一执行内**的 request子序号/幂等键解决不确定投递，但不能跨两次业务retry沿用同一幂等键导致供应商返回旧结果。超时后的供应商任务是否已运行应记录 UNKNOWN，不伪造零费用/未执行。

自动重试政策可限定“最多2次”或按错误类型选择新策略；但一旦调度了某次 retry，执行不能因哈希不变跳过。策略切换必须在新执行里显式记录，不能在同一个标记为 paddle_ocr 的执行中静默换 qwen_vl_ocr。

### 7.3 重试一个节点与重跑下游不是同一动作

重试 OCR 默认只产生新 OCR，不改已有下游。通过显式选择新 OCR 及新配方，才重跑归句/翻译/配音/时间线/成片。已有 CleanVideo 是否可沿用，取决于它绑定的 MaskTrack 是否仍被选用，而不是看 node_name 相同。

配方中纳入的节点每次都运行；希望沿用已有产物时，在新配方中把它写成固定 artifact 输入，而不纳入生产该产物的节点。此动作叫**显式绑定历史产物**，不叫“节点已执行但被缓存跳过”。骨架不存在自动 latest 解析。

`resume` 若以后支持从 checkpoint继续，应是独立操作和策略，记录 checkpoint artifact；默认 retry 从全新工作目录开始，不悄悄续旧 work。

## 8. 空档优先时间线的精确定义

### 8.1 使用实际语音边界与音频时长

源语句 i 的语音结束为 E_i，下一保护语音开始为 S_(i+1)，中文PCM长度 C_i，前后无讲述间隔 p=q=1秒。此前定格累计为 D_i。

理想连续时间：

```text
G_i = S_(i+1) - E_i
H_i = max(0, p + C_i + q - G_i)
中文开始 = E_i + D_i + p
中文结束 = 中文开始 + C_i
下一原语音开始 = S_(i+1) + D_i + H_i
```

但实际插入发生在安全帧边界 K_i≤S_(i+1)，不是随意在音频sample处拆视频帧。因此真正实现使用：

```text
K_i = safe_cut_frame_i / fps
r_i = max(0, ChineseEnd_i + q - (K_i + D_i))
hold_frames_i = ceil(r_i * fps)
H_i = hold_frames_i / fps
D_(i+1) = D_i + H_i
```

要求 `E_i ≤ K_i ≤ S_(i+1)`，且 K_i 不切断任何原始保护语音。若不存在安全帧边界，先合并/重新划分语句，不能在连续讲话的一个音素中间冻结。实际选用 K_i 可能比语音起点略早，这比理论公式多出的不足一帧/安全余量必须可追踪。

原片间隔大于需求时 H=0，保持原片全部停顿；中文之后可能超过1秒。最后一句令下一边界为源视频末尾，但必须先确认最后实际语音确实落在视频范围内。

### 8.2 原片时钟与输出时钟

正常段：两种时钟同速前进。定格段：原片时钟暂停，输出时钟继续；正在播放的中文不暂停、不重启。定格结束，原音/原画面同时恢复。

用半开区间表示所有 source pieces：源帧0到N恰好覆盖一次，不重排、不漏片头/空白/片尾。额外 HOLD 引用切点前一帧。SOURCE包含原视频与其同步原音；HOLD只包含静帧、零原音和当前中文/可选背景声。多次插入的位移只累计整数帧与精确采样，不逐段累加float秒。

### 8.3 数值样例（本包实际媒体测试）

源12秒，25fps，共300帧；音频48kHz双声道PCM。

| 语句 | 源语音范围 | 下一边界 | 中文长度 | 原空档 | 补帧 |
|---|---|---|---|---|---|
| u1 | 0.5–2秒 | 下一句6秒 | 1秒 | 4秒 | 0 |
| u2 | 6–7秒 | 下一句9秒 | 3秒 | 2秒 | 75帧=3秒 |
| u3 | 9–10秒 | 片尾12秒 | 2秒 | 2秒 | 50帧=2秒 |

输出17秒、425帧、816000个48kHz采样帧。测试同时验证所有原帧按序保留、每个冻结引用正确原帧，以及完整PCM内容和插入位置。该样例使用不同频率提示音标识各语段，不是自然语音评测。

### 8.4 视频规范化与精度限制

生产工作域优先保持已知CFR，否则显式生成CFR版本并记录映射；原始文件永不改写。归一化音视频要使用共同时间原点，保留容器中的真实offset，不可独立 `PTS-STARTPTS` 使原本偏移的两个流错误对齐。

计划器已用 Fraction 支持有理数帧率，避免29.97当成30。但本包参考渲染器要求每帧对应整数PCM采样数，因此**不宣称已支持全部30000/1001素材的合成**；不满足时明确拒绝。生产渲染器应采用统一高精度时钟、按绝对时间舍入采样端点、分段误差扩散并记录有界舍入，不允许每段独立四舍五入累积漂移。

首版不暗中丢弃HDR、旋转、可变帧率、多个音轨或带偏移源。由normalizer策略显式处理或者输出能力不支持。参考合成器支持范围、测试环境和限制见README。

## 9. 字幕清理、字体、排版与音频策略

### 9.1 文本来源不等于视觉来源

YouTube旁挂字幕或容器字幕可作为文本候选；但它可能自动转写、版本不同，或者与硬字幕文本不一致。CaptionTrack保存来源，ASR只作对齐/核验，不静默用ASR替换画面文字。只要需要复原硬字幕样式，仍要在擦除前保留原图证据。

VSE可参考提取与去重流程，但需要移除交互和清理缓存行为；VideOCR有CLI入口；VSR可参考掩膜、连续区间和修复执行，不能继承“无区域就全屏处理”的政策。[R03][R04][R05][R06]

### 9.2 去字幕只修改被授权区域

掩膜生成单独节点，支持一条视频多个动态字幕带；保留逐帧mask或关键帧+插值策略。边界精化避免抽帧漏掉瞬时字幕。画面标题、路牌和幻灯片内容不能默认归入字幕区域。

清理输出保持canonical帧数、尺寸和顺序；最终原音始终来自源音轨，而不是VSR重新混入的音轨。修复并非真实背景的无损还原；被文字遮挡的信息只能推断，质量不确定时标记REVIEW。

### 9.3 字体恢复

有ASS样式/字体附件时先用元数据；只有像素时，字体识别模型只生成候选。YuzuMarker演示返回top-k候选，不能当作确定的原字体结论。[R08]

新开发：候选字体对多条原字幕重渲染，比较字形宽高/结构；拟合字号、颜色、描边、阴影；检查中文字符coverage。英文字体缺中文时，使用同家族CJK或风格近似字体，明确记录 `font_match=APPROXIMATE`。fontTools可查询Unicode映射，pysubs2/libass承担字幕数据和渲染。[R09][R10][R11]

字体文件只记录本地引用、名称、文件哈希和授权；本交付不分发字体。严格同字体策略缺字即REVIEW，不静默fallback却报告exact。

### 9.4 字幕显示政策

中文播放和其后1秒内保留当前语句的英文与中文；下一句不能提前显示。长段落按语义分页，显示内容与当前译音页关联。原片长空档时可在译音后1秒淡出，避免整段空镜头挂字。

原英文字幕若需上移，必须在清理画面上重新渲染，不搬运带背景的字截图。ASS布局包括边距、换行、对齐、字号上限、两行/多行最大区域、描边厚度和避免遮挡策略。实际渲染后测量边界，不只相信字体宽度估算。

### 9.5 原音和中文混合

默认SOURCE段保留原混音；中文覆盖原无讲话空档时可按显式 `background_gain` 降低原音。HOLD段原音不前进，默认静音底，中文继续；生产可新增“无人声roomtone/背景音乐延续”策略，但不得循环带英文的原片音频。

语音活动不是静音阈值。FFmpeg silencedetect适合低音量检测，不代替VAD。新的音频混音策略要验证峰值、响度、左右声道、采样数以及所有原始讲话保护区。[R12]

中文模型输出如果包含首尾静音，先由独立节点定义处理方式并记录剪掉的样本范围；时间线使用这个被选中的DubClip实际播放长度。原始模型音频仍保存，不能以“去静音”为由裁掉尾音。中文发声距英文结束约1秒的感知验收，应比较实际语音起点，而不只比较WAV容器起点。

### 9.6 多语言

默认每种目标语言形成独立branch/release，例如 en+zh-CN、en+ja-JP，不把所有语言自动塞进同一音轨。模型插件可同时生成多语言，单个DubClip仍按 `(utterance_set,utterance_id,speaker,language)`管理。

若选择一条视频内英文→中文→日文，则语言顺序成为时间线参数；需求时长使用所有译音与相邻间隔之和，字幕分页同步。该扩展不改变资产和血缘模型，但本包参考时间线只实现每语句一段译音。

## 10. 日志、可观测性与质量门禁

### 10.1 主日志事件

统一JSONL每行包含：seq、event_id、UTC发生时间、asset、run、execution、node、scope、strategy、version、event、payload。payload记录开始时的输入引用/哈希、实际参数、git/代码树/模型声明，完成时的输出列表/哈希、状态、耗时和错误类型。骨架某些字段位于payload中的执行request/manifest，不保证每行重复全部字段，但可由execution_id完整关联。

事件类型：source.ingested、acquire.completed、run.started、execution.started、command.started/finished/interrupted、模型调用及响应（待具体worker）、artifact.validate、execution.finished、artifact.selected、run.finished、recovery。

使用monotonic测耗时，UTC用于跨节点审计；不通过系统时钟相减测耗时。每个文件产生的时点、实际参数变更、裁剪/兜底行为应在模型worker中发出事件或写结构化raw回执。raw输出可能包含敏感URL，生产日志采集还应执行脱敏/加密与文件权限控制。

### 10.2 质量状态与执行状态

执行状态：RUNNING/SUCCEEDED/FAILED/ABANDONED（生产增加CANCELLED）。质量状态：PASS/REVIEW/FAIL/SKIPPED。QA节点成功生成报告，其执行可以SUCCEEDED，报告仍为REVIEW或FAIL。发布节点必须读报告内容，不能只看进程0退出。

本包 demo 的最终质量状态为REVIEW，因为OCR残留、字体布局、翻译语义、音色和实际语音重叠检查尚未实现。结构检查通过不升级为全链路通过。

### 10.3 自动质检责任

| 层 | 输入证据 | 判定政策 |
|---|---|---|
| 数据与血缘 | manifest、hash、固定bindings | 所有引用存在且哈希一致，否则FAIL |
| 时间线 | source/dub events | 原内容覆盖一次；英文/译音不重叠；前后停顿；尾部完整 |
| 媒体结构 | 完整解码、frame/sample counts | 无解码错误；总长度和计划一致；禁用-shortest掩盖错误 |
| 画面冻结 | 源/输出帧与计划HOLD | 计划内冻结合法；原片本来静止也不误报 |
| 字幕清理 | clean video + 原ROI/mask | 重加字前OCR残字；掩膜外误修改；时间闪烁 |
| 字幕排版 | ASS + 渲染图 + fontlist | 缺字、重叠、越界、提前显示下一语句 |
| 译音内容 | 独立ASR + spoken_text | 漏读/重复/错语言；数字/单位/实体规则 |
| 音色 | 参考音频 + 独立说话者特征 | 可疑换人进入REVIEW；分数阈值按样本校准 |
| 语义 | 源/译文/术语/上下文 | 否定、数量、专名、重大漏译；模型结果也是概率证据 |

QCTools/qcli和FFmpeg可复用基础分析，但对“有意插入定格”“有意1秒无讲述”的业务解释需要本项目判定器。[R12][R13] 质量阈值必须用实际素材校准，不在没有实验时承诺固定模型相似度代表同一音色。

自动修复遵循有限策略：单节点最多配置次数；每次保存版本和错误证据；失败后REVIEW而非无限循环。任何更换模型/策略/参数都是新执行，有新的lineage。

## 11. 上游参考与新增开发边界

| 功能 | 优先复用/参考 | 新开发 |
|---|---|---|
| 下载 | yt-dlp CLI和最终文件定位 | 获取版本、哈希归档、无缓存重试、记录和安全控制 |
| 识别字幕 | VSE/VideOCR的OCR与去重/CLI | 目标ROI、统一CaptionTrack、时间边界精化、AB实验 |
| 语音边界 | WhisperX对齐/说话者接口 | 所有原讲话保护、安全帧切点、重叠归组 |
| 去字幕 | VSR检测/掩膜/连续区间/修复 | 固定MaskTrack输入、禁全屏误擦、帧与原音校验 |
| 字体候选 | YuzuMarker.FontDetection | 候选重渲染验证、原视觉样式拟合、中文映射 |
| 字幕格式渲染 | pysubs2/libass/fontTools | 双语自适应排版、实际边界检查、字体审计 |
| 翻译/声音 | 用户选定LLM/语音模型接口 | 结构化适配、回执、标准结果和QA；不重造模型 |
| 媒体执行 | FFmpeg | gap-first纯计划、原音暂停/恢复、流式执行与校验 |
| 基础质量分析 | FFmpeg/QCTools | 项目规则、证据归并、有限重试和发布门禁 |
| 执行基础设施 | SQLite、Python插件机制 | SHA资产、逐次版本/血缘、强制执行、统一日志、DAG |

具体每个仓库的文件、函数、极短源代码摘录、应该参考和不应搬入的逻辑，全部在 `docs/UPSTREAM_REFERENCES_ZH.md`。源码定位优先固定commit；只有main/master阅读证据的条目明确标为待部署锁定，不把移动分支当作可重现版本。

许可证按具体组件和模型权重检查，进程隔离不构成许可证豁免。尤其ProPainter的许可有非商业限制，不能因为VSR外层可开源使用就推导所有模型可商用。[R16] 本包未复制/打包这些上游实现或模型权重。

## 12. 开发与验收顺序

| 里程碑 | 开发交付 | 完成判定 |
|---|---|---|
| M0 执行基础 | 当前骨架 + 补齐生产端口/模型回执/目录权限 | 相同输入反复实际调用；血缘/版本不串；失败不覆盖 |
| M1 获取与规范化 | yt-dlp真实环境冒烟、live/大小限制、normalize/PTS映射 | 授权URL和本地文件均归档；VFR/偏移不暗错 |
| M2 字幕与语音事实层 | OCR两插件、ROI、WhisperX/VAD、UtteranceSet | 同素材AB可比较，下游同契约，安全边界可验证 |
| M3 模型适配 | 翻译与音色克隆服务、RawDub/DubClip、回执及clipQA | 数字/短词/多人引用正确，重试确实重新调用 |
| M4 图像与排版 | Mask/VSR、Style、ASS、清理和字体QA | 不误擦标题、不双影、不缺字、不提前切字幕 |
| M5 生产合成 | 音频混合、分块渲染、精确时基、长视频资源策略 | gap-first全边界用例通过，小时级样例无累计漂移 |
| M6 发布与恢复 | 完整QA/发布节点、kill -9矩阵、备份恢复 | 结果可回溯且未检查项不默认为通过 |

先完成稳定数据内核和时间线，再接模型，是为了让每一个不确定模型输出都能被追溯、换策略、重试和独立验证。模型选择与翻译提示词无需反复改动持久化或媒体时间线。

长视频实现禁止把所有帧/全音频读入RAM。按场景或固定块顺序解码，掩膜修复块留上下文halo，跨块只发布正确归属的帧；PCM流式处理；实际时长以全局采样计数验证。块产物仍是节点版本子产物。磁盘配额不足失败，不自动删除旧版本；清理需单独保留策略、引用可达性分析及操作日志。

## 13. 验证边界与交付使用

运行方式在README。测试分三层：纯逻辑/契约、实际FFmpeg媒体、真实联网/真实模型。前两层本次已执行；后者仅提供可运行入口和详细用例，不以mock冒充真实环境。

真实模型测试启用后缺环境、缺模型或缺授权配置会FAIL，不会自动SKIP成“成功”。离线默认跳过的外部测试在汇总中明确列出。全链路实际成片还需真实OCR、清理、翻译、克隆、字体、QA适配完成；本交付没有声称这条链已经跑通。

## 参考来源

完整出处和源码位置见 `docs/UPSTREAM_REFERENCES_ZH.md`；以下编号贯穿本文。

[R01] yt-dlp，官方README及YoutubeDL.py，https://github.com/yt-dlp/yt-dlp 。
[R02] yt-dlp，EJS官方文档，https://github.com/yt-dlp/yt-dlp/wiki/EJS 。
[R03] YaoFANGUK，video-subtitle-extractor/backend/main.py，固定commit见来源表。
[R04] timminator，VideOCR/CLI/videocr_cli.py，https://github.com/timminator/VideOCR 。
[R05] YaoFANGUK，video-subtitle-remover/backend/main.py，固定commit见来源表。
[R06] YaoFANGUK，video-subtitle-remover/backend/tools/subtitle_detect.py，固定commit见来源表。
[R07] m-bain，WhisperX/whisperx/alignment.py与diarize.py，https://github.com/m-bain/whisperX 。
[R08] JeffersonQin，YuzuMarker.FontDetection/demo.py，https://github.com/JeffersonQin/YuzuMarker.FontDetection 。
[R09] tkarabela，pysubs2，https://github.com/tkarabela/pysubs2 。
[R10] libass，https://github.com/libass/libass 。
[R11] fontTools，TTFont文档，https://fonttools.readthedocs.io/en/latest/ttLib/ttFont.html 。
[R12] FFmpeg，Filters Documentation，https://ffmpeg.org/ffmpeg-filters.html 。
[R13] BAVC，QCTools，https://github.com/bavc/qctools 。
[R14] SQLite，Write-Ahead Logging，https://www.sqlite.org/wal.html 。
[R15] Python Packaging，Entry points specification，https://packaging.python.org/en/latest/specifications/entry-points/ 。
[R16] sczhou，ProPainter LICENSE，https://github.com/sczhou/ProPainter/blob/main/LICENSE 。
