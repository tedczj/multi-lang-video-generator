#!/usr/bin/env python3
"""Resolve candidate branches to real Git commit IDs in a networked environment.
Does not claim that the resolved revision was the one previously inspected.
No lock is emitted unless every entry resolves and (by default) its object verifies.
"""
import argparse,datetime,json,re,subprocess,tempfile
from pathlib import Path


def run(argv):
    return subprocess.check_output(argv,text=True,stderr=subprocess.PIPE,timeout=180).strip()


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--catalog',default='references.catalog.json')
    p.add_argument('--out',default='upstreams.lock.json')
    p.add_argument('--resolve-only',action='store_true',help='No object fetch; marks verified=false')
    args=p.parse_args();output=Path(args.out)
    if output.exists():raise SystemExit('Refusing to overwrite an existing lock; choose a new path')
    catalog=json.loads(Path(args.catalog).read_text());locked=[]
    for entry in catalog['repositories']:
        url=entry['url'];branch=entry['branch']
        raw=run(['git','ls-remote',url,'refs/heads/'+branch]);lines=raw.splitlines()
        if len(lines)!=1:raise RuntimeError(f'Cannot uniquely resolve {url} {branch}')
        commit=lines[0].split()[0]
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',commit):raise RuntimeError('Invalid Git object id')
        verified=False
        if not args.resolve_only:
            with tempfile.TemporaryDirectory() as tmp:
                run(['git','init','--bare',tmp])
                run(['git','-C',tmp,'fetch','--depth=1','--filter=blob:none',url,commit])
                if run(['git','-C',tmp,'rev-parse','FETCH_HEAD'])!=commit:raise RuntimeError('Fetched wrong object')
                if run(['git','-C',tmp,'cat-file','-t',commit])!='commit':raise RuntimeError('Not a commit object')
                # Verify each requested path exists at this fixed revision.
                for path in entry['paths']:
                    if not run(['git','-C',tmp,'ls-tree',commit,'--',path]):raise RuntimeError(f'Missing path: {url} {path}')
                verified=True
        locked.append({**entry,'resolved_commit':commit,'object_and_paths_verified':verified})
    result={'schema':'upstreams_lock.v1','resolved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'note':'Resolved now, not claimed to equal a previously inspected moving branch; review before release.',
            'repositories':locked}
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(output)

if __name__=='__main__':main()
