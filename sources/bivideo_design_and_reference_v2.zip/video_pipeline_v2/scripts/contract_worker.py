"""TEST FIXTURE ONLY. Demonstrates the worker wire protocol, not OCR."""
import argparse,json,time,uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--request',required=True);args=p.parse_args()
r=json.loads(Path(args.request).read_text());out=Path(r['output_dir'])
if r['params'].get('sleep_s'):time.sleep(r['params']['sleep_s'])
caption={'schema':'captions.v1','canvas':{'width':100,'height':100},'cues':[{'id':'test-c1','text':'Fixture only','start_us':0,'end_us':1000000,'confidence':1.0,'bbox_xyxy':[1,80,99,99]}],'fixture_only':True}
(out/'captions.json').write_text(json.dumps(caption))
Path(r['response_path']).write_text(json.dumps({'attempt_id':r['attempt_id'],'status':'SUCCEEDED','execution':'EXECUTED',
    'provenance':{'fixture_only':True,'invocation_nonce':uuid.uuid4().hex},
    'outputs':[{'name':'captions','path':'captions.json','schema':'captions.v1'}]}))
