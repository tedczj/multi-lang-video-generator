from __future__ import annotations
import hashlib, json, os, shutil, sqlite3, time, uuid
from pathlib import Path
from .contracts import ArtifactRef
from .util import atomic_json, canonical, file_lock, fsync_dir, inside, sha512_file, token, code_provenance

DDL = """
CREATE TABLE IF NOT EXISTS attempts (
 id TEXT PRIMARY KEY, node TEXT NOT NULL, item TEXT NOT NULL, version INTEGER NOT NULL,
 relpath TEXT NOT NULL UNIQUE, status TEXT NOT NULL, retry_of TEXT,
 created_ns INTEGER NOT NULL, UNIQUE(node,item,version));
CREATE TABLE IF NOT EXISTS artifacts (
 attempt_id TEXT NOT NULL, name TEXT NOT NULL, ref_json TEXT NOT NULL,
 PRIMARY KEY(attempt_id,name));
CREATE TABLE IF NOT EXISTS edges (
 child_attempt TEXT NOT NULL, input_name TEXT NOT NULL, parent_attempt TEXT NOT NULL,
 artifact_name TEXT NOT NULL, artifact_sha512 TEXT NOT NULL,
 PRIMARY KEY(child_attempt,input_name));
CREATE TABLE IF NOT EXISTS events (
 seq INTEGER PRIMARY KEY AUTOINCREMENT, event_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS selections (
 id TEXT PRIMARY KEY, branch TEXT NOT NULL, mapping_json TEXT NOT NULL, created_ns INTEGER NOT NULL);
"""

class AssetStore:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def asset_path(self, digest: str) -> Path:
        if len(digest) != 128 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("Expected lowercase SHA-512 hex")
        return self.root / "videos" / digest

    def connect(self, asset: Path):
        conn = sqlite3.connect(asset / "index.sqlite", timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(DDL)
        return conn

    def ingest(self, source: Path, origin: dict | None = None) -> str:
        """Hash the copied bytes, not a path or URL. Original bytes never change."""
        source = Path(source).resolve()
        staging = self.root / "acquisitions" / uuid.uuid4().hex
        staging.mkdir(parents=True)
        temp = staging / "source.bin"
        ingest_started=time.perf_counter_ns()
        atomic_json(staging/"request.json", {"schema":"ingest_request.v1","execution_id":staging.name,"source_path":str(source),"origin":origin or {"type":"local"},"strategy_id":"sha512_copy","code":code_provenance(Path(__file__).resolve().parents[2])})
        h = hashlib.sha512()
        try:
            with source.open("rb") as inp, temp.open("xb") as out:
                before = os.fstat(inp.fileno())
                for chunk in iter(lambda: inp.read(1024*1024), b""):
                    h.update(chunk); out.write(chunk)
                out.flush(); os.fsync(out.fileno())
                after = os.fstat(inp.fileno())
            if (before.st_size,before.st_mtime_ns) != (after.st_size,after.st_mtime_ns):
                raise RuntimeError("Input changed during ingest")
            digest = h.hexdigest(); asset = self.asset_path(digest)
            asset.mkdir(parents=True, exist_ok=True)
            with file_lock(asset / ".asset.lock"):
                (asset / "source").mkdir(exist_ok=True)
                target = asset / "source" / "original.bin"
                if not target.exists():
                    os.replace(temp, target); fsync_dir(target.parent)
                    atomic_json(asset/"asset.json", {"schema":"asset.v1", "sha512":digest, "bytes":target.stat().st_size})
                elif sha512_file(target) != digest:
                    raise RuntimeError("Existing source corrupt; refuse overwrite")
                with self.connect(asset): pass
            # A repeated ingest hashes and copies again; byte identity alone only
            # deduplicates the immutable ORIGINAL, never a node execution.
            if temp.exists(): temp.unlink()
            elapsed=(time.perf_counter_ns()-ingest_started)/1e9
            atomic_json(staging/"result.json", {"schema":"ingest_result.v1","status":"SUCCEEDED","asset_sha512":digest,"elapsed_s":elapsed,"output_path":"source/original.bin"})
            adopted=asset/"acquisitions"/staging.name;adopted.parent.mkdir(exist_ok=True);os.replace(staging,adopted)
            self.event(digest, {"event":"SOURCE_INGESTED", "source_name":source.name,
                                "origin":origin or {"type":"local"}, "sha512":digest,"elapsed_s":elapsed,"execution_dir":str(adopted.relative_to(asset))})
            return digest
        except BaseException:
            if staging.exists(): atomic_json(staging/"failed.json", {"status":"FAILED", "source_name":source.name})
            raise

    def event(self, digest: str, payload: dict) -> None:
        asset = self.asset_path(digest)
        value = {"utc_ns":time.time_ns(), "asset_sha512":digest, **payload}
        # Single-host lock serializes the SQLite event and JSONL projection.
        # A crash between them is repaired by rebuild_log(), not hidden.
        with file_lock(asset / ".log.lock"):
            with self.connect(asset) as db:
                cur = db.execute("INSERT INTO events(event_json) VALUES(?)", (canonical(value).decode(),))
                seq = cur.lastrowid
            with (asset/"pipeline.jsonl").open("ab") as f:
                f.write(canonical({"seq":seq, **value})+b"\n"); f.flush(); os.fsync(f.fileno())

    def rebuild_log(self, digest: str) -> None:
        asset = self.asset_path(digest)
        with file_lock(asset/".log.lock"):
            with self.connect(asset) as db: rows = db.execute("SELECT * FROM events ORDER BY seq").fetchall()
            tmp=asset/".pipeline.jsonl.tmp"
            with tmp.open("wb") as f:
                for r in rows: f.write(canonical({"seq":r["seq"], **json.loads(r["event_json"])})+b"\n")
                f.flush();os.fsync(f.fileno())
            os.replace(tmp,asset/"pipeline.jsonl");fsync_dir(asset)

    def allocate(self, digest: str, node: str, item: str, retry_of: str | None = None):
        node,item=token(node),token(item);asset=self.asset_path(digest)
        attempt=uuid.uuid4().hex
        with self.connect(asset) as db:
            db.execute("BEGIN IMMEDIATE")
            version=db.execute("SELECT COALESCE(MAX(version),0)+1 FROM attempts WHERE node=? AND item=?",(node,item)).fetchone()[0]
            rel=f"nodes/{node}/{item}/v{version:06d}_{attempt}"
            db.execute("INSERT INTO attempts VALUES(?,?,?,?,?,?,?,?)", (attempt,node,item,version,rel,"RUNNING",retry_of,time.time_ns()))
        # Note: SQL placeholders are verified by tests; directory allocation is unique.
        path=asset/rel; (path/"work").mkdir(parents=True)
        return attempt,version,path

    def attempt(self, digest: str, attempt: str) -> dict:
        with self.connect(self.asset_path(digest)) as db:
            row=db.execute("SELECT * FROM attempts WHERE id=?",(attempt,)).fetchone()
        if row is None: raise KeyError(attempt)
        return dict(row)

    def resolve(self, ref: ArtifactRef) -> Path:
        asset=self.asset_path(ref.asset_sha512)
        if ref.producer_attempt_id == "source":
            if ref.name!="original" or ref.path!="source/original.bin" or ref.sha512!=ref.asset_sha512:
                raise ValueError("Invalid source reference")
        else:
            with self.connect(asset) as db:
                row=db.execute("SELECT a.ref_json,r.status FROM artifacts a JOIN attempts r ON r.id=a.attempt_id WHERE a.attempt_id=? AND a.name=?",(ref.producer_attempt_id,ref.name)).fetchone()
            if row is None or row["status"]!="SUCCEEDED" or json.loads(row["ref_json"])!=ref.as_dict():
                raise ValueError("Unpublished or forged artifact reference")
        path=inside(asset,ref.path)
        if not path.is_file() or path.stat().st_size!=ref.bytes or sha512_file(path)!=ref.sha512:
            raise ValueError("Artifact missing or checksum mismatch")
        return path

    def source_ref(self,digest:str)->ArtifactRef:
        path=self.asset_path(digest)/"source/original.bin"
        return ArtifactRef(digest,"source","original","source.bytes.v1","source/original.bin",digest,path.stat().st_size)

    def ref(self,digest:str,attempt:str,name:str)->ArtifactRef:
        with self.connect(self.asset_path(digest)) as db:
            row=db.execute("SELECT ref_json FROM artifacts WHERE attempt_id=? AND name=?",(attempt,name)).fetchone()
        if row is None: raise KeyError((attempt,name))
        return ArtifactRef(**json.loads(row["ref_json"]))

    def select(self,digest:str,branch:str,mapping:dict[str,ArtifactRef])->str:
        token(branch)
        for r in mapping.values():
            if r.asset_sha512 != digest: raise ValueError("Cross-asset selection")
            self.resolve(r)
        sid=uuid.uuid4().hex;data={k:v.as_dict() for k,v in mapping.items()}
        asset=self.asset_path(digest)
        atomic_json(asset/f"selections/{branch}/{sid}.json",{"selection_id":sid,"branch":branch,"mapping":data})
        with self.connect(asset) as db:
            db.execute("INSERT INTO selections VALUES(?,?,?,?)",(sid,branch,canonical(data).decode(),time.time_ns()))
        self.event(digest,{"event":"SELECTION_CREATED","selection_id":sid,"branch":branch,"mapping":data})
        return sid
