from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from .store import AssetStore
from .engine import Engine
from .plugins import defaults
from .demo import DemoClips,DemoRender,run_demo
from .contracts import ArtifactRef
from .acquire import acquire_youtube


def main():
    p=argparse.ArgumentParser();p.add_argument('--data',default='run-data');p.add_argument('--strict-git',action='store_true');p.add_argument('--plugin',action='append',default=[])
    sub=p.add_subparsers(dest='command',required=True)
    local=sub.add_parser('ingest');local.add_argument('--local',required=True)
    dl=sub.add_parser('download');dl.add_argument('--url',required=True);dl.add_argument('--format',default='bv*+ba/b');dl.add_argument('--retry-of')
    run=sub.add_parser('node-run');run.add_argument('--asset',required=True);run.add_argument('--strategy',required=True);run.add_argument('--inputs');run.add_argument('--params');run.add_argument('--item',default='all')
    retry=sub.add_parser('retry');retry.add_argument('--asset',required=True);retry.add_argument('--attempt',required=True);retry.add_argument('--strategy');retry.add_argument('--params')
    history=sub.add_parser('history');history.add_argument('--asset',required=True)
    log=sub.add_parser('rebuild-log');log.add_argument('--asset',required=True)
    demo=sub.add_parser('demo');demo.add_argument('--out',required=True);demo.add_argument('--long-gap',action='store_true')
    args=p.parse_args();root=Path(__file__).resolve().parents[2];store=AssetStore(Path(args.data))
    if args.command=='demo':result=run_demo(Path(args.out),root,args.long_gap)
    elif args.command=='ingest':
        digest=store.ingest(Path(args.local));result={'asset_sha512':digest,'source_ref':store.source_ref(digest).as_dict()}
    elif args.command=='download':result=acquire_youtube(store,args.url,root,format_selector=args.format,retry_of=args.retry_of)
    elif args.command=='history':
        with store.connect(store.asset_path(args.asset)) as db:result=[dict(x) for x in db.execute('SELECT * FROM attempts ORDER BY created_ns')]
    elif args.command=='rebuild-log':store.rebuild_log(args.asset);result={'status':'rebuilt'}
    else:
        e=Engine(store,root,strict_git=args.strict_git)
        for plugin in defaults()+[DemoClips(),DemoRender()]:e.register(plugin)
        e.load_installed_plugins(args.plugin)
        params=json.loads(Path(args.params).read_text()) if args.params else None
        if args.command=='retry':attempt,outputs=e.retry(args.asset,args.attempt,strategy_id=args.strategy,params=params)
        else:
            inputs={k:ArtifactRef(**v) for k,v in json.loads(Path(args.inputs).read_text()).items()} if args.inputs else {'source':store.source_ref(args.asset)}
            attempt,outputs=e.run(args.asset,e.plugins[args.strategy].spec.node,args.strategy,inputs,params,item=args.item)
        result={'attempt_id':attempt,'outputs':{k:v.as_dict() for k,v in outputs.items()}}
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
