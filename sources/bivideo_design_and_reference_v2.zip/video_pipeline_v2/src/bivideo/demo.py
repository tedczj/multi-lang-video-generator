from __future__ import annotations
import json,math,os,uuid
from pathlib import Path
from .contracts import PluginSpec,ProducedFile
from .media import make_fixture,render_reference,write_wav
from .store import AssetStore
from .engine import Engine
from .plugins import defaults
from .util import atomic_json

class DemoClips:
    spec=PluginSpec('fixture_prepare','fixture_tones','1',{'source':'source.bytes.v1'},'timeline_request.v1')
    def execute(self,ctx,inputs,params):
        rate=48000
        for name,seconds,hz in [('zh-a',4,880),('zh-b',1,990)]:
            write_wav(ctx.work/(name+'.wav'),rate,(int(2500*math.sin(2*math.pi*hz*n/rate)) for n in range(seconds*rate)))
        ctx.write_json('timeline_request.json',params['document'])
        return [ProducedFile('request','timeline_request.json','timeline_request.v1'),ProducedFile('clip_a','zh-a.wav','audio.wav.v1'),ProducedFile('clip_b','zh-b.wav','audio.wav.v1')]

class DemoRender:
    spec=PluginSpec('render','reference_ffmpeg','1',{'source':'source.bytes.v1','timeline':'timeline.v1','clip_a':'audio.wav.v1','clip_b':'audio.wav.v1'},'qa.v1')
    def execute(self,ctx,inputs,params):
        plan=json.loads(inputs['timeline'].read_text())
        render_reference(inputs['source'],plan,{'zh-a':inputs['clip_a'],'zh-b':inputs['clip_b']},ctx.work)
        ctx.event('RENDER_COMPLETED',command_log='work/commands.log')
        return [ProducedFile('video','result.mp4','video.mp4.v1'),ProducedFile('master','master.mkv','video.mkv.v1'),ProducedFile('master_audio','master.wav','audio.wav.v1'),ProducedFile('qa','qa.json','qa.v1')]


def run_demo(destination:Path,project_root:Path,long_gap=False):
    destination=destination.resolve()
    if destination.exists() and any(destination.iterdir()):raise FileExistsError('Choose a new empty demo directory')
    store=AssetStore(destination);provisional=destination/'acquisitions'/('fixture-'+uuid.uuid4().hex)
    source,_,request=make_fixture(provisional,long_gap)
    digest=store.ingest(source,{'type':'synthetic_fixture','contains_real_speech':False})
    saved=store.asset_path(digest)/'acquisitions'/provisional.name;saved.parent.mkdir(exist_ok=True);os.replace(provisional,saved)
    engine=Engine(store,project_root)
    for p in defaults()+[DemoClips(),DemoRender()]:engine.register(p)
    _,_=engine.run(digest,'probe','ffprobe',{'source':store.source_ref(digest)})
    prep,prepared=engine.run(digest,'fixture_prepare','fixture_tones',{'source':store.source_ref(digest)},{'document':request})
    timeline,planned=engine.run(digest,'timeline','gap_first',{'request':prepared['request']})
    render,rendered=engine.run(digest,'render','reference_ffmpeg',{'source':store.source_ref(digest),'timeline':planned['timeline'],'clip_a':prepared['clip_a'],'clip_b':prepared['clip_b']})
    selection=store.select(digest,'demo',{'timeline':planned['timeline'],**rendered})
    summary={'asset_sha512':digest,'asset_dir':str(store.asset_path(digest)),'prepare_attempt':prep,'timeline_attempt':timeline,'render_attempt':render,'selection_id':selection,
             'video':str(store.resolve(rendered['video'])),'qa':str(store.resolve(rendered['qa'])),'synthetic_tones_not_real_speech':True}
    atomic_json(destination/'demo_summary.json',summary)
    return summary
