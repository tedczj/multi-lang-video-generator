from __future__ import annotations
from fractions import Fraction
import math


def nearest(value: Fraction) -> int:
    # Nonnegative, exact half-up rounding. Avoid floating point drift.
    return (2*value.numerator+value.denominator)//(2*value.denominator)


def build_timeline(request: dict) -> dict:
    if request.get("schema")!="timeline_request.v1": raise ValueError("Wrong timeline input")
    fps=Fraction(request["fps_num"],request["fps_den"])
    rate=request["sample_rate"];frames=request["source_frames"];source_samples=request["source_samples"]
    if fps<=0 or rate<=0 or frames<=0 or source_samples<=0: raise ValueError("Invalid media clock")
    if abs(source_samples-nearest(Fraction(frames,1)/fps*rate))>1: raise ValueError("Source audio/video duration mismatch")
    units=request["utterances"]
    pre=request.get("pre_samples",rate);post=request.get("post_samples",rate);between=request.get("between_samples",rate)
    if min(pre,post,between)<0: raise ValueError("Negative pause")
    ids=set();previous_end=0
    for u in units:
        if u["id"] in ids: raise ValueError("Duplicate utterance id")
        ids.add(u["id"])
        if not (previous_end<=u["start_sample"]<u["end_sample"]<=source_samples):
            raise ValueError("Overlapping, unsorted, or out-of-range speech; regroup before planning")
        previous_end=u["end_sample"]
        if not u["dubs"]: raise ValueError("No translated clip")
        langs=[]
        for clip in u["dubs"]:
            if clip["sample_rate"]!=rate or clip["samples"]<=0: raise ValueError("Normalize and measure dubs first")
            langs.append(clip["language"])
        if len(langs)!=len(set(langs)): raise ValueError("Duplicate language")
    holds=[];dubs=[];speech=[];cumulative_frames=0
    for i,u in enumerate(units):
        offset_samples=nearest(Fraction(cumulative_frames,1)/fps*rate)
        pause=units[i+1]["start_sample"] if i+1<len(units) else source_samples
        gap=pause-u["end_sample"]
        need=pre+sum(c["samples"] for c in u["dubs"])+between*(len(u["dubs"])-1)+post
        missing=max(0,need-gap)
        extra=math.ceil(Fraction(missing,rate)*fps)
        speech.append({"utterance_id":u["id"],"start_sample":u["start_sample"]+offset_samples,"end_sample":u["end_sample"]+offset_samples})
        pos=u["end_sample"]+offset_samples+pre
        for clip in u["dubs"]:
            dubs.append({"utterance_id":u["id"],"language":clip["language"],"clip_id":clip["clip_id"],
                         "start_sample":pos,"end_sample":pos+clip["samples"]})
            pos+=clip["samples"]+between
        if extra:
            new_offset=nearest(Fraction(cumulative_frames+extra,1)/fps*rate)
            # Keep the frame actually displayed immediately BEFORE the next
            # speech start. For a sub-frame audio cut, clone after that frame;
            # no source video frame is lost, and the original audio cut is exact.
            boundary=min(frames,math.ceil(Fraction(pause,rate)*fps))
            if boundary<=0: raise ValueError("No previous frame exists")
            holds.append({"after_utterance":u["id"],"source_pause_sample":pause,
                          "video_insert_before_frame":boundary,"freeze_source_frame":boundary-1,
                          "hold_frames":extra,"hold_samples":new_offset-offset_samples,
                          "output_audio_start_sample":pause+offset_samples,
                          "output_video_start_frame":boundary+cumulative_frames,
                          "natural_gap_samples":gap,"required_samples":need})
            cumulative_frames+=extra
        # The sum-of-rounded-offsets method keeps audio error bounded even at
        # 30000/1001 FPS; independently rounding each hold would accumulate drift.
        next_start=pause+nearest(Fraction(cumulative_frames,1)/fps*rate)
        if next_start < dubs[-1]["end_sample"]+post: raise AssertionError("Insufficient post pause")
    plan={"schema":"timeline.v1","fps_num":fps.numerator,"fps_den":fps.denominator,"sample_rate":rate,
          "source_frames":frames,"source_samples":source_samples,"output_frames":frames+cumulative_frames,
          "output_samples":source_samples+nearest(Fraction(cumulative_frames,1)/fps*rate),
          "pre_samples":pre,"post_samples":post,"holds":holds,"dubs":dubs,"original_speech":speech}
    validate_plan(plan)
    return plan


def validate_plan(plan:dict)->None:
    if plan["output_frames"]!=plan["source_frames"]+sum(h["hold_frames"] for h in plan["holds"]):
        raise ValueError("Frame count does not conserve source plus holds")
    if plan["output_samples"]!=plan["source_samples"]+sum(h["hold_samples"] for h in plan["holds"]):
        raise ValueError("Sample count does not conserve source plus holds")
    previous_end=0
    for d in plan["dubs"]:
        if not (previous_end<=d["start_sample"]<d["end_sample"]<=plan["output_samples"]): raise ValueError("Dub collision")
        previous_end=d["end_sample"]
        for en in plan["original_speech"]:
            if max(d["start_sample"],en["start_sample"])<min(d["end_sample"],en["end_sample"]):
                raise ValueError("Dub overlaps original speech")
