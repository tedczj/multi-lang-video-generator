"""Executable reference, not a completed AI translation/inpainting product."""
__version__ = "0.2.0"
