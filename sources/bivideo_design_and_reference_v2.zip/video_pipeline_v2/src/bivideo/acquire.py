from __future__ import annotations
import json, os, shutil, subprocess, sys, time, uuid
from pathlib import Path
from urllib.parse import parse_qs,urlparse
from .store import AssetStore
from .util import atomic_json,canonical,code_provenance,inside,sha512_file


def canonical_youtube_url(url:str)->str:
    parsed=urlparse(url)
    if parsed.scheme!='https' or parsed.username or parsed.password or parsed.port not in (None,443):
        raise ValueError('Only HTTPS YouTube page URLs are supported')
    host=(parsed.hostname or '').lower()
    if host in {'youtube.com','www.youtube.com','m.youtube.com'}:
        parts=parsed.path.strip('/').split('/')
        if parsed.path=='/watch':video_id=parse_qs(parsed.query).get('v',[''])[0]
        elif len(parts)==2 and parts[0] in {'shorts','embed','live'}:video_id=parts[1]
        else:raise ValueError('Not a single YouTube video page')
    elif host=='youtu.be':video_id=parsed.path.strip('/')
    else:raise ValueError('Host is not YouTube')
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]{11}',video_id):raise ValueError('Invalid YouTube video ID')
    return 'https://www.youtube.com/watch?v='+video_id


def command(url: str, attempt_dir: Path, format_selector: str)->list[str]:
    return [sys.executable,'-m','yt_dlp','--ignore-config','--no-plugin-dirs','--no-playlist',
            '--no-download-archive','--no-cache-dir','--no-continue','--force-overwrites',
            '--abort-on-error','--abort-on-unavailable-fragments','--no-simulate','--no-mtime',
            '--socket-timeout','30','--retries','0','--fragment-retries','0',
            '--write-info-json','--write-subs','--write-auto-subs','--sub-langs','en.*,zh.*','--sub-format','vtt/best',
            '--merge-output-format','mkv','-f',format_selector,
            '-o',str(attempt_dir/'source.%(ext)s'),
            '--print-to-file','after_move:%(filepath)j',str(attempt_dir/'final_paths.jsonl'),'--',url]


def sanitize_info(value):
    # Preserve descriptive metadata, not expiring signed media URLs or HTTP headers.
    drop={'url','http_headers','cookies','cookie','fragments','fragment_base_url','manifest_url'}
    if isinstance(value,dict):return {k:sanitize_info(v) for k,v in value.items() if k not in drop}
    if isinstance(value,list):return [sanitize_info(v) for v in value]
    return value


def acquire_youtube(store:AssetStore,url:str,project_root:Path,*,format_selector='bv*+ba/b',timeout_s=1800,retry_of=None)->dict:
    canonical_url=canonical_youtube_url(url)
    aid=uuid.uuid4().hex;directory=store.root/'acquisitions'/aid;directory.mkdir(parents=True)
    argv=command(canonical_url,directory,format_selector)
    req={'schema':'acquisition_request.v1','acquisition_id':aid,'retry_of':retry_of,'url':canonical_url,
         'original_url':canonical_url,'whole_video':True,'strategy_id':'yt_dlp','strategy_version':'1',
         'code':code_provenance(project_root),'params':{'format':format_selector,'timeout_s':timeout_s},'argv':argv}
    atomic_json(directory/'request.json',req);started=time.perf_counter_ns()
    try:
        ver=subprocess.run([sys.executable,'-m','yt_dlp','--version'],capture_output=True,text=True,timeout=20)
        if ver.returncode:raise RuntimeError('yt-dlp not installed in this Python environment')
        atomic_json(directory/'runtime.json',{'yt_dlp_version':ver.stdout.strip(),'code':req['code']})
        with (directory/'stdout.txt').open('wb') as out,(directory/'stderr.txt').open('wb') as err:
            p=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout_s,stdin=subprocess.DEVNULL)
        if p.returncode:raise RuntimeError(f'yt-dlp exit code {p.returncode}; see stderr')
        paths=[json.loads(x) for x in (directory/'final_paths.jsonl').read_text().splitlines() if x.strip()]
        if len(paths)!=1:raise RuntimeError('Expected exactly one completed video')
        media=Path(paths[0]).resolve()
        if not media.is_relative_to(directory.resolve()) or not media.is_file():raise RuntimeError('Unexpected output path')
        probe=subprocess.run(['ffprobe','-v','error','-show_streams','-of','json',str(media)],capture_output=True,text=True,timeout=60,check=True)
        streams=json.loads(probe.stdout)['streams']
        if not any(x['codec_type']=='video' for x in streams) or not any(x['codec_type']=='audio' for x in streams):
            raise RuntimeError('Downloaded media needs both video and audio')
        # Source info is an output of acquisition; sanitization is itself recorded.
        for info in directory.glob('*.info.json'):
            safe=sanitize_info(json.loads(info.read_text()));atomic_json(info,safe)
        digest=store.ingest(media,{'type':'youtube','url':canonical_url,'acquisition_id':aid})
        elapsed=(time.perf_counter_ns()-started)/1e9
        result={'schema':'acquisition_result.v1','status':'SUCCEEDED','acquisition_id':aid,'asset_sha512':digest,
                'source_sha512':sha512_file(media),'elapsed_s':elapsed,'metadata_strategy':'strip_signed_urls_v1'}
        atomic_json(directory/'result.json',result)
        target=store.asset_path(digest)/'acquisitions'/aid;target.parent.mkdir(exist_ok=True)
        os.replace(directory,target)
        store.event(digest,{'event':'ACQUISITION_ADOPTED','request':req,'result':result,'path':str(target.relative_to(store.asset_path(digest)))})
        return result
    except BaseException as exc:
        if directory.exists():
            atomic_json(directory/'result.json',{'schema':'acquisition_result.v1','status':'FAILED','acquisition_id':aid,
                'retry_of':retry_of,'error_type':type(exc).__name__,'error':str(exc),'elapsed_s':(time.perf_counter_ns()-started)/1e9})
        raise
