from __future__ import annotations
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Protocol

@dataclass(frozen=True)
class ArtifactRef:
    asset_sha512: str
    producer_attempt_id: str
    name: str
    schema: str
    path: str
    sha512: str
    bytes: int

    def as_dict(self) -> dict:
        return asdict(self)

@dataclass(frozen=True)
class PluginSpec:
    node: str
    strategy_id: str
    strategy_version: str
    input_schemas: dict[str, str]
    output_schema: str
    default_params: dict = field(default_factory=dict)

@dataclass(frozen=True)
class ProducedFile:
    name: str
    path: str  # Relative to this attempt's work directory.
    schema: str

class Plugin(Protocol):
    spec: PluginSpec
    def execute(self, ctx: Any, inputs: dict[str, Path], params: dict) -> list[ProducedFile]: ...


def validate_json_document(schema: str, doc: dict) -> None:
    if not isinstance(doc, dict) or doc.get("schema") != schema:
        raise ValueError(f"Expected schema {schema}")
    if schema == "captions.v1":
        ids = set()
        width, height = doc["canvas"]["width"], doc["canvas"]["height"]
        for cue in doc["cues"]:
            if cue["id"] in ids: raise ValueError("Duplicate caption id")
            ids.add(cue["id"])
            if not isinstance(cue["text"], str) or not cue["text"].strip(): raise ValueError("Empty caption")
            if not (0 <= cue["start_us"] < cue["end_us"]): raise ValueError("Bad caption interval")
            if not 0 <= cue["confidence"] <= 1: raise ValueError("Bad confidence")
            box = cue.get("bbox_xyxy")
            if box is not None:
                x1,y1,x2,y2 = box
                if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height): raise ValueError("Bad caption box")
    # Other production schemas are documented separately; reference plugins also
    # validate semantic constraints in their own deterministic functions.
