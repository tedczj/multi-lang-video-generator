from __future__ import annotations
import json, os, platform, shutil, time, traceback
from dataclasses import asdict
from pathlib import Path
from importlib.metadata import entry_points
from .contracts import ArtifactRef, Plugin, ProducedFile, validate_json_document
from .store import AssetStore
from .util import atomic_json, canonical, check_no_secrets, code_provenance, inside, sha512_file, token

class AttemptFailed(RuntimeError):
    def __init__(self, attempt_id: str, message: str):
        super().__init__(message); self.attempt_id=attempt_id

class Context:
    def __init__(self, store, digest, attempt_id, directory):
        self.store=store;self.asset_sha512=digest;self.attempt_id=attempt_id
        self.directory=directory;self.work=directory/"work"
    def event(self,event,**data):
        self.store.event(self.asset_sha512,{"event":event,"attempt_id":self.attempt_id,**data})
    def write_json(self,name,document):
        atomic_json(inside(self.work,name),document)

class Engine:
    def __init__(self,store:AssetStore,project_root:Path,*,strict_git=False):
        self.store=store;self.project_root=project_root;self.strict_git=strict_git;self.plugins={}
    def register(self,plugin:Plugin):
        sid=token(plugin.spec.strategy_id)
        if sid in self.plugins: raise ValueError("Duplicate strategy id")
        self.plugins[sid]=plugin
    def load_installed_plugins(self, allowed_names=()):
        # Explicit allowlist: installing a distribution does not authorize execution.
        allowed=set(allowed_names)
        found=set()
        for entry in entry_points(group="bivideo.nodes"):
            if entry.name in allowed:
                self.register(entry.load()());found.add(entry.name)
        if allowed-found: raise ValueError(f"Unknown plugin entry points: {sorted(allowed-found)}")
    def run(self,digest,node,strategy_id,inputs,params=None,*,item="all",retry_of=None):
        # There is deliberately NO cache lookup, content-equality shortcut, or
        # 'exists -> success' branch. Every call allocates a new attempt.
        plugin=self.plugins[strategy_id]
        params={**plugin.spec.default_params, **(params or {})}
        check_no_secrets(params);canonical(params)
        if plugin.spec.node!=node: raise ValueError("Strategy cannot implement this node")
        provenance=code_provenance(self.project_root)
        if self.strict_git and (not provenance["git_commit"] or provenance["dirty"]):
            raise ValueError("Strict execution needs a clean, identifiable source build")
        aid,version,path=self.store.allocate(digest,node,item,retry_of)
        ctx=Context(self.store,digest,aid,path);started=time.perf_counter_ns()
        request={"schema":"node_request.v1","attempt_id":aid,"node":node,"item":item,"version":version,
                 "retry_of":retry_of,"strategy":asdict(plugin.spec),"code":provenance,"params":params,
                 "inputs":{k:v.as_dict() for k,v in inputs.items()},"cache_policy":"FORBID_RESULT_REUSE"}
        atomic_json(path/"request.json",request)
        atomic_json(path/"runtime.json",{"python":platform.python_version(),"platform":platform.platform(),"pid":os.getpid(),"code":provenance})
        ctx.event("NODE_STARTED",request=request)
        try:
            if set(inputs)!=set(plugin.spec.input_schemas): raise ValueError("Input ports do not match contract")
            resolved={}
            for name,ref in inputs.items():
                if ref.asset_sha512!=digest: raise ValueError("Cross-asset input is not allowed")
                if ref.schema!=plugin.spec.input_schemas[name]: raise ValueError("Input schema mismatch")
                resolved[name]=self.store.resolve(ref)
            with self.store.connect(self.store.asset_path(digest)) as db:
                for name,ref in inputs.items():
                    db.execute("INSERT INTO edges VALUES(?,?,?,?,?)",(aid,name,ref.producer_attempt_id,ref.name,ref.sha512))
            ctx.event("PLUGIN_INVOKED",strategy_id=strategy_id)
            produced=plugin.execute(ctx,resolved,params)  # ALWAYS reached for valid retry inputs.
            if not produced: raise ValueError("Plugin returned no artifacts")
            names=set();refs=[]
            for product in produced:
                token(product.name)
                if product.name in names: raise ValueError("Duplicate output name")
                names.add(product.name)
                source=inside(ctx.work,product.path)
                if not source.is_file(): raise ValueError("Output file is missing")
                if product.schema==plugin.spec.output_schema and source.suffix==".json":
                    validate_json_document(product.schema,json.loads(source.read_text()))
                target=path/"artifacts"/product.path; target.parent.mkdir(parents=True,exist_ok=True)
                # Copy, do not erase plugin raw/intermediate work evidence.
                shutil.copyfile(source,target)
                with target.open("rb") as f: os.fsync(f.fileno())
                refs.append(ArtifactRef(digest,aid,product.name,product.schema,str(target.relative_to(self.store.asset_path(digest))),sha512_file(target),target.stat().st_size))
            if not any(r.schema==plugin.spec.output_schema for r in refs): raise ValueError("Missing primary output contract")
            # Inventory every regular file created in this attempt, including raw/debug files.
            inventory=[]
            for file in sorted(path.rglob("*")):
                if file.is_symlink(): raise ValueError("Attempt contains symlink")
                if file.is_file(): inventory.append({"path":str(file.relative_to(path)),"sha512":sha512_file(file),"bytes":file.stat().st_size})
            elapsed=(time.perf_counter_ns()-started)/1e9
            result={"schema":"node_result.v1","attempt_id":aid,"status":"SUCCEEDED","elapsed_s":elapsed,
                    "outputs":[r.as_dict() for r in refs],"files":inventory,"request_sha512":sha512_file(path/"request.json")}
            # Terminal manifest is committed before the database publishes artifacts.
            atomic_json(path/"result.json",result)
            with self.store.connect(self.store.asset_path(digest)) as db:
                for ref in refs: db.execute("INSERT INTO artifacts VALUES(?,?,?)",(aid,ref.name,canonical(ref.as_dict()).decode()))
                db.execute("UPDATE attempts SET status='SUCCEEDED' WHERE id=?",(aid,))
            ctx.event("NODE_SUCCEEDED",outputs=result["outputs"],elapsed_s=elapsed,result_path=str((path/"result.json").relative_to(self.store.asset_path(digest))))
            return aid,{r.name:r for r in refs}
        except BaseException as exc:
            # If success was already durably published but logging failed, do not
            # overwrite the success manifest with a contradictory failure.
            row=self.store.attempt(digest,aid)
            if row["status"]=="SUCCEEDED": raise
            # A verified success manifest already on disk is a PREPARED commit.
            # Do not relabel it FAILED if publishing to SQLite was interrupted.
            if (path/"result.json").exists() and json.loads((path/"result.json").read_text()).get("status")=="SUCCEEDED":
                with self.store.connect(self.store.asset_path(digest)) as db:
                    db.execute("UPDATE attempts SET status='RECOVERY_REQUIRED' WHERE id=?",(aid,))
                raise AttemptFailed(aid,"Manifest prepared; metadata recovery required") from exc
            elapsed=(time.perf_counter_ns()-started)/1e9
            (path/"error.txt").write_text(traceback.format_exc())
            failed_files=[{"path":str(p.relative_to(path)),"sha512":sha512_file(p),"bytes":p.stat().st_size}
                          for p in sorted(path.rglob("*")) if p.is_file() and not p.is_symlink() and p.name!="result.json"]
            if not (path/"result.json").exists():
                atomic_json(path/"result.json",{"schema":"node_result.v1","attempt_id":aid,"status":"FAILED","elapsed_s":elapsed,
                      "error_type":type(exc).__name__,"error":str(exc),"outputs":[],"files":failed_files})
            with self.store.connect(self.store.asset_path(digest)) as db:
                db.execute("UPDATE attempts SET status='FAILED' WHERE id=?",(aid,))
            ctx.event("NODE_FAILED",error_type=type(exc).__name__,error=str(exc),elapsed_s=elapsed)
            if isinstance(exc,(KeyboardInterrupt,SystemExit)): raise
            raise AttemptFailed(aid,str(exc)) from exc

    def retry(self,digest,attempt_id,*,strategy_id=None,params=None):
        previous=self.store.attempt(digest,attempt_id)
        req=json.loads((self.store.asset_path(digest)/previous["relpath"]/"request.json").read_text())
        return self.run(digest,req["node"],strategy_id or req["strategy"]["strategy_id"],
                        {k:ArtifactRef(**v) for k,v in req["inputs"].items()},
                        req["params"] if params is None else params,item=req["item"],retry_of=attempt_id)
