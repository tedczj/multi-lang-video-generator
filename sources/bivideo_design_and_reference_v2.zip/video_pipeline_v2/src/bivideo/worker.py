from __future__ import annotations
import json,os,signal,subprocess
from .contracts import PluginSpec,ProducedFile
from .util import atomic_json

class SubprocessWorker:
    """Trusted, explicitly registered subprocess; not a security sandbox."""
    def __init__(self,spec:PluginSpec,argv:list[str],timeout_s=600):
        self.spec=spec;self.argv=list(argv);self.timeout_s=timeout_s
    def execute(self,ctx,inputs,params):
        request=ctx.work/'worker_request.json';response=ctx.work/'worker_response.json'
        atomic_json(request,{'schema':'worker_request.v1','attempt_id':ctx.attempt_id,
            'strategy_id':self.spec.strategy_id,'inputs':{k:str(v) for k,v in inputs.items()},
            'params':params,'output_dir':str(ctx.work),'response_path':str(response),
            'cache_policy':'FORBID_RESULT_REUSE'})
        argv=self.argv+['--request',str(request)]
        ctx.event('WORKER_STARTED',argv=argv,timeout_s=self.timeout_s)
        with (ctx.work/'stdout.txt').open('wb') as out,(ctx.work/'stderr.txt').open('wb') as err:
            p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
            try:p.wait(timeout=self.timeout_s)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=3)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
                raise TimeoutError('Worker timed out; process group terminated')
        if p.returncode:raise RuntimeError(f'Worker failed with exit {p.returncode}')
        result=json.loads(response.read_text())
        if result.get('attempt_id')!=ctx.attempt_id or result.get('status')!='SUCCEEDED':
            raise ValueError('Worker returned wrong attempt/status')
        if result.get('execution')!='EXECUTED':raise ValueError('Worker returned reused result; retries must execute')
        ctx.event('WORKER_FINISHED',worker_provenance=result.get('provenance',{}))
        return [ProducedFile(**item) for item in result['outputs']]
