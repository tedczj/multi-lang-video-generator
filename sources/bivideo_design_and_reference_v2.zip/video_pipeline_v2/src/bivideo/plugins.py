from __future__ import annotations
import json, subprocess
from .contracts import PluginSpec, ProducedFile
from .timeline import build_timeline

class ProbeFFprobe:
    spec=PluginSpec("probe","ffprobe","1",{"source":"source.bytes.v1"},"probe.v1",{"timeout_s":60})
    def execute(self,ctx,inputs,params):
        cmd=["ffprobe","-v","error","-show_format","-show_streams","-of","json",str(inputs["source"])]
        ctx.event("COMMAND",argv=cmd)
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=params.get("timeout_s",60))
        (ctx.work/"stderr.txt").write_text(p.stderr)
        if p.returncode: raise RuntimeError("ffprobe failed; see attempt stderr")
        raw=json.loads(p.stdout);ctx.write_json("probe.json",{"schema":"probe.v1","raw":raw})
        return [ProducedFile("probe","probe.json","probe.v1")]

class CaptionsFixture:
    """Only tests contract substitution. This class does NOT perform OCR."""
    def __init__(self,suffix="a"):
        self.spec=PluginSpec("ocr",f"fixture_{suffix}","1",{"source":"source.bytes.v1"},"captions.v1")
    def execute(self,ctx,inputs,params):
        ctx.write_json("raw.json",{"fixture":True,"strategy":self.spec.strategy_id})
        ctx.write_json("captions.json",{"schema":"captions.v1","canvas":{"width":1920,"height":1080},
              "cues":[{"id":"c1","text":params.get("text","Example"),"start_us":0,"end_us":1000000,
                        "confidence":0.99,"bbox_xyxy":[100,900,500,1000]}],"fixture_only":True})
        return [ProducedFile("captions","captions.json","captions.v1")]

class CaptionCount:
    spec=PluginSpec("caption_count","count","1",{"captions":"captions.v1"},"caption_count.v1")
    def execute(self,ctx,inputs,params):
        data=json.loads(inputs["captions"].read_text())
        ctx.write_json("count.json",{"schema":"caption_count.v1","count":len(data["cues"])})
        return [ProducedFile("count","count.json","caption_count.v1")]

class TimelineGapFirst:
    spec=PluginSpec("timeline","gap_first","2",{"request":"timeline_request.v1"},"timeline.v1")
    def execute(self,ctx,inputs,params):
        request=json.loads(inputs["request"].read_text());request.update(params)
        plan=build_timeline(request);ctx.write_json("timeline.json",plan)
        return [ProducedFile("timeline","timeline.json","timeline.v1")]

class JsonFixtureInput:
    spec=PluginSpec("fixture_input","fixture_input","1",{"source":"source.bytes.v1"},"timeline_request.v1")
    def execute(self,ctx,inputs,params):
        ctx.write_json("request.json",params["document"])
        return [ProducedFile("request","request.json","timeline_request.v1")]


def defaults():
    return [ProbeFFprobe(),CaptionsFixture("a"),CaptionsFixture("b"),CaptionCount(),TimelineGapFirst(),JsonFixtureInput()]
