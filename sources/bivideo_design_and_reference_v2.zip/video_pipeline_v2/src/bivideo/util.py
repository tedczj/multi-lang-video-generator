from __future__ import annotations
import hashlib, json, os, re, subprocess, tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha512_file(path: Path) -> str:
    h = hashlib.sha512()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(canonical(value) + b"\n"); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
        fsync_dir(path.parent)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def fsync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)


def token(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", value) or value in {".", ".."}:
        raise ValueError(f"Invalid path identifier: {value!r}")
    return value


def inside(root: Path, rel: str) -> Path:
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError("Absolute or escaping artifact path")
    candidate = root / p
    cur = root
    for part in p.parts:
        cur = cur / part
        if cur.is_symlink(): raise ValueError("Symlink artifacts are not accepted")
    if not candidate.resolve().is_relative_to(root.resolve()):
        raise ValueError("Artifact outside root")
    return candidate


@contextmanager
def file_lock(path: Path):
    # Reference implementation targets macOS/Linux, one host and a local filesystem.
    import fcntl
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try: yield
        finally: fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def check_no_secrets(value: Any) -> None:
    sensitive = {"api_key", "password", "authorization", "cookie", "cookies", "token", "access_token", "secret"}
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in sensitive and item not in (None, ""):
                raise ValueError(f"Use a secret_ref, not a plaintext {key}")
            check_no_secrets(item)
    elif isinstance(value, list):
        for item in value: check_no_secrets(item)


def code_provenance(root: Path) -> dict:
    files = sorted(list((root / "src").rglob("*.py")) + list((root / "scripts").rglob("*.py")) + ([root/"pyproject.toml"] if (root/"pyproject.toml").exists() else []))
    source_hash = hashlib.sha512()
    for p in files:
        source_hash.update(str(p.relative_to(root)).encode() + b"\0" + p.read_bytes() + b"\0")
    tree = source_hash.hexdigest()
    try:
        commit = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True).strip()
        status = subprocess.check_output(["git", "-C", str(root), "status", "--porcelain", "--", "src", "scripts", "pyproject.toml"], text=True)
        return {"git_commit": commit, "dirty": bool(status.strip()), "code_tree_sha512": tree}
    except (subprocess.CalledProcessError, FileNotFoundError):
        build = root / "BUILD_INFO.json"
        if build.exists():
            data = json.loads(build.read_text())
            return {"git_commit": data["git_commit"], "dirty": tree != data["code_tree_sha512"], "code_tree_sha512": tree}
        return {"git_commit": None, "dirty": True, "code_tree_sha512": tree}
