from __future__ import annotations
import array,hashlib,json,math,subprocess,sys,wave
from pathlib import Path
from fractions import Fraction
from .timeline import validate_plan
from .util import atomic_json


def read_wav(path:Path):
    with wave.open(str(path),'rb') as w:
        if w.getsampwidth()!=2 or w.getnchannels()!=1:raise ValueError('Reference renderer requires mono PCM16 WAV')
        rate=w.getframerate();data=array.array('h',w.readframes(w.getnframes()))
    if sys.byteorder!='little':data.byteswap()
    return rate,data


def write_wav(path:Path,rate:int,samples):
    data=array.array('h',samples)
    if sys.byteorder!='little':data.byteswap()
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(data.tobytes())


def checked(cmd:list[str],log:Path,timeout=120):
    with log.open('ab') as f:
        f.write((json.dumps(cmd,ensure_ascii=False)+'\n').encode());f.flush()
        p=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=f,stderr=f,timeout=timeout)
    if p.returncode:raise RuntimeError(f'Command failed ({p.returncode}); see {log.name}')


def render_reference(source:Path,plan:dict,clips:dict[str,Path],out:Path)->dict:
    """Streaming frame renderer for correctness tests, not a high-throughput editor.
    SDR CFR input, 48kHz mono audio, no subtitle removal/burn-in or AI inference.
    """
    validate_plan(plan);out.mkdir(parents=True,exist_ok=True)
    if (out/'master.mkv').exists():raise FileExistsError('Use a new execution directory')
    log=out/'commands.log';rate=plan['sample_rate']
    checked(['ffmpeg','-nostdin','-v','error','-i',str(source),'-map','0:a:0','-ar',str(rate),'-ac','1','-c:a','pcm_s16le',str(out/'source.wav')],log)
    r,original=read_wav(out/'source.wav')
    if r!=rate or len(original)!=plan['source_samples']:raise ValueError('Decoded source sample count does not match plan')
    audio=array.array('h');cursor=0
    for h in plan['holds']:
        cut=h['source_pause_sample'];audio.extend(original[cursor:cut]);audio.extend([0]*h['hold_samples']);cursor=cut
    audio.extend(original[cursor:])
    if len(audio)!=plan['output_samples']:raise ValueError('Audio assembly count mismatch')
    clipping=0
    for d in plan['dubs']:
        r,clip=read_wav(clips[d['clip_id']])
        if r!=rate or len(clip)!=d['end_sample']-d['start_sample']:raise ValueError('Clip has changed since planning')
        for i,value in enumerate(clip,d['start_sample']):
            mixed=audio[i]+value
            if not -32768<=mixed<=32767:clipping+=1
            audio[i]=max(-32768,min(32767,mixed))
    if clipping:raise ValueError(f'Audio clipped at {clipping} samples; configure mix gain')
    write_wav(out/'master.wav',rate,audio)
    meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_streams','-of','json',str(source)]))['streams'][0]
    width,height=meta['width'],meta['height'];fps=f"{plan['fps_num']}/{plan['fps_den']}"
    if Fraction(meta['avg_frame_rate'])!=Fraction(plan['fps_num'],plan['fps_den']):raise ValueError('Normalize source frame rate first')
    frame_bytes=width*height*3
    counts={}
    for h in plan['holds']:counts[h['video_insert_before_frame']]=counts.get(h['video_insert_before_frame'],0)+h['hold_frames']
    dec_cmd=['ffmpeg','-nostdin','-v','error','-threads','1','-i',str(source),'-map','0:v:0','-vsync','0','-f','rawvideo','-pix_fmt','rgb24','pipe:1']
    enc_cmd=['ffmpeg','-nostdin','-v','error','-threads','1','-f','rawvideo','-pix_fmt','rgb24','-video_size',f'{width}x{height}','-framerate',fps,'-i','pipe:0','-i',str(out/'master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','ffv1','-level','3','-c:a','pcm_s16le',str(out/'master.mkv')]
    with log.open('a') as f:f.write(json.dumps(dec_cmd)+'\n'+json.dumps(enc_cmd)+'\n')
    with (out/'decode.stderr').open('wb') as de,(out/'encode.stderr').open('wb') as ee:
        decoder=subprocess.Popen(dec_cmd,stdout=subprocess.PIPE,stderr=de,stdin=subprocess.DEVNULL)
        encoder=subprocess.Popen(enc_cmd,stdin=subprocess.PIPE,stderr=ee,stdout=subprocess.DEVNULL)
        try:
            for index in range(plan['source_frames']):
                frame=decoder.stdout.read(frame_bytes)
                if len(frame)!=frame_bytes:raise RuntimeError('Source ended before planned frame count')
                encoder.stdin.write(frame)
                for _ in range(counts.get(index+1,0)):encoder.stdin.write(frame)
            if decoder.stdout.read(1):raise RuntimeError('Source contains unplanned frames')
            decoder.stdout.close();encoder.stdin.close()
            if decoder.wait(timeout=60) or encoder.wait(timeout=60):raise RuntimeError('FFmpeg frame pipeline failed')
        finally:
            for p in (decoder,encoder):
                if p.poll() is None:p.kill();p.wait()
    checked(['ffmpeg','-nostdin','-v','error','-i',str(out/'master.mkv'),'-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(out/'result.mp4')],log)
    checked(['ffmpeg','-nostdin','-v','error','-xerror','-i',str(out/'result.mp4'),'-f','null','-'],log)
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','json',str(out/'result.mp4')]))
    actual_frames=int(probe['streams'][0]['nb_read_frames'])
    if actual_frames!=plan['output_frames']:raise ValueError('Final encoded frame count mismatch')
    qa={'schema':'qa.v1','profile':'reference_structural_only','structural_status':'PASS','release_status':'REVIEW',
        'frames':actual_frames,'samples':len(audio),'full_decode':'PASS',
        'not_executed':['OCR','inpainting','font matching','translation','voice cloning','semantic/audio quality QA']}
    atomic_json(out/'qa.json',qa);return qa


def frame_hashes(path:Path)->list[str]:
    p=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',str(path),'-map','0:v:0','-pix_fmt','rgb24','-f','framemd5','-'],capture_output=True,text=True,check=True,timeout=120)
    return [line.split(',')[-1].strip() for line in p.stdout.splitlines() if line and not line.startswith('#')]


def make_fixture(out:Path,gap_long=False):
    out.mkdir(parents=True,exist_ok=True);rate=48000;seconds=20 if gap_long else 10;second_start=13 if gap_long else 8
    original=array.array('h',[0]*(seconds*rate))
    for start,end,freq in [(2,5,440),(second_start,second_start+1,660)]:
        for n in range(start*rate,end*rate):original[n]=int(3000*math.sin(2*math.pi*freq*n/rate))
    write_wav(out/'fixture_source.wav',rate,original)
    clips={}
    for name,duration,freq in [('zh-a',4,880),('zh-b',1,990)]:
        path=out/(name+'.wav');write_wav(path,rate,(int(2500*math.sin(2*math.pi*freq*n/rate)) for n in range(duration*rate)));clips[name]=path
    source=out/'fixture_source.mkv'
    checked(['ffmpeg','-nostdin','-v','error','-f','lavfi','-i',f'testsrc=size=160x96:rate=25:duration={seconds}','-i',str(out/'fixture_source.wav'),'-c:v','ffv1','-level','3','-c:a','pcm_s16le',str(source)],out/'fixture_commands.log')
    request={'schema':'timeline_request.v1','fps_num':25,'fps_den':1,'sample_rate':rate,'source_frames':seconds*25,'source_samples':seconds*rate,
        'utterances':[{'id':'a','start_sample':2*rate,'end_sample':5*rate,'dubs':[{'clip_id':'zh-a','language':'zh','samples':4*rate,'sample_rate':rate}]},
                      {'id':'b','start_sample':second_start*rate,'end_sample':(second_start+1)*rate,'dubs':[{'clip_id':'zh-b','language':'zh','samples':rate,'sample_rate':rate}]}]}
    return source,clips,request
