# 契约范围

这些 JSON Schema 是骨架核心产物的机器可读结构定义；`contracts.py` 和 `timeline.py` 另做语义校验，当前不是通过通用 JSON Schema 引擎自动加载全部文件。生产接入时应启用完整 schema 校验和跨字段、跨时钟检查。

`captions.v1` 是测试骨架的较小契约，已知数字置信度；生产 `CaptionSet.v1` 要补 clock_id、evidence_refs、source_scope、可空置信度和缺字段原因。不能假设不同名称已经无缝兼容。`quality_report.v1` 是计划中的完整门禁格式；演示中的结构 QA 字段较小，整体发布状态仍为 REVIEW。

版本规则：破坏兼容的字段/语义改动增 major；增加可选字段保持 major 并记录 minor；迁移执行独立 adapter 节点，保留原输入与转换版本。永远不原地改写旧产物来升级 schema。
