# YouTube 双语视频流水线：设计与参考骨架

本项目采用新的轻量骨架，按视频文件 SHA-512 聚合数据，所有节点每次执行独立版本，支持标准契约插件、真实重试和输入输出血缘。

时间策略：英文结束等 1 秒，译文配音先利用自然无讲话空档；不足时只补下一段英文开始前的冻结帧，中文结束至少等 1 秒再恢复下一段英文。原画面与原音同步暂停/恢复。多出的原片空档保留。

**不是完整的一键 AI 产品。** 已实现的是执行/存储/重试内核、可替换插件协议、yt-dlp 下载适配器、确定性时间线、真实 FFmpeg 参考合成。OCR、去字幕、字体识别、翻译、声音克隆、完整 DAG 调度和综合 QA 需要按设计接入。本包演示使用测试字幕和提示音，不代表模型已经集成。

## 文档

- `docs/DEVELOPMENT_DESIGN_V2_ZH.md`：覆盖全部十项需求的完整设计、业务 DAG、持久化、协议、时间线、重试、日志和开发分期。
- `docs/CODE_REFERENCES_ZH.md`：各上游仓库的具体文件/函数、短代码摘录、参考边界和需要新写的内容。
- `docs/REAL_TEST_MATRIX_ZH.md`：已实现测试与未来真实模型/网络/媒体/故障测试的场景及验收条件。
- `verification/TEST_REPORT_ZH.md`：本次真实执行的环境、数量、结果与未执行项。
- `schemas/`：骨架契约及适用范围。`configs/pipeline.blueprint.json` 是生产 DAG 蓝图，**当前 CLI 不执行这个配置文件**。

## 1. 环境

Python 3.11+；macOS 或 Linux；本地文件系统。FFmpeg/FFprobe 在 PATH 中，参考演示需 FFV1、libx264、AAC 和基础 testsrc 滤镜。本包未在 Mac 实测，实际验证系统见测试报告。核心 Python 代码无第三方运行依赖；测试使用 pytest。

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[test]'
ffmpeg -version
ffprobe -version
```

也可不安装项目，以 `PYTHONPATH=src python -m bivideo.cli ...` 运行；这不省略测试环境本身所需的 pytest。

## 2. 执行本地可验证演示

```bash
python -m pytest -q
PYTHONPATH=src python -m bivideo.cli demo --out /tmp/bivideo-short-001
PYTHONPATH=src python -m bivideo.cli demo --out /tmp/bivideo-long-001 --long-gap
```

输出目录必须不存在或为空，不能覆盖上一轮演示。每个结果的 `demo_summary.json` 给出成片、QA、asset SHA-512 和目录路径。真实产物全部在 `videos/<SHA-512>/` 内。

短间隔：10 秒源片 → 15 秒、375 帧、720000 个 48 kHz 音频采样帧；长间隔：20 秒源片 → 20 秒、500 帧、960000 个采样帧。测试对无损主视频逐帧哈希、无损主音轨逐采样验证；MP4 只验证媒体结构和完整解码，不宣称有损字节相同。

音频为不同频率的提示音。演示没有烧录字幕，没有真实语音/字体匹配/视频修复；QA 报告的整体发布状态为 REVIEW，明确列出未执行项。

## 3. 导入真实本地视频和重试

```bash
PYTHONPATH=src python -m bivideo.cli --data ./run-data ingest --local /path/to/video.mp4
```

返回 `asset_sha512` 和 `source_ref`。把实际值填入下列变量，不要使用省略号代替：

```bash
ASSET_SHA512='<上一步返回的128位十六进制SHA-512>'
PYTHONPATH=src python -m bivideo.cli --data ./run-data node-run \
  --asset "$ASSET_SHA512" --strategy ffprobe

ATTEMPT_ID='<上一步返回的attempt_id>'
PYTHONPATH=src python -m bivideo.cli --data ./run-data retry \
  --asset "$ASSET_SHA512" --attempt "$ATTEMPT_ID"

PYTHONPATH=src python -m bivideo.cli --data ./run-data history --asset "$ASSET_SHA512"
```

两次 ffprobe 是两次真实执行。即使同输入、同代码、同参数、同输出内容，也产生新的目录、attempt、文件清单和日志。`--strict-git` 为全局参数，生产使用它拒绝无法识别或已修改的核心构建。

## 4. YouTube 下载适配器

联网安装：

```bash
python -m pip install -e '.[download]'
PYTHONPATH=src python -m bivideo.cli --data ./run-data download \
  --url 'https://www.youtube.com/watch?v=<实际视频ID>'
```

仅接受单个 HTTPS YouTube 页面，默认整条下载；页面 `t=` 不触发片段截取。需要自有/授权的视频、可用网络及 yt-dlp 官方要求的 JS runtime/EJS 和 FFmpeg。不能把安装完成等同于 YouTube 在所在网络可用。某些视频需明确选择原始音轨/身份凭据，当前示例不提供凭据管理和原声轨自动判别。

下载代码会忽略外部配置，关闭 download archive/结果缓存/旧文件续用；每次使用全新 acquisition 目录，先检查结束码和媒体流，完成后才以最终媒体 bytes 建立 asset。官方当前选项与依赖见代码参考。**本次未实际完成联网下载，命令构造单测不能替代网络测试。**

失败时 SHA 可能尚不存在，获取证据保留在 `acquisitions/<id>`；不能提前猜测应放入哪个 SHA 目录。再次调用 `download --retry-of <旧acquisition_id>` 创建新的获取记录，旧失败证据不删除。关联的历史获取链归并是生产 acquisition recovery 的补充开发项。

## 5. 替换节点实现

`PluginSpec` 定义业务节点、策略 ID/版本、输入端口 schema、主要输出 schema 和默认参数。`execute()` 收到已验证输入文件与本次 work 目录。返回相对本次 work 的产物列表，不得返回其他 attempt 的旧文件。

代码例子见 `plugins.py`；`fixture_a/fixture_b` 是接口测试，`count` 证明下游无需依赖 OCR 实现。真实模型应使用独立 worker：参考 `worker.py` 与 `scripts/contract_worker.py`，但后者只是演示协议，不做 OCR。

安装式插件使用 entry point group `bivideo.nodes`，**必须显式允许**：

```bash
PYTHONPATH=src python -m bivideo.cli --data ./run-data --plugin '<entry_point_name>' \
  node-run --asset "$ASSET_SHA512" --strategy '<registered_strategy_id>'
```

Worker 不是沙箱；只运行可信代码。模型环境自己锁定模型 revision、权重摘要及 provider 返回的实际身份，不能只报一个营销模型名。

## 6. 数据和日志

```text
run-data/
  acquisitions/<尚未知SHA的获取ID>/
  videos/<原视频SHA-512>/
    source/original.bin
    acquisitions/<已归档获取ID>/
    nodes/<node>/<item>/v000001_<attempt>/
      request.json
      runtime.json
      work/
      artifacts/
      result.json
    selections/<branch>/<selection_id>.json
    pipeline.jsonl
    index.sqlite
```

`original.bin` 是原文件字节，不因扩展名改变内容，FFprobe 可直接探测。`pipeline.jsonl` 是每个视频的一份总日志，节点 stdout/stderr 和原始模型响应属于版本化执行证据。各产物记录源输入、策略、代码身份、参数和文件 SHA-512。

日志投影修复命令：

```bash
PYTHONPATH=src python -m bivideo.cli --data ./run-data rebuild-log --asset "$ASSET_SHA512"
```

它不是全功能崩溃恢复器。生产还需按设计实现 orphan/lease 恢复、文件索引重建和发布事务恢复。数据库请使用本地磁盘，不把同一 SQLite WAL 放在多机共享网络文件系统上。

## 7. 固定源码版本

`BUILD_INFO.json` 保存本包核心构建的真实 Git commit 和代码树摘要。`SOURCE.bundle` 是相同源代码的 Git bundle；可另选空目录用 Git clone 恢复源码历史：

```bash
git clone SOURCE.bundle /tmp/bivideo-source-checkout
```

打包目录没有 `.git` 时会用构建身份并重新核对代码树摘要；本地源码修改会标 dirty。代码身份覆盖 `src/*.py`、`scripts/*.py`、`pyproject.toml`；第三方 worker 代码和外部模型须另行报告版本。

`references.catalog.json` 是上游候选表，不是已锁定版本。联网开发环境执行：

```bash
python scripts/pin_upstreams.py --out upstreams.lock.json
```

脚本解析真实 commit 并验证对象及文件路径；失败不会产出一个伪成功锁。生成时间与此前网上查看分支的时间不同，应重新审查锁定源码，再构建 worker。上游源码/模型/字体不包含在本包，许可须分别核查。

## 8. 尚需开发

完整 DAG 调度、真实 OCR/ASR/修复/字体/翻译/克隆模型适配器、VFR/HDR 等归一化、双声道生产混音、双语布局、长视频高效渲染、综合质量门禁、故障恢复和 provider 身份/凭据治理均按详细设计逐项实施。参考渲染器只验证 CFR SDR、单声道 PCM 工作格式；不用它来冒充通用视频转码服务。
