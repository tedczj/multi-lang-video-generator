import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_reference_catalog_does_not_fabricate_locks():
    data=json.loads((ROOT/'references.catalog.json').read_text())
    assert data['status']=='CANDIDATES_NOT_A_RELEASE_LOCK'
    assert all(x['resolved_commit'] is None for x in data['repositories'])

def test_machine_readable_contracts_and_blueprint():
    for path in (ROOT/'schemas').glob('*.json'):
        doc=json.loads(path.read_text())
        assert doc['type']=='object' and 'required' in doc
    config=json.loads((ROOT/'configs/pipeline.blueprint.json').read_text())
    assert config['status']=='DESIGN_ONLY_NOT_EXECUTABLE_BY_REFERENCE_CLI'
    seen=set()
    for node in config['nodes']:
        assert set(node['dependencies']) <= seen
        assert node['id'] not in seen
        seen.add(node['id'])
