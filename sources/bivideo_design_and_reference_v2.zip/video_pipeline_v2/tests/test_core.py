import concurrent.futures, json
from pathlib import Path
import pytest
from bivideo.store import AssetStore
from bivideo.engine import Engine, AttemptFailed
from bivideo.plugins import defaults
from bivideo.contracts import ArtifactRef,PluginSpec,ProducedFile
from bivideo.util import canonical,inside

ROOT=Path(__file__).resolve().parents[1]
@pytest.fixture
def setup(tmp_path):
    source=tmp_path/'source.mp4';source.write_bytes(b'fixture source bytes')
    store=AssetStore(tmp_path/'data');digest=store.ingest(source)
    engine=Engine(store,ROOT)
    for p in defaults():engine.register(p)
    return store,digest,engine,source

def test_same_bytes_same_asset(setup,tmp_path):
    s,d,e,source=setup;other=tmp_path/'other.webm';other.write_bytes(source.read_bytes())
    assert s.ingest(other)==d
    assert len(list((s.root/'videos').iterdir()))==1

def test_changed_bytes_new_asset(setup):
    s,d,e,source=setup;source.write_bytes(b'different bytes')
    assert s.ingest(source)!=d

def test_identical_retry_executes_and_preserves_old_files(setup):
    s,d,e,_=setup
    a,out=e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)},{'text':'Hello'})
    first=s.resolve(out['captions']).read_bytes()
    b,out2=e.retry(d,a)
    assert a!=b
    assert out['captions'].sha512==out2['captions'].sha512
    assert out['captions'].path!=out2['captions'].path
    assert s.resolve(out['captions']).read_bytes()==first
    assert s.attempt(d,b)['retry_of']==a
    events=[json.loads(x) for x in (s.asset_path(d)/'pipeline.jsonl').read_text().splitlines()]
    assert len([x for x in events if x['event']=='PLUGIN_INVOKED'])==2

def test_strategy_swap_same_downstream_contract(setup):
    s,d,e,_=setup
    _,a=e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)})
    _,b=e.run(d,'ocr','fixture_b',{'source':s.source_ref(d)})
    ca,_=e.run(d,'caption_count','count',{'captions':a['captions']})
    cb,_=e.run(d,'caption_count','count',{'captions':b['captions']})
    with s.connect(s.asset_path(d)) as db:
        edges=db.execute('SELECT parent_attempt FROM edges WHERE child_attempt IN (?,?)',(ca,cb)).fetchall()
    assert {r[0] for r in edges}=={a['captions'].producer_attempt_id,b['captions'].producer_attempt_id}

def test_explicit_selections_are_versioned(setup):
    s,d,e,_=setup;_,o=e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)})
    a=s.select(d,'branch-a',o);b=s.select(d,'branch-a',o)
    assert a!=b
    assert len(list((s.asset_path(d)/'selections/branch-a').glob('*.json')))==2

def test_output_tampering_is_rejected(setup):
    s,d,e,_=setup;_,o=e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)})
    (s.asset_path(d)/o['captions'].path).write_text('corrupted')
    with pytest.raises(ValueError):s.resolve(o['captions'])

def test_forged_lineage_is_rejected(setup):
    s,d,e,_=setup;_,o=e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)})
    r=o['captions'].as_dict();r['producer_attempt_id']='forged'
    with pytest.raises(ValueError):s.resolve(ArtifactRef(**r))

def test_cross_asset_reference_is_rejected(setup,tmp_path):
    s,d,e,_=setup;p=tmp_path/'second';p.write_bytes(b'second');d2=s.ingest(p)
    with pytest.raises(AttemptFailed):e.run(d,'ocr','fixture_a',{'source':s.source_ref(d2)})

def test_failed_attempt_retains_evidence_and_retry_invokes(setup):
    s,d,e,_=setup
    class Fail:
        spec=PluginSpec('bad','bad','1',{'source':'source.bytes.v1'},'bad.v1')
        calls=0
        def execute(self,ctx,inputs,params):
            self.calls+=1;ctx.write_json('partial.json',{'calls':self.calls});raise RuntimeError('intentional')
    p=Fail();e.register(p)
    with pytest.raises(AttemptFailed) as x:e.run(d,'bad','bad',{'source':s.source_ref(d)})
    with pytest.raises(AttemptFailed) as y:e.retry(d,x.value.attempt_id)
    assert p.calls==2 and x.value.attempt_id!=y.value.attempt_id
    path=s.asset_path(d)/s.attempt(d,x.value.attempt_id)['relpath']
    assert (path/'work/partial.json').exists()
    assert json.loads((path/'result.json').read_text())['status']=='FAILED'

def test_invalid_output_never_published(setup):
    s,d,e,_=setup
    class Invalid:
        spec=PluginSpec('bad','invalid','1',{'source':'source.bytes.v1'},'captions.v1')
        def execute(self,ctx,inputs,params):
            ctx.write_json('x.json',{'schema':'wrong'})
            return [ProducedFile('captions','x.json','captions.v1')]
    e.register(Invalid())
    with pytest.raises(AttemptFailed) as ex:e.run(d,'bad','invalid',{'source':s.source_ref(d)})
    with pytest.raises(KeyError):s.ref(d,ex.value.attempt_id,'captions')

def test_concurrent_version_allocation(setup):
    s,d,_,_=setup
    def execute(_):
        e=Engine(s,ROOT)
        for p in defaults():e.register(p)
        return e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)})[0]
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:ids=list(pool.map(execute,range(12)))
    assert len(set(ids))==12
    assert sorted(s.attempt(d,i)['version'] for i in ids)==list(range(1,13))

def test_log_projection_rebuild(setup):
    s,d,e,_=setup;e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)})
    path=s.asset_path(d)/'pipeline.jsonl';original=path.read_bytes();path.write_bytes(b'{broken')
    s.rebuild_log(d);assert path.read_bytes()==original

@pytest.mark.parametrize('path',['../escape','/absolute','a/../../escape'])
def test_output_escape_rejected(tmp_path,path):
    with pytest.raises(ValueError):inside(tmp_path,path)

def test_symlink_output_rejected(tmp_path):
    outside=tmp_path/'outside';outside.write_text('x');root=tmp_path/'root';root.mkdir();(root/'link').symlink_to(outside)
    with pytest.raises(ValueError):inside(root,'link')

def test_secret_params_rejected(setup):
    s,d,e,_=setup
    with pytest.raises(ValueError):e.run(d,'ocr','fixture_a',{'source':s.source_ref(d)},{'api_key':'secret-value'})

def test_nonfinite_parameters_rejected():
    with pytest.raises(ValueError):canonical({'x':float('nan')})
