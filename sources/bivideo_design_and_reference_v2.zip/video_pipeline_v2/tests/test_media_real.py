import array,json,shutil
import pytest
from bivideo.media import make_fixture,render_reference,frame_hashes,read_wav
from bivideo.timeline import build_timeline

@pytest.mark.real
@pytest.mark.parametrize('long_gap',[False,True],ids=['short-gap-freeze','long-gap-no-freeze'])
def test_real_ffmpeg_output_against_independent_golden(tmp_path,long_gap):
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):pytest.skip('Real FFmpeg binaries required')
    source,clips,request=make_fixture(tmp_path/'inputs',long_gap)
    plan=build_timeline(request);out=tmp_path/'render';qa=render_reference(source,plan,clips,out)
    src_hashes=frame_hashes(source);actual=frame_hashes(out/'master.mkv')
    # Independent expected values; not derived from the produced timeline.
    if long_gap:expected=src_hashes;expected_frames=500
    else:expected=src_hashes[:200]+[src_hashes[199]]*75+src_hashes[200:]+[src_hashes[249]]*50;expected_frames=375
    assert actual==expected and qa['frames']==expected_frames
    _,original=read_wav(tmp_path/'inputs/fixture_source.wav');_,rendered=read_wav(out/'master.wav')
    rate=48000
    if long_gap:golden=array.array('h',original);starts=[6,15]
    else:golden=array.array('h',original[:8*rate]);golden.extend([0]*(3*rate));golden.extend(original[8*rate:]);golden.extend([0]*(2*rate));starts=[6,13]
    for name,start in zip(['zh-a','zh-b'],starts):
        _,clip=read_wav(clips[name])
        for i,value in enumerate(clip,start*rate):golden[i]+=value
    assert rendered==golden
    assert qa['release_status']=='REVIEW'  # No pretend AI quality pass.
