import json,sys
from pathlib import Path
import pytest
from bivideo.contracts import PluginSpec
from bivideo.store import AssetStore
from bivideo.engine import Engine,AttemptFailed
from bivideo.worker import SubprocessWorker
ROOT=Path(__file__).resolve().parents[1]

def make(tmp_path,timeout=10):
    f=tmp_path/'source';f.write_bytes(b'test');s=AssetStore(tmp_path/'data');d=s.ingest(f);e=Engine(s,ROOT)
    e.register(SubprocessWorker(PluginSpec('ocr','fixture_worker','1',{'source':'source.bytes.v1'},'captions.v1'),[sys.executable,str(ROOT/'scripts/contract_worker.py')],timeout))
    return s,d,e

def test_real_subprocess_protocol_and_repeat(tmp_path):
    s,d,e=make(tmp_path);a,_=e.run(d,'ocr','fixture_worker',{'source':s.source_ref(d)});b,_=e.retry(d,a)
    assert a!=b
    def nonce(aid):return json.loads((s.asset_path(d)/s.attempt(d,aid)['relpath']/'work/worker_response.json').read_text())['provenance']['invocation_nonce']
    assert nonce(a)!=nonce(b)

def test_worker_timeout_retains_request(tmp_path):
    s,d,e=make(tmp_path,.1)
    with pytest.raises(AttemptFailed) as ex:e.run(d,'ocr','fixture_worker',{'source':s.source_ref(d)},{'sleep_s':5})
    p=s.asset_path(d)/s.attempt(d,ex.value.attempt_id)['relpath']
    assert (p/'work/worker_request.json').exists()
    assert json.loads((p/'result.json').read_text())['error_type']=='TimeoutError'
