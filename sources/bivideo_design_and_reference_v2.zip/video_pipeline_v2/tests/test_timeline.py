import copy,math,random
from fractions import Fraction
import pytest
from bivideo.timeline import build_timeline,nearest

def req(gap=3,clip=4):
    r=48000;end=5;start=5+gap;length=start+2
    return {'schema':'timeline_request.v1','fps_num':25,'fps_den':1,'sample_rate':r,
            'source_frames':math.ceil(length*25),'source_samples':math.ceil(length*25)*1920,
            'utterances':[{'id':'a','start_sample':2*r,'end_sample':5*r,'dubs':[{'clip_id':'zh-a','language':'zh','samples':int(clip*r),'sample_rate':r}]},
                          {'id':'b','start_sample':int(start*r),'end_sample':int((start+1)*r),'dubs':[{'clip_id':'zh-b','language':'zh','samples':r,'sample_rate':r}]}]}

@pytest.mark.parametrize('gap,expected',[(8,0),(6,0),(3,3),(.3,5.72),(0,6)])
def test_gap_first_cases(gap,expected):
    p=build_timeline(req(gap));a=[h for h in p['holds'] if h['after_utterance']=='a']
    assert (a[0]['hold_frames']/25 if a else 0)==expected

def test_user_example():
    p=build_timeline(req());assert p['dubs'][0]['start_sample']==6*48000
    assert p['dubs'][0]['end_sample']==10*48000
    assert p['original_speech'][1]['start_sample']==11*48000
    assert p['holds'][0]['freeze_source_frame']==199

def test_long_gap_not_shortened():
    p=build_timeline(req(8));assert p['original_speech'][1]['start_sample']==13*48000

def test_last_sentence_uses_tail_and_extends():
    p=build_timeline(req());assert p['holds'][-1]['source_pause_sample']==10*48000
    assert p['output_frames']==375  # 10 source seconds + 3 first hold + 2 final hold

def test_last_sentence_tail_is_sufficient():
    x=req();x['source_frames']=20*25;x['source_samples']=20*48000
    p=build_timeline(x);assert len(p['holds'])==1

def test_no_speech_no_holds():
    x=req();x['utterances']=[];p=build_timeline(x)
    assert p['output_frames']==x['source_frames'] and not p['holds']

def test_overlap_rejected():
    x=req();x['utterances'][1]['start_sample']=4*48000
    with pytest.raises(ValueError):build_timeline(x)

def test_missing_audio_rejected():
    x=req();x['utterances'][0]['dubs'][0]['samples']=0
    with pytest.raises(ValueError):build_timeline(x)

def test_multiple_languages():
    x=req();x['utterances'][0]['dubs'].append({'clip_id':'ja-a','language':'ja','samples':2*48000,'sample_rate':48000})
    p=build_timeline(x);assert p['dubs'][1]['start_sample']==11*48000
    assert p['original_speech'][1]['start_sample']==14*48000

def test_subframe_pause_keeps_previous_presented_frame():
    x=req(.3);p=build_timeline(x);h=p['holds'][0]
    assert h['source_pause_sample']==int(5.3*48000)
    assert h['video_insert_before_frame']==133 and h['freeze_source_frame']==132

def test_2997_no_cumulative_rounding_drift():
    rate=48000;fps=Fraction(30000,1001);rng=random.Random(91);units=[];pos=0
    for i in range(1000):
        start=pos;end=start+rng.randint(8000,20000);pos=end+rng.randint(0,1000)
        units.append({'id':str(i),'start_sample':start,'end_sample':end,'dubs':[{'clip_id':f'z{i}','language':'zh','samples':rng.randint(5000,50000),'sample_rate':rate}]})
    frames=math.ceil(Fraction(pos+rate,rate)*fps)
    x={'schema':'timeline_request.v1','fps_num':30000,'fps_den':1001,'sample_rate':rate,'source_frames':frames,
       'source_samples':nearest(Fraction(frames,1)/fps*rate),'utterances':units}
    p=build_timeline(x)
    ideal=Fraction(sum(h['hold_frames'] for h in p['holds']),1)/fps*rate
    actual=p['output_samples']-p['source_samples']
    assert abs(Fraction(actual)-ideal)<=Fraction(1,2)

def test_400_random_timeline_invariants():
    rng=random.Random(817)
    for _ in range(400):
        gap=rng.randint(0,20);clip=rng.randint(1,15)
        p=build_timeline(req(gap,clip))
        for d in p['dubs']:
            for en in p['original_speech']:
                assert not (max(d['start_sample'],en['start_sample'])<min(d['end_sample'],en['end_sample']))
