from pathlib import Path
import os,sys
import pytest
from bivideo.acquire import canonical_youtube_url,command,acquire_youtube
from bivideo.store import AssetStore

@pytest.mark.parametrize('url',['https://www.youtube.com/watch?v=BaW_jenozKc&t=33s','https://youtu.be/BaW_jenozKc','https://www.youtube.com/shorts/BaW_jenozKc'])
def test_url_normalization(url):
    assert canonical_youtube_url(url)=='https://www.youtube.com/watch?v=BaW_jenozKc'

@pytest.mark.parametrize('url',['file:///etc/passwd','https://youtube.com.evil.example/watch?v=BaW_jenozKc','https://127.0.0.1/x','https://www.youtube.com/playlist?list=x','https://user:pass@youtube.com/watch?v=BaW_jenozKc'])
def test_invalid_url(url):
    with pytest.raises(ValueError):canonical_youtube_url(url)

def test_downloader_cannot_skip_retry_by_archive_or_existing_file(tmp_path):
    args=command('https://www.youtube.com/watch?v=BaW_jenozKc',tmp_path,'bv*+ba/b')
    for flag in ['--no-download-archive','--no-cache-dir','--no-continue','--force-overwrites','--ignore-config','--no-simulate']:
        assert flag in args
    assert '--download-sections' not in args

@pytest.mark.network
def test_real_youtube_download_opt_in(tmp_path):
    url=os.environ.get('BIVIDEO_YOUTUBE_TEST_URL')
    if not url:pytest.skip('Set BIVIDEO_YOUTUBE_TEST_URL to an authorized test video; network download not executed')
    store=AssetStore(tmp_path/'data')
    r=acquire_youtube(store,url,Path(__file__).resolve().parents[1])
    assert (store.asset_path(r['asset_sha512'])/'source/original.bin').is_file()
