"""Opt-in model contract tests. A skip is NOT a model-quality pass."""
import json,os
from pathlib import Path
import pytest
from bivideo.contracts import PluginSpec
from bivideo.store import AssetStore
from bivideo.engine import Engine
from bivideo.worker import SubprocessWorker

@pytest.mark.models
def test_real_ocr_workers_on_authorized_fixture(tmp_path):
    cfg=os.environ.get('BIVIDEO_REAL_OCR_CASES')
    if not cfg:pytest.skip('No OCR workers/weights supplied; model test not executed')
    cases=json.loads(Path(cfg).read_text())['cases']
    assert cases,'Do not claim a pass for an empty model suite'
    for c in cases:
        store=AssetStore(tmp_path/c['strategy_id']);digest=store.ingest(Path(c['video']))
        engine=Engine(store,Path(__file__).resolve().parents[1])
        engine.register(SubprocessWorker(PluginSpec('ocr',c['strategy_id'],'1',{'source':'source.bytes.v1'},'captions.v1'),c['argv'],c.get('timeout_s',1800)))
        _,outputs=engine.run(digest,'ocr',c['strategy_id'],{'source':store.source_ref(digest)},c['params'])
        result=json.loads(store.resolve(outputs['captions']).read_text())
        assert not result.get('fixture_only',False),'Fixture output cannot certify a real model'
        text=' '.join(x['text'] for x in result['cues'])
        assert all(s in text for s in c['expected_phrases'])
